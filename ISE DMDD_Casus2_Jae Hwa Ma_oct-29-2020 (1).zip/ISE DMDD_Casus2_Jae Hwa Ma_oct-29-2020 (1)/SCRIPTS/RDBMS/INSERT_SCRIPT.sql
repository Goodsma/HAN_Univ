--2. Fill the empty tables with a sufficiently large ppieceulation that Beethovenlies with all
--integrity rules, including C1 – C2 and any other ones you specified yourself: about 25
--choir members, 20 pieces of music and around 10 concerts taking place in around 5
--venues. Common choir vocal ranges are Baritone, Bass, Contralto and Alto
insert into VOCALRANGE
values ('Baritone'),
       ('Bass'),
       ('Contralto'),
       ('Alto')
insert into Choir
values ('National'),
       ('Youth')

insert into town
values ('Amsterdam'),
       ('Arnhem'),
       ('Nijmegen'),
       ('Eindhoven'),
       ('Tilburg')


INSERT INTO MEMBER(MEMBERNO, RANGENAME, TOWNNAME, SURNAME, INITIALS, HOMEHOUSENO, EMAIL, CELLPHONE, LANDLINE)
VALUES (1, 'Baritone', 'Tilburg', 'Boer', 'A', 2, 'm@hot.com', 123456789, 123456789),
       (2, 'Contralto', 'Amsterdam', 'Pieter', 'B', 2, 'a@mail.nl', 123456789, 123456789),
       (3, 'Bass', 'Nijmegen', 'Smit', 'C', 2, 't@hot.com', 123456789, 123456789),
       (4, 'Baritone', 'Arnhem', 'Jansen', 'D', 2, 'D@hot.com', 123456789, 123456789),
       (5, 'Alto', 'Eindhoven', 'Smit', 'E', 2, 'b@mail.com', 123456789, 123456789),
       (6, 'Bass', 'Nijmegen', 'Jansen', 'F', 2, 'f@hot.nl', 123456789, 123456789),
       (7, 'Contralto', 'Nijmegen', 'Boer', 'G', 2, 'g@mail.com', 123456789, 123456789),
       (8, 'Bass', 'Arnhem', 'Smit', 'H', 2, 'r@mail.com', 123456789, 123456789),
       (9, 'Baritone', 'Tilburg', 'Jansen', 'I', 2, 'E@hot.nl', 123456789, 123456789),
       (10, 'Baritone', 'Arnhem', 'Pieter', 'J', 2, 'h@mail.com', 123456789, 123456789),
       (11, 'Bass', 'Amsterdam', 'Jansen', 'K', 2, 'k@mail.nl', 123456789, 123456789),
       (12, 'Alto', 'Tilburg', 'Boer', 'L', 2, 'b@mail.com', 123456789, 123456789),
       (13, 'Contralto', 'Eindhoven', 'Smit', 'M', 2, 'm@hot.com', 123456789, 123456789),
       (14, 'Baritone', 'Amsterdam', 'Pieter', 'N', 2, 'n@mail.com', 123456789, 123456789),
       (15, 'Alto', 'Arnhem', 'Jansen', 'O', 2, 's@mail.com', 123456789, 123456789),
       (16, 'Baritone', 'Nijmegen', 'Pieter', 'P', 2, 'c@hot.nl', 123456789, 123456789),
       (17, 'Baritone', 'Eindhoven', 'Smit', 'W', 2, 'd@mail.com', 123456789, 123456789),
       (18, 'Alto', 'Amsterdam', 'Jansen', 'X', 2, 'X@mail.nl', 123456789, 123456789),
       (19, 'Bass', 'Tilburg', 'Smit', 'Y', 2, 'y@mail.com', 123456789, 123456789),
       (20, 'Baritone', 'Eindhoven', 'Pieter', 'A', 2, 'A@hot.nl', 123456789, 123456789),
       (21, 'Baritone', 'Amsterdam', 'Boer', 'Z', 2, 'J@mail.com', 123456789, 123456789),
       (22, 'Alto', 'Tilburg', 'Pieter', 'A', 2, 'F@mail.com', 123456789, 123456789),
       (23, 'Contralto', 'Eindhoven', 'Jansen', 'G', 2, 'f@hot.com', 123456789, 123456789),
       (24, 'Contralto', 'Arnhem', 'Smit', 'E', 2, 'k@mail.nl', 123456789, 123456789),
       (25, 'Contralto', 'Amsterdam', 'Boer', 'R', 2, 'f@mail.com', 123456789, 123456789)

INSERT INTO COMPOSER(SURNAME, INITIALS, YEARBORN, YEARDIED)
VALUES ('Jansen', 'A', '1988', null),
       ('Peter', 'Z', '1989', null),
       ('Smid', 'F', '1930', '2010'),
       ('Bakker', 'W', '1860', '1920'),
       ('Bos', 'S', '1990', null)

INSERT INTO WORK(SURNAME, INITIALS, TITLE, OPUSNUMBER)
VALUES ('Jansen', 'A', 'Walker', '1'),
       ('Jansen', 'A', 'NightOwl', '2'),
       ('Jansen', 'A', 'Midnight', '3'),
       ('Jansen', 'A', 'Homework', '4'),
       ('Jansen', 'A', 'Brigadier', '5'),
       ('Peter', 'Z', 'Picasso5', '5'),
       ('Peter', 'Z', 'Picasso12', '12'),
       ('Peter', 'Z', 'Picasso7', '7'),
       ('Peter', 'Z', 'Picasso4', '4'),
       ('Peter', 'Z', 'Picasso1', '1'),
       ('Smid', 'F', 'Beethoven', '1'),
       ('Smid', 'F', 'Beethoven3', '3'),
       ('Bakker', 'W', 'piece2', '2'),
       ('Bakker', 'W', 'piece3', '3'),
       ('Bakker', 'W', 'piece4', '4'),
       ('Bakker', 'W', 'piece5', '5'),
       ('Bos', 'S', 'Mus11', '11'),
       ('Bos', 'S', 'Mus7', '7'),
       ('Bos', 'S', 'Mus12', '12'),
       ('Bos', 'S', 'Mus13', '13')

INSERT INTO VENUE(TOWNNAME, VENUENAME)
VALUES ('Arnhem', 'GelreDome'),
       ('Eindhoven', 'De Kuip')


INSERT INTO CONDUCTOROFCHOIR(MEMBERNO, CHOIRNAME)
VALUES (1, 'National'),
       (2, 'National'),
       (24, 'Youth'),
       (25, 'Youth')

INSERT INTO MEMBERINCHOIR(MEMBERNO, CHOIRNAME)
VALUES (3, 'National'),
       (4, 'National'),
       (5, 'National'),
       (6, 'National'),
       (7, 'National'),
       (8, 'National'),
       (9, 'National'),
       (10, 'National'),
       (11, 'National'),
       (12, 'National'),
       (13, 'National'),
       (14, 'Youth'),
       (15, 'Youth'),
       (16, 'Youth'),
       (17, 'Youth'),
       (18, 'Youth'),
       (19, 'Youth'),
       (20, 'Youth'),
       (21, 'Youth'),
       (22, 'Youth'),
       (23, 'Youth')

INSERT INTO VOCALRANGE_IN_WORK(RANGENAME, SURNAME, INITIALS, TITLE, VOCRANGENUMREQUIRED)
VALUES ('Baritone', 'Jansen', 'A', 'Walker', '3'),
       ('Bass', 'Jansen', 'A', 'Walker', '3'),
       ('Alto', 'Jansen', 'A', 'Walker', '2'),
       ('Baritone', 'Jansen', 'A', 'NightOwl', '2'),
       ('Bass', 'Jansen', 'A', 'NightOwl', '1'),
       ('Contralto', 'Jansen', 'A', 'NightOwl', '2'),
       ('Alto', 'Jansen', 'A', 'NightOwl', '3'),
       ('Baritone', 'Peter', 'Z', 'Picasso5', '1'),
       ('Contralto', 'Peter', 'Z', 'Picasso5', '2'),
       ('Baritone', 'Peter', 'Z', 'Picasso1', '2'),
       ('Alto', 'Peter', 'Z', 'Picasso1', '1'),
       ('Contralto', 'Peter', 'Z', 'Picasso1', '3'),
       ('Baritone', 'Smid', 'F', 'Beethoven', '1'),
       ('Contralto', 'Smid', 'F', 'Beethoven', '2'),
       ('Alto', 'Smid', 'F', 'Beethoven3', '3'),
       ('Contralto', 'Smid', 'F', 'Beethoven3', '1'),
       ('Bass', 'Smid', 'F', 'Beethoven3', '2'),
       ('Baritone', 'Bakker', 'W', 'piece2', '2'),
       ('Contralto', 'Bakker', 'W', 'piece2', '2'),
       ('Contralto', 'Bakker', 'W', 'piece5', '2'),
       ('Bass', 'Bakker', 'W', 'piece5', '1'),
       ('Alto', 'Bakker', 'W', 'piece5', '2'),
       ('Bass', 'Bos', 'S', 'Mus12', '1'),
       ('Baritone', 'Bos', 'S', 'Mus12', '3'),
       ('Baritone', 'Bos', 'S', 'Mus13', '2'),
       ('Contralto', 'Bos', 'S', 'Mus13', '2')

INSERT INTO CONDUCTORFORWORK(MEMBERNO, SURNAME, INITIALS, TITLE)
VALUES ('1', 'Jansen', 'A', 'Walker'),
       ('1', 'Jansen', 'A', 'NightOwl'),
       ('1', 'Jansen', 'A', 'Midnight'),
       ('1', 'Jansen', 'A', 'Homework'),
       ('1', 'Jansen', 'A', 'Brigadier'),
       ('2', 'Peter', 'Z', 'Picasso5'),
       ('2', 'Peter', 'Z', 'Picasso12'),
       ('2', 'Peter', 'Z', 'Picasso7'),
       ('2', 'Peter', 'Z', 'Picasso4'),
       ('2', 'Peter', 'Z', 'Picasso1'),
       ('24', 'Smid', 'F', 'Beethoven'),
       ('24', 'Smid', 'F', 'Beethoven3'),
       ('24', 'Bakker', 'W', 'piece2'),
       ('24', 'Bakker', 'W', 'piece3'),
       ('24', 'Bakker', 'W', 'piece4'),
       ('25', 'Bakker', 'W', 'piece5'),
       ('25', 'Bos', 'S', 'Mus11'),
       ('25', 'Bos', 'S', 'Mus7'),
       ('25', 'Bos', 'S', 'Mus12'),
       ('25', 'Bos', 'S', 'Mus13')

INSERT INTO CONCERT(PERFORMANCEDATE, CHOIRNAME, TOWNNAME, VENUENAME, PERFORMANCETIME, LOCATION, TITLE)
VALUES ('2 FEB', 'National', 'Arnhem', 'GelreDome', '20:00', 'Hall B', 'Best Of'),
       ('24 DEC', 'Youth', 'Eindhoven', 'De Kuip', '18:00', 'Hall 1', 'Christmas')

INSERT INTO PROGRAM(PERFORMANCEDATE, SEQNO, SURNAME, INITIALS, TITLE)
VALUES ('2 FEB', '1', 'Jansen', 'A', 'NightOwl'),
       ('2 FEB', '2', 'Smid', 'F', 'Beethoven3'),
       ('2 FEB', '4', 'Bos', 'S', 'Mus7'),
       ('2 FEB', '3', 'Bakker', 'W', 'piece3'),
       ('2 FEB', '5', 'Jansen', 'A', 'Walker'),
       ('24 DEC', '1', 'Bakker', 'W', 'piece2'),
       ('24 DEC', '2', 'Bos', 'S', 'Mus12'),
       ('24 DEC', '3', 'Bos', 'S', 'Mus13'),
       ('24 DEC', '4', 'Peter', 'Z', 'Picasso4')

INSERT INTO MEMBERINCONCERT(MEMBERNO, PERFORMANCEDATE)
VALUES ('3', '2 FEB'),
       ('4', '2 FEB'),
       ('5', '2 FEB'),
       ('6', '2 FEB'),
       ('7', '2 FEB'),
       ('8', '2 FEB'),
       ('9', '2 FEB'),
       ('10', '2 FEB'),
       ('11', '2 FEB'),
       ('12', '2 FEB'),
       ('13', '2 FEB'),
       ('14', '24 DEC'),
       ('15', '24 DEC'),
       ('16', '24 DEC'),
       ('17', '24 DEC'),
       ('18', '24 DEC'),
       ('19', '24 DEC'),
       ('20', '24 DEC'),
       ('21', '24 DEC'),
       ('22', '24 DEC'),
       ('23', '24 DEC')
