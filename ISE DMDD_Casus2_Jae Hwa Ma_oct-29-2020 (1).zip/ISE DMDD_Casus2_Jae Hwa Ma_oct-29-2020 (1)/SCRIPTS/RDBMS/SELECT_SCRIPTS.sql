-- 1
-- Concert organizers would like to know which choirs can play concerts in their town.
-- Provide a query that returns all choirs that have members in the same town as a specific concert location.
DECLARE @ConcertLocation LOCATION_NAME; SET @ConcertLocation = 'Eindhoven';

SELECT C.CHOIRNAME FROM dbo.CHOIR C
WHERE C.CHOIRNAME IN (SELECT MC.CHOIRNAME FROM dbo.MEMBERINCHOIR MC
                        INNER JOIN dbo.MEMBER M
                        ON M.MEMBERNO = MC.MEMBERNO
                        WHERE M.TOWNNAME = @ConcertLocation)

-- 2
-- Membership between choirs is fluid and often based on which musicians are available to sing in a specific range to perform at a specific concert.
-- Provide a query that returns all vocalists in a specific range that live in a specific city OR that have sung in concerts in the specified city
-- (because that implies they have no problem travelling to that city to perform in a concert)

DECLARE @VocalRange VOICE_TYPE_NAME; SET @VocalRange = 'Bass';
DECLARE @Location LOCATION_NAME; SET @Location = 'Eindhoven';

SELECT * FROM MEMBER WHERE RangeName = @VocalRange
and 
(TownName = @Location
or
MemberNo IN (SELECT MemberNo FROM MemberInConcert WHERE PerformanceDate IN (SELECT PerformanceDate FROM CONCERT WHERE TownName = @Location))
)

-- 3
-- To determine which works can be sung at a concert, 
-- it is necessary to determine works that require vocalists in ranges that are available in the city in which the concert is to take place.
-- Provide a query that returns all works that satisfy this requirement.
SELECT * FROM WORK W
WHERE (SELECT count(*) FROM VOCALRANGE_IN_WORK 
WHERE SurName = W.SurName
and Initials = W.Initials
and Title = W.Title)
=
(SELECT count(*) FROM VOCALRANGE_IN_WORK VIW
WHERE SurName = W.SurName
and Initials = W.Initials
and Title = W.Title
and (SELECT count(*) FROM MEMBER WHERE RangeName = VIW.RangeName and TownName = 'Arnhem') 
>=VIW.VocRangeNumRequired)


SELECT * FROM WORK W 
WHERE NOT EXISTS
(SELECT * FROM VOCALRANGE_IN_WORK VIW WHERE
Surname = W.Surname 
and Initials = W.Initials
and Title = W.Title
and VocRangeNumRequired > (SELECT count(*) FROM MEMBER where TownName = 'Arnhem' and RangeName = VIW.RangeName))



-- 4
-- Sometimes when staging a concert it is already known which work is to be performed (Bach's Mattheus Passion, for example),
-- but not which choir is to perform it.
-- In such a case it is often advantageous to enlist the services of choirs that are conducted by someone who has already performed the work in question.
-- Provide a query that returns all choirs that are conducted by a conductor who has conducted a specific work before.
DECLARE @Surname LOCATION_NAME; SET @Surname = 'Bakker';
DECLARE @Initials LOCATION_NAME; SET @Initials = 'w';
DECLARE @Title LOCATION_NAME; SET @Title = 'piece2';


SELECT coc.CHOIRNAME
FROM CONDUCTOROFCHOIR coc
INNER JOIN CONDUCTORFORWORK cfk on coc.MEMBERNO = cfk.MEMBERNO
WHERE cfk.SURNAME = @Surname
    AND cfk.INITIALS = @Initials
    AND cfk.TITLE = @Title

-- 5
-- Likewise for soloists it is often advantageous to enlist members of another choir
-- if they have already performed a specific work in a specific range.
-- Provide a query that returns these members for a specific work and a specific vocal range.
SELECT *
FROM dbo.MEMBER MEM
WHERE EXISTS(SELECT MIC.MEMBERNO
             FROM dbo.CONCERT C
                      INNER JOIN dbo.MEMBERINCONCERT MIC
                                 ON C.PERFORMANCEDATE = MIC.PERFORMANCEDATE
                      INNER JOIN dbo.PROGRAM P
                                 ON P.PERFORMANCEDATE = C.PERFORMANCEDATE
             WHERE P.TITLE = 'NightOwl'
               AND MIC.MEMBERNO = MEM.MEMBERNO)
  AND MEM.RANGENAME = 'Bass'

 --It doesn't mean that member have performed the work but member
 --have participated in the concert include the specific work.



