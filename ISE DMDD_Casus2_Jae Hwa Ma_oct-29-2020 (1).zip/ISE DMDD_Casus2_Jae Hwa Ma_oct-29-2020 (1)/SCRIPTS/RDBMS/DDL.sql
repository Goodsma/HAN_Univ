/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2014                    */
/* Created on:     10/3/2019 11:35:16 AM                        */
/*==============================================================*/


if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CONCERT') and o.name = 'FK_CONCERT_CHOIRINCO_CHOIR')
alter table CONCERT
   drop constraint FK_CONCERT_CHOIRINCO_CHOIR
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CONCERT') and o.name = 'FK_CONCERT_CONCERTAT_VENUE')
alter table CONCERT
   drop constraint FK_CONCERT_CONCERTAT_VENUE
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CONDUCTORFORWORK') and o.name = 'FK_CONDUCTO_CONDUCTED_MEMBER')
alter table CONDUCTORFORWORK
   drop constraint FK_CONDUCTO_CONDUCTED_MEMBER
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CONDUCTORFORWORK') and o.name = 'FK_CONDUCTO_CONDUCTOR_WORK')
alter table CONDUCTORFORWORK
   drop constraint FK_CONDUCTO_CONDUCTOR_WORK
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CONDUCTOROFCHOIR') and o.name = 'FK_CONDUCTO_CONDUCTOR_CHOIR')
alter table CONDUCTOROFCHOIR
   drop constraint FK_CONDUCTO_CONDUCTOR_CHOIR
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CONDUCTOROFCHOIR') and o.name = 'FK_CONDUCTO_IS_CONDUC_MEMBER')
alter table CONDUCTOROFCHOIR
   drop constraint FK_CONDUCTO_IS_CONDUC_MEMBER
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('MEMBER') and o.name = 'FK_MEMBER_MEMBERINT_TOWN')
alter table MEMBER
   drop constraint FK_MEMBER_MEMBERINT_TOWN
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('MEMBER') and o.name = 'FK_MEMBER_VOCALRANG_VOCALRAN')
alter table MEMBER
   drop constraint FK_MEMBER_VOCALRANG_VOCALRAN
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('MEMBERINCHOIR') and o.name = 'FK_MEMBERIN_IS_A_MEMB_MEMBER')
alter table MEMBERINCHOIR
   drop constraint FK_MEMBERIN_IS_A_MEMB_MEMBER
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('MEMBERINCHOIR') and o.name = 'FK_MEMBERIN_MEMBERINC_CHOIR')
alter table MEMBERINCHOIR
   drop constraint FK_MEMBERIN_MEMBERINC_CHOIR
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('MEMBERINCONCERT') and o.name = 'FK_MEMBERIN_MEMBERINC_MEMBER')
alter table MEMBERINCONCERT
   drop constraint FK_MEMBERIN_MEMBERINC_MEMBER
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('MEMBERINCONCERT') and o.name = 'FK_MEMBERIN_TOOK_PART_CONCERT')
alter table MEMBERINCONCERT
   drop constraint FK_MEMBERIN_TOOK_PART_CONCERT
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('PROGRAM') and o.name = 'FK_PROGRAM_CONCERTIN_CONCERT')
alter table PROGRAM
   drop constraint FK_PROGRAM_CONCERTIN_CONCERT
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('PROGRAM') and o.name = 'FK_PROGRAM_WORKINPRO_WORK')
alter table PROGRAM
   drop constraint FK_PROGRAM_WORKINPRO_WORK
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('VENUE') and o.name = 'FK_VENUE_VENUEINTO_TOWN')
alter table VENUE
   drop constraint FK_VENUE_VENUEINTO_TOWN
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('VOCALRANGE_IN_WORK') and o.name = 'FK_VOCALRAN_VOCALRANG_VOCALRAN')
alter table VOCALRANGE_IN_WORK
   drop constraint FK_VOCALRAN_VOCALRANG_VOCALRAN
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('VOCALRANGE_IN_WORK') and o.name = 'FK_VOCALRAN_WORKINVOC_WORK')
alter table VOCALRANGE_IN_WORK
   drop constraint FK_VOCALRAN_WORKINVOC_WORK
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('WORK') and o.name = 'FK_WORK_COMPOSERO_COMPOSER')
alter table WORK
   drop constraint FK_WORK_COMPOSERO_COMPOSER
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CHOIR')
            and   type = 'U')
   drop table CHOIR
go

if exists (select 1
            from  sysobjects
           where  id = object_id('COMPOSER')
            and   type = 'U')
   drop table COMPOSER
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CONCERT')
            and   name  = 'CHOIRINCONCERT_FK'
            and   indid > 0
            and   indid < 255)
   drop index CONCERT.CHOIRINCONCERT_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CONCERT')
            and   name  = 'CONCERTATVENUE_FK'
            and   indid > 0
            and   indid < 255)
   drop index CONCERT.CONCERTATVENUE_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CONCERT')
            and   type = 'U')
   drop table CONCERT
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CONDUCTORFORWORK')
            and   name  = 'CONDUCTOR_FK'
            and   indid > 0
            and   indid < 255)
   drop index CONDUCTORFORWORK.CONDUCTOR_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CONDUCTORFORWORK')
            and   name  = 'CONDUCTED_WORK_FK'
            and   indid > 0
            and   indid < 255)
   drop index CONDUCTORFORWORK.CONDUCTED_WORK_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CONDUCTORFORWORK')
            and   type = 'U')
   drop table CONDUCTORFORWORK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CONDUCTOROFCHOIR')
            and   name  = 'CONDUCTOROFCHOIR_FK'
            and   indid > 0
            and   indid < 255)
   drop index CONDUCTOROFCHOIR.CONDUCTOROFCHOIR_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CONDUCTOROFCHOIR')
            and   name  = 'IS_CONDUCTOR_OF_FK'
            and   indid > 0
            and   indid < 255)
   drop index CONDUCTOROFCHOIR.IS_CONDUCTOR_OF_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CONDUCTOROFCHOIR')
            and   type = 'U')
   drop table CONDUCTOROFCHOIR
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('MEMBER')
            and   name  = 'MEMBERINTOWN_FK'
            and   indid > 0
            and   indid < 255)
   drop index MEMBER.MEMBERINTOWN_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('MEMBER')
            and   name  = 'VOCALRANGEOFMEMBER_FK'
            and   indid > 0
            and   indid < 255)
   drop index MEMBER.VOCALRANGEOFMEMBER_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('MEMBER')
            and   type = 'U')
   drop table MEMBER
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('MEMBERINCHOIR')
            and   name  = 'MEMBERINCHOIR_FK'
            and   indid > 0
            and   indid < 255)
   drop index MEMBERINCHOIR.MEMBERINCHOIR_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('MEMBERINCHOIR')
            and   name  = 'IS_A_MEMBER_OF_FK'
            and   indid > 0
            and   indid < 255)
   drop index MEMBERINCHOIR.IS_A_MEMBER_OF_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('MEMBERINCHOIR')
            and   type = 'U')
   drop table MEMBERINCHOIR
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('MEMBERINCONCERT')
            and   name  = 'TOOK_PART_IN_FK'
            and   indid > 0
            and   indid < 255)
   drop index MEMBERINCONCERT.TOOK_PART_IN_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('MEMBERINCONCERT')
            and   name  = 'MEMBERINCONCERT_FK'
            and   indid > 0
            and   indid < 255)
   drop index MEMBERINCONCERT.MEMBERINCONCERT_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('MEMBERINCONCERT')
            and   type = 'U')
   drop table MEMBERINCONCERT
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('PROGRAM')
            and   name  = 'CONCERTINPROGRAM_FK'
            and   indid > 0
            and   indid < 255)
   drop index PROGRAM.CONCERTINPROGRAM_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('PROGRAM')
            and   name  = 'WORKINPROGRAM_FK'
            and   indid > 0
            and   indid < 255)
   drop index PROGRAM.WORKINPROGRAM_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('PROGRAM')
            and   type = 'U')
   drop table PROGRAM
go

if exists (select 1
            from  sysobjects
           where  id = object_id('TOWN')
            and   type = 'U')
   drop table TOWN
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('VENUE')
            and   name  = 'VENUEINTOWN_FK'
            and   indid > 0
            and   indid < 255)
   drop index VENUE.VENUEINTOWN_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('VENUE')
            and   type = 'U')
   drop table VENUE
go

if exists (select 1
            from  sysobjects
           where  id = object_id('VOCALRANGE')
            and   type = 'U')
   drop table VOCALRANGE
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('VOCALRANGE_IN_WORK')
            and   name  = 'WORKINVOCALRANGEINWORK_FK'
            and   indid > 0
            and   indid < 255)
   drop index VOCALRANGE_IN_WORK.WORKINVOCALRANGEINWORK_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('VOCALRANGE_IN_WORK')
            and   name  = 'VOCALRANGEINVOCALRANGEINWORK_FK'
            and   indid > 0
            and   indid < 255)
   drop index VOCALRANGE_IN_WORK.VOCALRANGEINVOCALRANGEINWORK_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('VOCALRANGE_IN_WORK')
            and   type = 'U')
   drop table VOCALRANGE_IN_WORK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('WORK')
            and   name  = 'COMPOSEROFWORK_FK'
            and   indid > 0
            and   indid < 255)
   drop index WORK.COMPOSEROFWORK_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('WORK')
            and   type = 'U')
   drop table WORK
go

if exists(select 1 from systypes where name='DAY')
   drop type DAY
go

if exists(select 1 from systypes where name='DURATION')
   drop type DURATION
go

if exists(select 1 from systypes where name='EMAIL')
   drop type EMAIL
go

if exists(select 1 from systypes where name='HOUSENO')
   drop type HOUSENO
go

if exists(select 1 from systypes where name='HOUSE_NO')
   drop type HOUSE_NO
go

if exists(select 1 from systypes where name='INITIALS')
   drop type INITIALS
go

if exists(select 1 from systypes where name='LOCATION_NAME')
   drop type LOCATION_NAME
go

if exists(select 1 from systypes where name='LOST_YN')
   drop type LOST_YN
go

if exists(select 1 from systypes where name='NAME')
   drop type NAME
go

if exists(select 1 from systypes where name='OPUS_NO')
   drop type OPUS_NO
go

if exists(select 1 from systypes where name='PHONE_NO')
   drop type PHONE_NO
go

if exists(select 1 from systypes where name='POST_CODE')
   drop type POST_CODE
go

if exists(select 1 from systypes where name='PRICE')
   drop type PRICE
go

if exists(select 1 from systypes where name='SEQ_NO')
   drop type SEQ_NO
go

if exists(select 1 from systypes where name='STREET_NAME')
   drop type STREET_NAME
go

if exists(select 1 from systypes where name='PERFTIME')
   drop type PERFTIME
go

if exists(select 1 from systypes where name='TITLE')
   drop type TITLE
go

if exists(select 1 from systypes where name='TOWN_NAME')
   drop type TOWN_NAME
go

if exists(select 1 from systypes where name='VOICE_TYPE_NAME')
   drop type VOICE_TYPE_NAME
go

if exists(select 1 from systypes where name='YEAR')
   drop type YEAR
go

/*==============================================================*/
/* Domain: DAY                                                  */
/*==============================================================*/
create type DAY
   from char(10)
go

/*==============================================================*/
/* Domain: DURATION                                             */
/*==============================================================*/
create type DURATION
   from char(10)
go

/*==============================================================*/
/* Domain: EMAIL                                                */
/*==============================================================*/
create type EMAIL
   from char(10)
go

/*==============================================================*/
/* Domain: HOUSENO                                              */
/*==============================================================*/
create type HOUSENO
   from char(10)
go

/*==============================================================*/
/* Domain: HOUSE_NO                                             */
/*==============================================================*/
create type HOUSE_NO
   from char(10)
go

/*==============================================================*/
/* Domain: INITIALS                                             */
/*==============================================================*/
create type INITIALS
   from char(10)
go

/*==============================================================*/
/* Domain: LOCATION_NAME                                        */
/*==============================================================*/
create type LOCATION_NAME
   from char(10)
go

/*==============================================================*/
/* Domain: LOST_YN                                              */
/*==============================================================*/
create type LOST_YN
   from char(10)
go

/*==============================================================*/
/* Domain: NAME                                                 */
/*==============================================================*/
create type NAME
   from char(10)
go

/*==============================================================*/
/* Domain: OPUS_NO                                              */
/*==============================================================*/
create type OPUS_NO
   from char(10)
go

/*==============================================================*/
/* Domain: PHONE_NO                                             */
/*==============================================================*/
create type PHONE_NO
   from char(10)
go

/*==============================================================*/
/* Domain: POST_CODE                                            */
/*==============================================================*/
create type POST_CODE
   from char(10)
go

/*==============================================================*/
/* Domain: PRICE                                                */
/*==============================================================*/
create type PRICE
   from char(10)
go

/*==============================================================*/
/* Domain: SEQ_NO                                               */
/*==============================================================*/
create type SEQ_NO
   from char(10)
go

/*==============================================================*/
/* Domain: STREET_NAME                                          */
/*==============================================================*/
create type STREET_NAME
   from char(10)
go

/*==============================================================*/
/* Domain: PERFTIME                                                 */
/*==============================================================*/
create type PERFTIME
   from char(10)
go

/*==============================================================*/
/* Domain: TITLE                                                */
/*==============================================================*/
create type TITLE
   from char(10)
go

/*==============================================================*/
/* Domain: TOWN_NAME                                            */
/*==============================================================*/
create type TOWN_NAME
   from char(10)
go

/*==============================================================*/
/* Domain: VOICE_TYPE_NAME                                      */
/*==============================================================*/
create type VOICE_TYPE_NAME
   from char(10)
go

/*==============================================================*/
/* Domain: YEAR                                                 */
/*==============================================================*/
create type YEAR
   from char(10)
go

/*==============================================================*/
/* Table: CHOIR                                                 */
/*==============================================================*/
create table CHOIR (
   CHOIRNAME            char(10)             not null,
   constraint PK_CHOIR primary key (CHOIRNAME)
)
go

/*==============================================================*/
/* Table: COMPOSER                                              */
/*==============================================================*/
create table COMPOSER (
   SURNAME         NAME                 not null,
   INITIALS         INITIALS             not null,
   YEARBORN             YEAR                 not null,
   YEARDIED             YEAR                 null,
   constraint PK_COMPOSER primary key (SURNAME, INITIALS)
)
go

/*==============================================================*/
/* Table: CONCERT                                               */
/*==============================================================*/
create table CONCERT (
   PERFORMANCEDATE      DAY                  not null,
   CHOIRNAME            char(10)             null,
   TOWNNAME             TOWN_NAME            not null,
   VENUENAME            char(10)             not null,
   PERFORMANCETIME      PERFTIME                 not null,
   LOCATION             LOCATION_NAME        not null,
   TITLE                TITLE                not null,
   constraint PK_CONCERT primary key (PERFORMANCEDATE)
)
go

if exists (select 1 from  sys.extended_properties
           where major_id = object_id('CONCERT') and minor_id = 0)
begin
   declare @CurrentUser sysname
select @CurrentUser = user_name()
execute sp_dropextendedproperty 'MS_Description',
   'user', @CurrentUser, 'table', 'CONCERT'

end


select @CurrentUser = user_name()
execute sp_addextendedproperty 'MS_Description',
   'CONCERT',
   'user', @CurrentUser, 'table', 'CONCERT'
go

/*==============================================================*/
/* Index: CONCERTATVENUE_FK                                     */
/*==============================================================*/




create nonclustered index CONCERTATVENUE_FK on CONCERT (TOWNNAME ASC,
  VENUENAME ASC)
go

/*==============================================================*/
/* Index: CHOIRINCONCERT_FK                                     */
/*==============================================================*/




create nonclustered index CHOIRINCONCERT_FK on CONCERT (CHOIRNAME ASC)
go

/*==============================================================*/
/* Table: CONDUCTORFORWORK                                      */
/*==============================================================*/
create table CONDUCTORFORWORK (
   MEMBERNO             SEQ_NO               not null,
   SURNAME         NAME                 not null,
   INITIALS         INITIALS             not null,
   TITLE         TITLE                not null,
   constraint PK_CONDUCTORFORWORK primary key (SURNAME, INITIALS, MEMBERNO, TITLE)
)
go

/*==============================================================*/
/* Index: CONDUCTED_WORK_FK                                     */
/*==============================================================*/




create nonclustered index CONDUCTED_WORK_FK on CONDUCTORFORWORK (MEMBERNO ASC)
go

/*==============================================================*/
/* Index: CONDUCTOR_FK                                          */
/*==============================================================*/




create nonclustered index CONDUCTOR_FK on CONDUCTORFORWORK (SURNAME ASC,
  INITIALS ASC,
  TITLE ASC)
go

/*==============================================================*/
/* Table: CONDUCTOROFCHOIR                                      */
/*==============================================================*/
create table CONDUCTOROFCHOIR (
   MEMBERNO             SEQ_NO               not null,
   CHOIRNAME            char(10)             not null,
   constraint PK_CONDUCTOROFCHOIR primary key (MEMBERNO, CHOIRNAME)
)
go

/*==============================================================*/
/* Index: IS_CONDUCTOR_OF_FK                                    */
/*==============================================================*/




create nonclustered index IS_CONDUCTOR_OF_FK on CONDUCTOROFCHOIR (MEMBERNO ASC)
go

/*==============================================================*/
/* Index: CONDUCTOROFCHOIR_FK                                   */
/*==============================================================*/




create nonclustered index CONDUCTOROFCHOIR_FK on CONDUCTOROFCHOIR (CHOIRNAME ASC)
go

/*==============================================================*/
/* Table: MEMBER                                                */
/*==============================================================*/
create table MEMBER (
   MEMBERNO             SEQ_NO               not null,
   RANGENAME            char(10)             null,
   TOWNNAME             TOWN_NAME            not null,
   SURNAME              NAME                 not null,
   INITIALS             INITIALS             not null,
   HOMEHOUSENO          HOUSE_NO             not null,
   EMAIL                EMAIL                not null,
   CELLPHONE            PHONE_NO             null,
   LANDLINE             PHONE_NO             null,
   constraint PK_MEMBER primary key (MEMBERNO)
)
go

/*==============================================================*/
/* Index: VOCALRANGEOFMEMBER_FK                                 */
/*==============================================================*/




create nonclustered index VOCALRANGEOFMEMBER_FK on MEMBER (RANGENAME ASC)
go

/*==============================================================*/
/* Index: MEMBERINTOWN_FK                                       */
/*==============================================================*/




create nonclustered index MEMBERINTOWN_FK on MEMBER (TOWNNAME ASC)
go

/*==============================================================*/
/* Table: MEMBERINCHOIR                                         */
/*==============================================================*/
create table MEMBERINCHOIR (
   MEMBERNO             SEQ_NO               not null,
   CHOIRNAME            char(10)             not null,
   constraint PK_MEMBERINCHOIR primary key (MEMBERNO, CHOIRNAME)
)
go

/*==============================================================*/
/* Index: IS_A_MEMBER_OF_FK                                     */
/*==============================================================*/




create nonclustered index IS_A_MEMBER_OF_FK on MEMBERINCHOIR (MEMBERNO ASC)
go

/*==============================================================*/
/* Index: MEMBERINCHOIR_FK                                      */
/*==============================================================*/




create nonclustered index MEMBERINCHOIR_FK on MEMBERINCHOIR (CHOIRNAME ASC)
go

/*==============================================================*/
/* Table: MEMBERINCONCERT                                       */
/*==============================================================*/
create table MEMBERINCONCERT (
   MEMBERNO             SEQ_NO               not null,
   PERFORMANCEDATE      DAY                  not null,
   constraint PK_MEMBERINCONCERT primary key (MEMBERNO, PERFORMANCEDATE)
)
go

/*==============================================================*/
/* Index: MEMBERINCONCERT_FK                                    */
/*==============================================================*/




create nonclustered index MEMBERINCONCERT_FK on MEMBERINCONCERT (MEMBERNO ASC)
go

/*==============================================================*/
/* Index: TOOK_PART_IN_FK                                       */
/*==============================================================*/




create nonclustered index TOOK_PART_IN_FK on MEMBERINCONCERT (PERFORMANCEDATE ASC)
go

/*==============================================================*/
/* Table: PROGRAM                                               */
/*==============================================================*/
create table PROGRAM (
   PERFORMANCEDATE      DAY                  not null,
   SEQNO                SEQ_NO               not null,
   SURNAME         NAME                 not null,
   INITIALS         INITIALS             not null,
   TITLE         TITLE                not null,
   constraint PK_PROGRAM primary key (PERFORMANCEDATE, SEQNO)
)
go

/*==============================================================*/
/* Index: WORKINPROGRAM_FK                                      */
/*==============================================================*/




create nonclustered index WORKINPROGRAM_FK on PROGRAM (SURNAME ASC,
  INITIALS ASC,
  TITLE ASC)
go

/*==============================================================*/
/* Index: CONCERTINPROGRAM_FK                                   */
/*==============================================================*/




create nonclustered index CONCERTINPROGRAM_FK on PROGRAM (PERFORMANCEDATE ASC)
go

/*==============================================================*/
/* Table: TOWN                                                  */
/*==============================================================*/
create table TOWN (
   TOWNNAME             TOWN_NAME            not null,
   constraint PK_TOWN primary key (TOWNNAME)
)
go

/*==============================================================*/
/* Table: VENUE                                                 */
/*==============================================================*/
create table VENUE (
   TOWNNAME             TOWN_NAME            not null,
   VENUENAME            char(10)             not null,
   constraint PK_VENUE primary key (TOWNNAME, VENUENAME)
)
go

/*==============================================================*/
/* Index: VENUEINTOWN_FK                                        */
/*==============================================================*/




create nonclustered index VENUEINTOWN_FK on VENUE (TOWNNAME ASC)
go

/*==============================================================*/
/* Table: VOCALRANGE                                            */
/*==============================================================*/
create table VOCALRANGE (
   RANGENAME            char(10)             not null,
   constraint PK_VOCALRANGE primary key (RANGENAME)
)
go

/*==============================================================*/
/* Table: VOCALRANGE_IN_WORK                                    */
/*==============================================================*/
create table VOCALRANGE_IN_WORK (
   RANGENAME            char(10)             not null,
   SURNAME         NAME                 not null,
   INITIALS         INITIALS             not null,
   TITLE         TITLE                not null,
   VOCRANGENUMREQUIRED  char(10)             not null,
   constraint PK_VOCALRANGE_IN_WORK primary key (SURNAME, INITIALS, RANGENAME, TITLE)
)
go

/*==============================================================*/
/* Index: VOCALRANGEINVOCALRANGEINWORK_FK                       */
/*==============================================================*/




create nonclustered index VOCALRANGEINVOCALRANGEINWORK_FK on VOCALRANGE_IN_WORK (RANGENAME ASC)
go

/*==============================================================*/
/* Index: WORKINVOCALRANGEINWORK_FK                             */
/*==============================================================*/




create nonclustered index WORKINVOCALRANGEINWORK_FK on VOCALRANGE_IN_WORK (SURNAME ASC,
  INITIALS ASC,
  TITLE ASC)
go

/*==============================================================*/
/* Table: WORK                                                  */
/*==============================================================*/
create table WORK (
   SURNAME         NAME                 not null,
   INITIALS         INITIALS             not null,
   TITLE         TITLE                not null,
   OPUSNUMBER           OPUS_NO              null,
   constraint PK_WORK primary key (SURNAME, INITIALS, TITLE)
)
go

/*==============================================================*/
/* Index: COMPOSEROFWORK_FK                                     */
/*==============================================================*/




create nonclustered index COMPOSEROFWORK_FK on WORK (SURNAME ASC,
  INITIALS ASC)
go

alter table CONCERT
   add constraint FK_CONCERT_CHOIRINCO_CHOIR foreign key (CHOIRNAME)
      references CHOIR (CHOIRNAME)
go

alter table CONCERT
   add constraint FK_CONCERT_CONCERTAT_VENUE foreign key (TOWNNAME, VENUENAME)
      references VENUE (TOWNNAME, VENUENAME)
go

alter table CONDUCTORFORWORK
   add constraint FK_CONDUCTO_CONDUCTED_MEMBER foreign key (MEMBERNO)
      references MEMBER (MEMBERNO)
go

alter table CONDUCTORFORWORK
   add constraint FK_CONDUCTO_CONDUCTOR_WORK foreign key (SURNAME, INITIALS, TITLE)
      references WORK (SURNAME, INITIALS, TITLE)
go

alter table CONDUCTOROFCHOIR
   add constraint FK_CONDUCTO_CONDUCTOR_CHOIR foreign key (CHOIRNAME)
      references CHOIR (CHOIRNAME)
go

alter table CONDUCTOROFCHOIR
   add constraint FK_CONDUCTO_IS_CONDUC_MEMBER foreign key (MEMBERNO)
      references MEMBER (MEMBERNO)
go

alter table MEMBER
   add constraint FK_MEMBER_MEMBERINT_TOWN foreign key (TOWNNAME)
      references TOWN (TOWNNAME)
go

alter table MEMBER
   add constraint FK_MEMBER_VOCALRANG_VOCALRAN foreign key (RANGENAME)
      references VOCALRANGE (RANGENAME)
go

alter table MEMBERINCHOIR
   add constraint FK_MEMBERIN_IS_A_MEMB_MEMBER foreign key (MEMBERNO)
      references MEMBER (MEMBERNO)
go

alter table MEMBERINCHOIR
   add constraint FK_MEMBERIN_MEMBERINC_CHOIR foreign key (CHOIRNAME)
      references CHOIR (CHOIRNAME)
go

alter table MEMBERINCONCERT
   add constraint FK_MEMBERIN_MEMBERINC_MEMBER foreign key (MEMBERNO)
      references MEMBER (MEMBERNO)
go

alter table MEMBERINCONCERT
   add constraint FK_MEMBERIN_TOOK_PART_CONCERT foreign key (PERFORMANCEDATE)
      references CONCERT (PERFORMANCEDATE)
go

alter table PROGRAM
   add constraint FK_PROGRAM_CONCERTIN_CONCERT foreign key (PERFORMANCEDATE)
      references CONCERT (PERFORMANCEDATE)
go

alter table PROGRAM
   add constraint FK_PROGRAM_WORKINPRO_WORK foreign key (SURNAME, INITIALS, TITLE)
      references WORK (SURNAME, INITIALS, TITLE)
go

alter table VENUE
   add constraint FK_VENUE_VENUEINTO_TOWN foreign key (TOWNNAME)
      references TOWN (TOWNNAME)
go

alter table VOCALRANGE_IN_WORK
   add constraint FK_VOCALRAN_VOCALRANG_VOCALRAN foreign key (RANGENAME)
      references VOCALRANGE (RANGENAME)
go

alter table VOCALRANGE_IN_WORK
   add constraint FK_VOCALRAN_WORKINVOC_WORK foreign key (SURNAME, INITIALS, TITLE)
      references WORK (SURNAME, INITIALS, TITLE)
go

alter table WORK
   add constraint FK_WORK_COMPOSERO_COMPOSER foreign key (SURNAME, INITIALS)
      references COMPOSER (SURNAME, INITIALS)
go

