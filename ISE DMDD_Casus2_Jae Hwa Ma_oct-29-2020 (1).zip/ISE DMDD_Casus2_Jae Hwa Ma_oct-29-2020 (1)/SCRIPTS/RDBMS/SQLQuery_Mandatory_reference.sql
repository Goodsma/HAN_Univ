--mandatory child references

SELECT * FROM CONCERT

BEGIN TRAN

INSERT INTO CONCERT 
VALUES('17 oct','National','Arnhem','GelreDome','20:00','Hall B','Best Of')

ROLLBACK TRAN


SELECT * FROM PROGRAM

DROP TRIGGER IF EXISTS trg_concert_ins
go
CREATE TRIGGER trg_concert_ins
ON CONCERT
AFTER INSERT
AS
BEGIN
	IF @@ROWCOUNT = 0 RETURN
	SET NOCOUNT ON
	BEGIN TRY
		IF EXISTS(SELECT * FROM 
				INSERTED I LEFT JOIN PROGRAM P
				ON I.PerformanceDate = P.PerformanceDate
				WHERE P.PerformanceDate IS NULL)
		THROW 50001, 'Concert can''t exist ownself without Program',1
	END TRY
	BEGIN CATCH
		THROW
	END CATCH
END







