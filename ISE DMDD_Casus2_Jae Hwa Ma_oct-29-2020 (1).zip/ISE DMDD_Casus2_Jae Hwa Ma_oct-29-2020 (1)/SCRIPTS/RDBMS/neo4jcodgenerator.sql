SELECT 'CREATE (m:MEMBER {MEMBERNO:'+MEMBERNO+', Surname:"'+Surname+'", Initials:"'+Initials+'", HomeHouseNo:'+HomeHouseNo+', Email:"'+Email+'", CellPhone:'+CellPhone+', Landline:'+Landline+'});' FROM MEMBER

SELECT 'CREATE (c:Choir {ChoirName:"'+ChoirName+'"});' FROM Choir

SELECT 'CREATE (v:VOCALRANGE {RangeName:"'+RangeName+'"});' FROM VOCALRANGE

SELECT 'CREATE (t:TOWN {TownName:"'+TownName+'"});' FROM TOWN

SELECT 'CREATE (c:CONCERT {PerformanceDate:"'+PerformanceDate+'", PerformanceTime:"'+PerformanceTime+'", Location:"'+Location+'", Title:"'+Title+'"});' FROM CONCERT

SELECT 'CREATE (w:WORK {Title:"'+Title+'", OpusNumber:'+OpusNumber+'});' FROM WORK

SELECT 'CREATE (c:COMPOSER {Surname:"'+Surname+'", Initials:"'+Initials+'", YearBorn:"'+YearBorn+'", YearDied:"'+YearDied+'"});' FROM COMPOSER where YEARDIED IS NOT NULL

SELECT 'CREATE (c:COMPOSER {Surname:"'+Surname+'", Initials:"'+Initials+'", YearBorn:"'+YearBorn+'"});' FROM COMPOSER WHERE YEARDIED IS NULL

SELECT 'CREATE (v:VENUE {VenueName:"'+VenueName+'"});' FROM VENUE 

SELECT
'MATCH (c:Choir {ChoirName:"'+CHOIRNAME+'"}),
(m:MEMBER {MEMBERNO:'+MEMBERNO+'})
CREATE (m)-[r:is_a_member_of]->(c);'
FROM MemberInChoir

SELECT
'MATCH (c:Choir {ChoirName:"'+CHOIRNAME+'"}),
(m:MEMBER {MEMBERNO:'+MEMBERNO+'})
CREATE (m)-[r:is_conductor_of]->(c);'
FROM ConductorOfChoir

SELECT * FROM ConductorOfChoir

SELECT
'MATCH (c:TOWN {TownName:"'+TownName+'"}),
(m:MEMBER {MEMBERNO:'+MEMBERNO+'})
CREATE (m)-[r:lives_in]->(c);'
FROM MEMBER

SELECT * FROM MEMBER

SELECT
'MATCH (c:VOCALRANGE {RangeName:"'+RangeName+'"}),
(m:MEMBER {MEMBERNO:'+MEMBERNO+'})
CREATE (m)-[r:is]->(c);'
FROM MEMBER

SELECT
'MATCH (c:WORK {Title:"'+ Title +'"}),
(m:MEMBER {MEMBERNO:'+MEMBERNO+'})
CREATE (m)-[r:conducted_work]->(c);'
FROM ConductorForWork

SELECT * FROM ConductorForWork

SELECT
'MATCH (c:CONCERT {PerformanceDate:"'+PerformanceDate+'"}),
(m:MEMBER {MEMBERNO:'+MEMBERNO+'})
CREATE (m)-[r:took_part_in]->(c);'
FROM MemberInConcert

SELECT * FROM MemberInConcert


SELECT
'MATCH (c:WORK {Title:"'+ Title +'"}),
(m:VOCALRANGE {RangeName:"'+RangeName+'"})
CREATE (m)-[r:is_required_to_perform {VocRangeNumRequired:'+VocRangeNumRequired+'}]->(c);'
FROM VOCALRANGE_IN_WORK

SELECT
'MATCH (c:WORK {Title:"'+ Title +'"}),
(m:COMPOSESR {Surname:"'+ SURNAME +'", Initials:"'+INITIALS+'"})
CREATE (m)-[r:composed]->(c);'
FROM WORK

SELECT
'MATCH (c:WORK {Title:"'+ Title +'"}),
(m:CONCERT {PerformanceDate:"'+ PerformanceDate +'"})
CREATE (c)-[r:was_performed_in{SeqNo:'+SeqNo+'}]->(m);'
FROM PROGRAM

SELECT
'MATCH (c:Choir {ChoirName:"'+CHOIRNAME+'"}),
(m:CONCERT {PerformanceDate:"'+PerformanceDate+'"})
CREATE (c)-[r:in]->(m);'
FROM CONCERT

SELECT
'MATCH (c:TOWN {TownName:"'+TownName+'"}),
(m:VENUE {VenueName:"'+VenueName+'"})
CREATE (m)-[r:is_located_in]->(c);'
FROM VENUE

SELECT
'MATCH (c:VENUE {VenueName:"'+VENUENAME+'"}),
(m:CONCERT {PerformanceDate:"'+PerformanceDate+'"})
CREATE (m)-[r:was_held_at]->(c);'
FROM CONCERT

SELECT * FROM CONCERT
SELECT * FROM VENUE
SELECT * FROM TOWN
SELECT * FROM MEMBER

SELECT
'MATCH (c:WORK {Title:"'+ Title +'"}),
(m:COMPOSER {Surname:"'+ SURNAME +'", Initials:"'+INITIALS+'"})
CREATE (m)-[r:composed]->(c);'
FROM WORK

SELECT * FROM WORK



