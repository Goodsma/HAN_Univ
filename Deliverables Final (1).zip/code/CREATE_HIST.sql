USE SUPERCINEMA
GO

DROP PROC IF EXISTS PROC_CREATE_HIST_TABLE
GO

-- Procedure generates a history table
CREATE PROC PROC_CREATE_HIST_TABLE @tablename nvarchar(128), @Output NVARCHAR(MAX) OUTPUT
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint
            DECLARE @Script NVARCHAR(MAX) = 'CREATE TABLE HIST_' + @tablename;
            SET @Script = @Script + ' (DATE_OF_CHANGE datetime default GETDATE(), '
            SELECT @Script = @Script + COLUMN_NAME + ' ' + DATA_TYPE + (CASE DATA_TYPE
                                                                            WHEN 'numeric' THEN '(' +
                                                                                                CAST(NUMERIC_PRECISION AS VARCHAR(2)) +
                                                                                                ',' +
                                                                                                CAST(NUMERIC_SCALE AS VARCHAR(2)) +
                                                                                                ')'
                                                                            WHEN 'varchar'
                                                                                THEN '(' + CAST(CHARACTER_MAXIMUM_LENGTH AS VARCHAR(2)) + ')'
                                                                            WHEN 'char'
                                                                                THEN '(' + CAST(CHARACTER_MAXIMUM_LENGTH AS VARCHAR(3)) + ')'
                                                                            ELSE '' END) + ', '
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME = @tablename

            DECLARE @Key NVARCHAR(MAX) = 'CONSTRAINT pk_hist_' + @tablename + ' PRIMARY KEY (DATE_OF_CHANGE'
            SELECT @Key = @Key + ', ' + COLUMN_NAME
            FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
            WHERE CONSTRAINT_NAME IN (SELECT CONSTRAINT_NAME
                                      FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
                                      WHERE CONSTRAINT_TYPE = 'PRIMARY KEY'
                                        AND TABLE_NAME = @tablename)

            SELECT @Output = @Script + @Key + '))'
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        THROW 50001, 'Something went wrong in PROC_CREATE_HIST_TABLE', 1
    END CATCH
END
GO

DROP PROC IF EXISTS PROC_CREATE_HIST_TRIGGER
GO

-- Procedure generates a trigger that inserts into the history table
CREATE PROC PROC_CREATE_HIST_TRIGGER @tablename nvarchar(128), @Output NVARCHAR(MAX) OUTPUT
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint
            DECLARE @Columns NVARCHAR(MAX) = ''

            SELECT @Columns = @Columns + COLUMN_NAME + ', '
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME = @tablename
            SELECT @Columns = LEFT(@Columns, LEN(@Columns) - 1)
            DECLARE @Script NVARCHAR(MAX) = 'CREATE TRIGGER TRG_' + @tablename + '_FILLHISTORY
ON [' + @tablename + ']
AFTER DELETE, UPDATE, INSERT
AS
BEGIN
  IF @@ROWCOUNT = 0 RETURN
  SET NOCOUNT ON
  BEGIN TRY
		IF EXISTS (SELECT * FROM inserted) AND NOT EXISTS (SELECT * FROM deleted)
			INSERT INTO HIST_' + @tablename + ' (' + @Columns + ') SELECT ' + @Columns + ' FROM inserted
		ELSE
			INSERT INTO HIST_' + @tablename + ' (' + @Columns + ') SELECT ' + @Columns + ' FROM deleted
  END TRY
  BEGIN CATCH
    ;THROW
  END CATCH
END'

            SELECT @Output = @Script
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        THROW 50002, 'Something went wrong in PROC_CREATE_HIST_TRIGGER', 1
    END CATCH
END
GO

DROP PROC IF EXISTS PROC_CREATE_HIST
GO

-- Automates creation of history tables and triggers for all tables in the database
CREATE PROC PROC_CREATE_HIST
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint


            DECLARE @Script nvarchar(MAX)
            DECLARE @table nvarchar(128)
            DECLARE @getid cursor

            SET @getid = CURSOR FOR SELECT DISTINCT TABLE_NAME
                                    FROM INFORMATION_SCHEMA.TABLES
                                    WHERE TABLE_NAME NOT LIKE 'HIST_%'
                                      AND (TABLE_NAME LIKE '%VOUCHER%' OR TABLE_NAME = 'BALANCE')

            OPEN @getid
            FETCH NEXT
                FROM @getid INTO @table
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    EXEC PROC_CREATE_HIST_TRIGGER @tablename = @table, @Output = @Script OUTPUT
                    EXEC (@Script)
                    EXEC PROC_CREATE_HIST_TABLE @tablename = @table, @Output = @Script OUTPUT
                    EXEC (@Script)
                    FETCH NEXT
                        FROM @getid INTO @table
                END

            CLOSE @getid
            DEALLOCATE @getid
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        THROW
    END CATCH
END
GO

EXEC PROC_CREATE_HIST
