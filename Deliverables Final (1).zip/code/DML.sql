-- noinspection SqlWithoutWhereForFile

USE SUPERCINEMA
GO

DELETE
FROM SCANNED_BY
DELETE
FROM RETURNED_VOUCHER
DELETE
FROM PRODUCT_ON_VOUCHER
UPDATE VOUCHER
SET REPRINT_OF = NULL
DELETE
FROM BLOCKED_VOUCHER
DELETE
FROM VOUCHER
DELETE
FROM EXCHANGED_FOR
DELETE
FROM PRODUCT
DELETE
FROM VOUCHER_TYPE
DELETE
FROM POINT_OF_SALE
DELETE
FROM "ORDER"
DELETE
FROM HAS_A_ROLE_OF
DELETE
FROM EMPLOYEE
DELETE
FROM ROLE
GO

SET IDENTITY_INSERT EMPLOYEE ON

INSERT INTO EMPLOYEE (Employee_Number)
VALUES (1),
       (2),
       (3),
       (4),
       (5),
       (6),
       (7),
       (8),
       (9),
       (10),
       (11),
       (12)
GO

SET IDENTITY_INSERT EMPLOYEE OFF

INSERT INTO ROLE (ROLE)
VALUES ('Usher'),
       ('Manager'),
       ('Cashier'),
       ('Office Employee')
GO

INSERT INTO HAS_A_ROLE_OF (EMPLOYEE_NUMBER, ROLE)
VALUES (1, 'Usher'),
       (2, 'Manager'),
       (3, 'Usher'),
       (4, 'Manager'),
       (5, 'Cashier'),
       (6, 'Usher'),
       (7, 'Cashier'),
       (8, 'Usher'),
       (9, 'Usher'),
       (10, 'Cashier'),
       (11, 'Office Employee'),
       (12, 'Office Employee')
GO

INSERT INTO POINT_OF_SALE (SHOP_NAME)
VALUES ('Super Cinema''s Arnhem Stationslaan'),
       ('Super Cinema''s Arnhem Ruitenberglaan'),
       ('Super Cinema''s Nijmegen'),
       ('Albert Heijn Arnhem '),
       ('Lidl Utrecht Smaragdplein'),
       ('Lidl Utrecht Vleuterweide')
GO

INSERT INTO VOUCHER_TYPE (VOUCHER_TYPE)
VALUES ('Marvel the Avengers: Infinity War ticket'),
       ('Frozen 2 ticket'),
       ('Maleficent 2 ticket with Coca Cola 500ml and medium popcorn salt'),
       ('Frozen 2 ticket with drink balance and non-specific snack'),
       ('Marvel the Avengers: Infinity War ticket with drink/snack balance'),
       ('After ticket and non-specific ticket'),
       ('Drink balance and snack balance'),
       ('Non-specific drink and non-specific snack')
GO

INSERT INTO PRODUCT (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
VALUES ('Marvel the Avengers: Infinity War', 'Ticket', 12.50),
       ('Frozen 2', 'Ticket', 10.00),
       ('Maleficent 2', 'Ticket', 11.50),
       ('After', 'Ticket', 12.00),
       ('Coca Cola 500ml', 'Drink', 5.00),
       ('Coca Cola 330ml', 'Drink', 4.00),
       ('Grolsch beugel', 'Drink', 5.00),
       ('Grolsch 300ml', 'Drink', 4.00),
       ('Small popcorn salt', 'Snack', 4.00),
       ('Medium popcorn salt', 'Snack', 4.50),
       ('Large popcorn salt', 'Snack', 5.00),
       ('Small popcorn sweet', 'Snack', 4.00),
       ('Medium popcorn sweet', 'Snack', 4.50),
       ('Large popcorn sweet', 'Snack', 5.00),
       ('Non-specific ticket', 'Ticket', 15.00),
       ('Non-specific drink', 'Drink', 5.50),
       ('Non-specific snack', 'Snack', 5.50),
       ('Drink_Balance', 'Balance', NULL),
       ('Snack_Balance', 'Balance', NULL),
       ('Ticket_Balance', 'Balance', NULL),
       ('Drink_and_Snack_Balance', 'Balance', NULL)
GO

INSERT INTO EXCHANGED_FOR (VOUCHER_TYPE, PRODUCT_NAME)
VALUES ('Marvel the Avengers: Infinity War ticket', 'Marvel the Avengers: Infinity War'),
       ('Frozen 2 ticket', 'Frozen 2'),
       ('Maleficent 2 ticket with Coca Cola 500ml and medium popcorn salt', 'Maleficent 2'),
       ('Maleficent 2 ticket with Coca Cola 500ml and medium popcorn salt', 'Coca Cola 500ml'),
       ('Maleficent 2 ticket with Coca Cola 500ml and medium popcorn salt', 'Medium popcorn salt'),
       ('Frozen 2 ticket with drink balance and non-specific snack', 'Frozen 2'),
       ('Frozen 2 ticket with drink balance and non-specific snack', 'Non-specific snack'),
       ('Marvel the Avengers: Infinity War ticket with drink/snack balance', 'Marvel the Avengers: Infinity War'),
       ('After ticket and non-specific ticket', 'After'),
       ('After ticket and non-specific ticket', 'Non-specific ticket'),
       ('Non-specific drink and non-specific snack', 'Non-specific drink'),
       ('Non-specific drink and non-specific snack', 'Non-specific snack')
GO

SET IDENTITY_INSERT "ORDER" ON

INSERT INTO "ORDER" (ORDER_NUMBER, CUSTOMER_EMAIL, ADDRESS, POSTAL_CODE, PERSONAL_MESSAGE, CONFIRMED_BY,
                     CONFIRMED_DATE_TIME, PRINTED_BY, PRINTED_DATE_TIME)
VALUES (1, 'melleeluc@gmail.com', 'Kon. Emmastraat 34', '7061XK', 'I would like to ask you to print this ASAP', 5,
        GETDATE(), 4, '2020-05-15 11:37:00'),
       (2, 'melleeluc@gmail.com', 'Kon. Emmastraat 34', '7061XK', 'I would like to ask you to print this ASAP', NULL,
        NULL, 4, '2020-05-15 11:37:00'),
       (3, 'melleeluc@gmail.com', 'Kon. Emmastraat 34', '7061XK', 'I would like to ask you to print this ASAP', NULL,
        NULL, NULL, NULL),
       (4, 'melleeluc@gmail.com', 'Kon. Emmastraat 34', '7061XK', 'I would like to ask you to print this ASAP', NULL,
        NULL, NULL, NULL),
       (5, 'melleeluc@gmail.com', 'Kon. Emmastraat 34', '7061XK', 'I would like to ask you to print this ASAP', NULL,
        NULL, 11, '2019-05-15 11:37:00'),
       (6, 'melleeluc@gmail.com', 'Kon. Emmastraat 34', '7061XK', 'I would like to ask you to print this ASAP', 12,
        GETDATE(), 11, '2019-05-15 11:37:00'),
       (7, 'melleeluc@gmail.com', 'Kon. Emmastraat 34', '7061XK', 'I would like to ask you to print this ASAP', NULL,
        NULL, NULL, NULL),
       (8, 'melleeluc@gmail.com', 'Kon. Emmastraat 34', '7061XK', 'I would like to ask you to print this ASAP', NULL,
        NULL, NULL, NULL),
       (9, 'melleeluc@gmail.com', 'Kon. Emmastraat 34', '7061XK', 'I would like to ask you to print this ASAP', NULL,
        NULL, NULL, NULL),
       (10, 'melleeluc@gmail.com', 'Kon. Emmastraat 34', '7061XK', 'I would like to ask you to print this ASAP', NULL,
        NULL, NULL, NULL)
GO

SET IDENTITY_INSERT "ORDER" OFF
SET IDENTITY_INSERT VOUCHER ON

INSERT INTO VOUCHER (VOUCHER_NUMBER, SHOP_NAME, VOUCHER_TYPE, PRINTED_BY, REPRINT_OF, PRINTED_DATE_TIME, STATUS,
                     SELLING_PRICE, ORDER_NUMBER)
VALUES (1, 'Super Cinema''s Arnhem Stationslaan', 'Drink balance and snack balance', 11, NULL, '2020-04-19 20:20:20',
        'Open', 30, 1),
       (2, 'Super Cinema''s Arnhem Ruitenberglaan', 'After ticket and non-specific ticket', NULL, NULL,
        '2020-02-20 20:02:20', 'Open', 47, 2),
       (3, 'Super Cinema''s Arnhem Stationslaan', 'Non-specific drink and non-specific snack', 11, NULL,
        '2020-04-16 19:18:17', 'Returned', 16.50, 3),
       (4, 'Super Cinema''s Nijmegen', 'Frozen 2 ticket', 2, NULL, '2020-04-19 20:20:20', 'Open', 50, 4),
       (5, 'Albert Heijn Arnhem', 'Marvel the Avengers: Infinity War ticket with drink/snack balance', 12, NULL,
        '2020-05-06 12:23:20', 'Used', 67.50, 5),
       (6, 'Lidl Utrecht Vleuterweide', 'Frozen 2 ticket with drink balance and non-specific snack', 7, NULL,
        '2020-03-03 11:33:59', 'Returned', 45, 6),
       (7, 'Lidl Utrecht VleuterWeide', 'Maleficent 2 ticket with Coca Cola 500ml and medium popcorn salt', 5, NULL,
        '2020-05-03 9:56:59', 'Open', 21, 7),
       (8, 'Lidl Utrecht Smaragdplein', 'Marvel the Avengers: Infinity War ticket', 5, NULL, '2020-05-03 7:20:59',
        'Blocked', 37.50, NULL),
       (9, 'Albert Heijn Arnhem', 'Frozen 2 ticket', 2, NULL, '2020-04-01 8:18:45', 'Used', 20, NULL),
       (10, 'Super Cinema''s Nijmegen', 'Non-specific drink and non-specific snack', 4, NULL, '2020-03-11 13:13:29 ',
        'Open', 38.50, NULL),
       (11, 'Super Cinema''s Arnhem Ruitenberglaan', 'Drink balance and snack balance', 10, NULL, '2020-03-14 12:36:55',
        'Open', 28, NULL),
       (12, 'Super Cinema''s Arnhem Ruitenberglaan', 'Frozen 2 ticket with drink balance and non-specific snack', 10,
        NULL, '2020-2-19 20:02:20', 'Blocked', 47, NULL),
       (13, 'Albert Heijn Arnhem', 'Marvel the Avengers: Infinity War ticket with drink/snack balance', 12, NULL,
        '2020-05-04 12:23:20', 'Blocked', 72, NULL)
GO

INSERT INTO BLOCKED_VOUCHER(VOUCHER_NUMBER, BLOCKED_BY)
VALUES (8, 5),
       (12, 11),
       (13, 12)
GO

-- noinspection SqlInsertIntoGeneratedColumn

INSERT INTO VOUCHER (VOUCHER_NUMBER, SHOP_NAME, VOUCHER_TYPE, REPRINT_OF, PRINTED_BY, PRINTED_DATE_TIME, STATUS,
                     SELLING_PRICE, ORDER_NUMBER)
VALUES (14, 'Lidl Utrecht Smaragdplein', 'Marvel the Avengers: Infinity War ticket', 8, 8, '2020-05-03 7:20:59', 'Open',
        12.50, NULL),
       (15, 'Lidl Utrecht Smaragdplein', 'Frozen 2 ticket with drink balance and non-specific snack', 12, 5,
        '2020-05-06 15:20:59', 'Open', 38, NULL),
       (16, 'Albert Heijn Arnhem', 'Marvel the Avengers: Infinity War ticket with drink/snack balance', NULL, NULL,
        '2020-05-04 12:23:20', 'Blocked', 72, 8),
       (17, 'Albert Heijn Arnhem', 'Marvel the Avengers: Infinity War ticket with drink/snack balance', NULL, NULL,
        '2020-05-04 12:23:20', 'Open', 72, 8),
       (18, 'Albert Heijn Arnhem', 'Marvel the Avengers: Infinity War ticket with drink/snack balance', NULL, NULL,
        '2020-05-04 12:23:20', 'Open', 72, 9),
       (19, 'Albert Heijn Arnhem', 'Marvel the Avengers: Infinity War ticket with drink/snack balance', NULL, NULL,
        '2020-05-04 12:23:20', 'Open', 72, 9),
       (20, 'Albert Heijn Arnhem', 'Marvel the Avengers: Infinity War ticket with drink/snack balance', NULL, NULL,
        '2020-05-04 12:23:20', 'Open', 72, 9),
       (21, 'Albert Heijn Arnhem', 'Marvel the Avengers: Infinity War ticket with drink/snack balance', NULL, NULL,
        '2020-05-04 12:23:20', 'Open', 72, 10),
       (22, 'Albert Heijn Arnhem', 'Marvel the Avengers: Infinity War ticket with drink/snack balance', NULL, NULL,
        '2020-05-04 12:23:20', 'Open', 72, 10)
GO

SET IDENTITY_INSERT VOUCHER OFF

INSERT INTO RETURNED_VOUCHER (VOUCHER_NUMBER, RETURNED_BY, RETURN_DATE_TIME)
VALUES (3, 11, '2020-04-16 21:18:17'),
       (6, 7, '2020-02-03 12:33:59')
GO

INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, QUANTITY)
VALUES (2, 'After', 3),
       (2, 'Non-specific drink', 2),
       (3, 'Non-specific snack', 2),
       (3, 'Non-specific drink', 1),
       (4, 'Frozen 2', 5),
       (5, 'Marvel the Avengers: Infinity War', 0),
       (6, 'Frozen 2', 1),
       (6, 'Non-specific snack', 2),
       (7, 'Maleficent 2', 1),
       (7, 'Coca Cola 500ml', 1),
       (7, 'Medium popcorn salt', 1),
       (8, 'Marvel the Avengers: Infinity War', 3),
       (9, 'Frozen 2', 0),
       (10, 'Non-specific snack', 3),
       (10, 'Non-specific drink', 4),
       (12, 'Frozen 2', 2),
       (13, 'Marvel the Avengers: Infinity War', 4),
       (14, 'Marvel the Avengers: Infinity War', 1),
       (15, 'Frozen 2', 2),
       (16, 'Marvel the Avengers: Infinity War', 2),
       (17, 'Marvel the Avengers: Infinity War', 1),
       (18, 'Marvel the Avengers: Infinity War', 1),
       (19, 'Marvel the Avengers: Infinity War', 1),
       (20, 'Marvel the Avengers: Infinity War', 1),
       (21, 'Marvel the Avengers: Infinity War', 1),
       (22, 'Marvel the Avengers: Infinity War', 1)
GO

INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, AMOUNT)
VALUES (1, 'Drink_Balance', 20),
       (1, 'Snack_Balance', 10),
       (5, 'Drink_and_Snack_Balance', 0),
       (6, 'Drink_Balance', 24),
       (11, 'Drink_Balance', 5),
       (11, 'Snack_Balance', 23),
       (12, 'Drink_Balance', 18),
       (13, 'Drink_and_Snack_Balance', 22),
       (15, 'Drink_Balance', 18),
       (16, 'Drink_and_Snack_Balance', 11),
       (17, 'Drink_and_Snack_Balance', 99),
       (18, 'Drink_and_Snack_Balance', 34),
       (19, 'Drink_and_Snack_Balance', 67),
       (20, 'Drink_and_Snack_Balance', 9),
       (21, 'Drink_and_Snack_Balance', 15),
       (22, 'Drink_and_Snack_Balance', 87)
GO

INSERT INTO SCANNED_BY (VOUCHER_NUMBER, PRODUCT_NAME, SCANNED_BY, SCANNED_TIME, SCANNED_LOCATION)
VALUES (5, 'Drink_and_Snack_Balance', 1, '2020-06-03 14:50:31', 'SuperCinema''s Nijmegen'),
       (5, 'Marvel the Avengers: Infinity War', 1, '2020-06-03 14:52:31', 'SuperCinema''s Nijmegen'),
       (5, 'Drink_and_Snack_Balance', 3, '2020-06-04 19:49:43', 'SuperCinema''s Arnhem'),
       (9, 'Frozen 2', 3, '2020-06-04 19:40:43', 'SuperCinema''s Arnhem'),
       (9, 'Frozen 2', 3, '2020-06-04 19:41:06', 'SuperCinema''s Arnhem'),
       (11, 'Drink_Balance', 6, '2020-06-04 19:41:06', 'SuperCinema''s Arnhem')
