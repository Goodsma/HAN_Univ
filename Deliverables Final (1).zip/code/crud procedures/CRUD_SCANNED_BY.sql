USE SUPERCINEMA

/* =======================================
    Procedure name: SP_READ_SCANNED_BY
    For roles: MANAGER_ROLE, OFFICE_EMP_ROLE, FINANCE_DEPT_ROLE
========================================== */
DROP PROC IF EXISTS SP_READ_SCANNED_BY
GO

CREATE PROC SP_READ_SCANNED_BY
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint
            SELECT VOUCHER_NUMBER, PRODUCT_NAME, SCANNED_BY, SCANNED_TIME, SCANNED_LOCATION
            FROM SCANNED_BY
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO

/* =======================================
    Procedure name: SP_INSERT_SCANNED_BY
    For roles: USHER_ROLE, CASHIER_ROLE, MANAGER_ROLE
========================================== */
DROP PROC IF EXISTS SP_INSERT_SCANNED_BY
GO

CREATE PROC SP_INSERT_SCANNED_BY @voucherNumber INT,
                                 @productName VARCHAR(256),
                                 @scannedBy INT,
                                 @scannedLocation VARCHAR(256)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint
            IF @voucherNumber IS NULL OR @productName IS NULL OR @scannedBy IS NULL OR @scannedLocation IS NULL
                BEGIN
                    THROW 50001, 'Voucher Type was a NULL value, which is not allowed.', 1
                END
            ELSE
                INSERT INTO SCANNED_BY (VOUCHER_NUMBER, PRODUCT_NAME, SCANNED_BY, SCANNED_TIME, SCANNED_LOCATION)
                VALUES (@voucherNumber, @productName, @scannedBy, GETDATE(), @scannedLocation)
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO

