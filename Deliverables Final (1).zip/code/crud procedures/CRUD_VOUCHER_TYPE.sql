USE SUPERCINEMA
GO

/* ================================================================
    Procedure name: SP_READ_VOUCHER_TYPE
    For roles: CUSTOMER_USER, USHER_ROLE, CASHIER_ROLE, MANAGER_ROLE, OFFICE_EMP_ROLE, FINANCE_DEPT_ROLE
=================================================================== */
DROP PROC IF EXISTS SP_READ_VOUCHER_TYPE
GO

CREATE PROC SP_READ_VOUCHER_TYPE
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint
            SELECT VOUCHER_TYPE
            FROM VOUCHER_TYPE
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO

/* ================================================================
    Procedure name: SP_CREATE_VOUCHER_TYPE
    For roles: MANAGER_ROLE
=================================================================== */
DROP PROC IF EXISTS SP_CREATE_VOUCHER_TYPE
GO

CREATE PROC SP_CREATE_VOUCHER_TYPE @voucher_type varchar(256)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint

            IF (@voucher_type IS NULL)
                BEGIN
                    THROW 51000, 'Parameters can not be null. Enter valid values.', 1
                END

            INSERT INTO VOUCHER_TYPE(VOUCHER_TYPE)
            VALUES (@voucher_type)
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO

/* ================================================================
    Procedure name: SP_DELETE_VOUCHER_TYPE
    For roles: MANAGER_ROLE
=================================================================== */
DROP PROC IF EXISTS SP_DELETE_VOUCHER_TYPE
GO

CREATE PROC SP_DELETE_VOUCHER_TYPE @voucher_type varchar(256)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint

            IF (@voucher_type IS NULL)
                BEGIN
                    THROW 51000, 'Parameters can not be null. Enter valid values.', 1
                END

            DELETE
            FROM VOUCHER_TYPE
            WHERE VOUCHER_TYPE = @voucher_type
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO

/* ================================================================
    Procedure name: SP_UPDATE_VOUCHER_TYPE
    For roles: MANAGER_ROLE
=================================================================== */
DROP PROC IF EXISTS SP_UPDATE_VOUCHER_TYPE
GO

CREATE PROC SP_UPDATE_VOUCHER_TYPE @new_voucher_type varchar(256),
                                   @old_voucher_type varchar(256)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint

            IF (@new_voucher_type IS NULL OR @old_voucher_type IS NULL)
                BEGIN
                    THROW 51000, 'Parameters can not be null. Enter valid values.', 1
                END

            IF (EXISTS(SELECT VOUCHER_TYPE
                       FROM VOUCHER_TYPE
                       WHERE VOUCHER_TYPE = @old_voucher_type)
                )
                UPDATE VOUCHER_TYPE
                SET VOUCHER_TYPE = @new_voucher_type
                WHERE VOUCHER_TYPE = @old_voucher_type

            ELSE
                BEGIN
                    THROW 51000, 'This voucher type does not exist', 1
                END
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO