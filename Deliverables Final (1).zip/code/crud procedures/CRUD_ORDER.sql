USE SUPERCINEMA

/* =======================================
    Procedure name: SP_READ_ORDER_CUSTOMER
    For roles: CUSTOMER_ROLE
========================================== */
DROP PROC IF EXISTS SP_READ_ORDER_CUSTOMER
GO

CREATE PROC SP_READ_ORDER_CUSTOMER
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint
            SELECT ORDER_NUMBER, ADDRESS, POSTAL_CODE, CUSTOMER_EMAIL, PERSONAL_MESSAGE
            FROM [ORDER]
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO


/* =======================================
    Procedure name: SP_READ_ALL_OF_ORDER
    For roles: CASHIER_ROLE, MANAGER_ROLE, OFFICE_EMPLOYEE
========================================== */
DROP PROC IF EXISTS SP_READ_ALL_OF_ORDER
GO

CREATE PROC SP_READ_ALL_OF_ORDER
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint
            SELECT ORDER_NUMBER,
                   CUSTOMER_EMAIL,
                   ADDRESS,
                   POSTAL_CODE,
                   PERSONAL_MESSAGE,
                   CONFIRMED_BY,
                   CONFIRMED_DATE_TIME,
                   PRINTED_BY,
                   PRINTED_DATE_TIME
            FROM [ORDER]
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO

/* =======================================
    Procedure name: SP_READ_ORDER_FINANCE_DEPT
    For roles: FINANCE_DEPT_ROLE
========================================== */
DROP PROC IF EXISTS SP_READ_ORDER_FINANCE_DEPT
GO

CREATE PROC SP_READ_ORDER_FINANCE_DEPT
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint
            SELECT ORDER_NUMBER, PERSONAL_MESSAGE, PRINTED_DATE_TIME, CONFIRMED_DATE_TIME, CONFIRMED_BY, PRINTED_BY
            FROM [ORDER]
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO


/* =======================================
    Procedure name: SP_CREATE_ORDER
    For roles: CUSTOMER_ROLE
========================================== */
DROP PROC IF EXISTS SP_CREATE_ORDER
GO

CREATE PROC SP_CREATE_ORDER @Address VARCHAR(256),
                            @Postal_Code VARCHAR(256),
                            @Customer_Email VARCHAR(256),
                            @Personal_Message VARCHAR(256) = NULL
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint

            IF @Address IS NULL OR @Postal_Code IS NULL OR @Customer_Email IS NULL
                BEGIN
                    THROW 52005, 'Parameters can not be null. Enter valid values.', 1
                END

            INSERT INTO [ORDER] (ADDRESS, POSTAL_CODE, CUSTOMER_EMAIL, PERSONAL_MESSAGE)
            VALUES (@Address, @Postal_Code, @Customer_Email, @Personal_Message)
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO


/* =======================================
    Procedure name: SP_PRINT_ORDER
    For roles: CASHIER_ROLE, MANAGER_ROLE, OFFICE_EMP_ROLE
========================================== */
DROP PROC IF EXISTS SP_PRINT_ORDER
GO

CREATE PROC SP_PRINT_ORDER @Order_Number INT,
                           @Employee_Number INT
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint

            IF @Order_Number IS NULL OR @Employee_Number IS NULL
                BEGIN
                    THROW 52006, 'The parameters can not be null. Enter a valid value.', 1
                END

            IF NOT EXISTS(SELECT * FROM [ORDER] WHERE ORDER_NUMBER = @Order_Number)
                BEGIN
                    DECLARE @message VARCHAR(255)
                    SET @message = CONCAT('Order with order number ', @Order_Number, ' does not exist.');
                    THROW 50037, @message, 1
                END

            IF EXISTS (SELECT 1 FROM [ORDER] WHERE ORDER_NUMBER = @Order_Number AND PRINTED_BY IS NOT NULL)
                BEGIN
                    THROW 52017, 'This Order is already PRINTED', 1
                END

            DECLARE @insertedOrderNumber TABLE
                                           (
                                               ORDER_NUMBER_INSERTED INTEGER
                                           )

            UPDATE [ORDER]
            SET PRINTED_BY = @Employee_Number,
                PRINTED_DATE_TIME = GETDATE()
            OUTPUT inserted.ORDER_NUMBER INTO @insertedOrderNumber
            WHERE ORDER_NUMBER = @Order_Number and PRINTED_DATE_TIME IS NULL

            IF (SELECT count(*) FROM @insertedOrderNumber) = 0
                BEGIN
                    THROW 52017, 'This Order is already PRINTED', 1
                END

        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO


/* =======================================
    Procedure name: SP_CONFIRM_PRINTING
    For roles: CASHIER_ROLE, MANAGER_ROLE, OFFICE_EMP_ROLE
========================================== */
DROP PROC IF EXISTS SP_CONFIRM_PRINTING
GO

CREATE PROC SP_CONFIRM_PRINTING @Order_Number INT,
                                @Employee_Number INT
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint

            IF @Order_Number IS NULL OR @Employee_Number IS NULL
                BEGIN
                    THROW 52006, 'The parameters can not be null. Enter a valid value.', 1
                END

            IF NOT EXISTS(SELECT 1 FROM [ORDER] WHERE ORDER_NUMBER = @Order_Number)
                BEGIN
                    DECLARE @message VARCHAR(255)
                    SET @message = CONCAT('Order with order number ', @Order_Number, ' does not exist.');
                    THROW 50037, @message, 1
                END

            IF EXISTS (SELECT 1 FROM [ORDER] WHERE ORDER_NUMBER = @Order_Number AND CONFIRMED_BY IS NOT NULL)
                BEGIN
                    THROW 52027, 'This Order is already CONFIRMED', 1
                END

            IF (SELECT PRINTED_BY FROM [ORDER] WHERE ORDER_NUMBER = @Order_Number) IS NULL
                BEGIN
                    THROW 52018, 'This Order is not yet printed', 1
                END

            DECLARE @insertedOrderNumber TABLE
                                           (
                                               ORDER_NUMBER_INSERTED INTEGER
                                           )

            UPDATE [ORDER]
            SET CONFIRMED_BY = @Employee_Number,
                CONFIRMED_DATE_TIME = GETDATE()
            OUTPUT inserted.ORDER_NUMBER INTO @insertedOrderNumber
            WHERE ORDER_NUMBER = @Order_Number and CONFIRMED_DATE_TIME IS NULL

            IF (SELECT count(*) FROM @insertedOrderNumber) = 0
                BEGIN
                    THROW 52027, 'This Order is already CONFIRMED', 1
                END

        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO