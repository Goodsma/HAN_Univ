/* ================================================================
    Procedure name: SP_READ_VOUCHER_FOR_CASHIER
    For roles: CASHIER_ROLE
=================================================================== */
DROP PROC IF EXISTS SP_READ_VOUCHER_FOR_CASHIER
GO

CREATE PROC SP_READ_VOUCHER_FOR_CASHIER
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint
            SELECT VOUCHER_NUMBER, STATUS, SELLING_PRICE, VOUCHER_TYPE, PRINTED_BY
            FROM VOUCHER
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO

/* ================================================================
    Procedure name: SP_READ_VOUCHER_FOR_USHER
    For roles: USHER_ROLE
=================================================================== */
DROP PROC IF EXISTS SP_READ_VOUCHER_FOR_USHER
GO

CREATE PROC SP_READ_VOUCHER_FOR_USHER
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint
            SELECT VOUCHER_NUMBER, STATUS, VOUCHER_TYPE, PRINTED_BY
            FROM VOUCHER
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO

/* ================================================================
    Procedure name: SP_READ_ALL_OF_VOUCHER
    For roles: MANAGER_ROLE, OFFICE_EMP_ROLE and FINANCE_DEPT_ROLE
=================================================================== */
DROP PROC IF EXISTS SP_READ_ALL_OF_VOUCHER
GO

CREATE PROC SP_READ_ALL_OF_VOUCHER
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint
            SELECT VOUCHER_NUMBER,
                   SHOP_NAME,
                   VOUCHER_TYPE,
                   REPRINT_OF,
                   PRINTED_BY,
                   PRINTED_DATE_TIME,
                   ORDER_NUMBER,
                   STATUS,
                   SELLING_PRICE
            FROM VOUCHER
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO

/* ================================================================
    Procedure name: SP_PRINT_VOUCHER
    For roles: CASHIER_ROLE, MANAGER_ROLE, OFFICE_EMP_ROLE
=================================================================== */
DROP PROC IF EXISTS SP_PRINT_VOUCHER
GO

CREATE PROC SP_PRINT_VOUCHER @voucherNumber INT, @empNumber INT
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
        BEGIN TRAN
            SAVE TRAN @savepoint
            IF @voucherNumber IS NULL OR @empNumber IS NULL
                BEGIN
                    THROW 50001, 'Voucher number or Employee number was a NULL value, which is not allowed.', 1
                END
            ELSE
                BEGIN
                    DECLARE @message VARCHAR(255)
                    IF EXISTS(SELECT 1 FROM VOUCHER WHERE VOUCHER_NUMBER = @voucherNumber)
                        BEGIN
                            IF NOT EXISTS(
                                    SELECT 1
                                    FROM VOUCHER
                                    WHERE VOUCHER_NUMBER = @voucherNumber
                                      AND PRINTED_BY IS NOT NULL)
                                BEGIN
                                    UPDATE VOUCHER
                                    SET PRINTED_DATE_TIME = GETDATE(),
                                        PRINTED_BY        = @empNumber
                                    WHERE VOUCHER_NUMBER = @voucherNumber
                                END
                            ELSE
                                BEGIN
                                    SET @message =
                                            CONCAT('Voucher with voucher number ', @voucherNumber,
                                                   ' was already printed.');
                                    THROW 50001, @message, 1
                                END
                        END
                    ELSE
                        BEGIN
                            SET @message =
                                    CONCAT('Voucher with voucher number ', @voucherNumber, ' does not exist.');
                            THROW 50001, @message, 1
                        END
                END
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO

/* ================================================================
    Procedure name: SP_CREATE_VOUCHER
    For roles: CASHIER_ROLE, MANAGER_ROLE, OFFICE_EMP_ROLE
=================================================================== */
DROP PROC IF EXISTS SP_CREATE_VOUCHER
GO

CREATE PROC SP_CREATE_VOUCHER @voucherType VARCHAR(256), @shopName VARCHAR(256) = NULL, @reprintOf INT = NULL
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint
            IF @voucherType IS NULL
                BEGIN
                    THROW 50001, 'Voucher Type was a NULL value, which is not allowed.', 1
                END
            ELSE
                BEGIN
                    DECLARE @insertedVoucherNumber TABLE
                                                   (
                                                       VOUCHER_NUMBER INTEGER
                                                   )
                    DECLARE @voucherNumber INT

                    INSERT INTO VOUCHER (VOUCHER_TYPE, SHOP_NAME, REPRINT_OF, STATUS, SELLING_PRICE)
                    OUTPUT inserted.VOUCHER_NUMBER INTO @insertedVoucherNumber
                    VALUES (@voucherType, @shopName, @reprintOf, 'Open', 0)

                    SELECT @voucherNumber = VOUCHER_NUMBER
                    FROM @insertedVoucherNumber

                    IF @voucherNumber IS NULL
                        BEGIN
                            THROW 50001, 'Voucher Number resulted in NULL suggesting the insert might have failed.', 1
                        END
                    ELSE
                        BEGIN
                            EXEC SP_ADD_PRODUCTS_TO_VOUCHER @voucherNumber, @voucherType
                        END
                END
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO

-- Add products procedure
DROP PROC IF EXISTS SP_ADD_PRODUCTS_TO_VOUCHER
GO

CREATE PROC SP_ADD_PRODUCTS_TO_VOUCHER @voucherNumber INT, @voucherType VARCHAR(256)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint
            IF @voucherNumber IS NULL OR @voucherType IS NULL
                BEGIN
                    THROW 50001, 'One of the provided parameters contained a NULL value, which is not allowed.', 1
                END
            ELSE
                BEGIN
                    DECLARE @checkSum INT
                    SELECT @checkSum = COUNT(VOUCHER_TYPE) FROM EXCHANGED_FOR WHERE VOUCHER_TYPE = @voucherType

                    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, QUANTITY, AMOUNT)
                    SELECT @voucherNumber,
                           EF.PRODUCT_NAME,
                           (CASE
                                WHEN (SELECT PRICE FROM PRODUCT P WHERE P.PRODUCT_NAME = EF.PRODUCT_NAME) IS NOT NULL
                                    THEN 0
                                ELSE NULL END),
                           (CASE
                                WHEN (SELECT PRICE FROM PRODUCT P WHERE P.PRODUCT_NAME = EF.PRODUCT_NAME) IS NULL THEN 0
                                ELSE NULL END)
                    FROM EXCHANGED_FOR EF
                    WHERE VOUCHER_TYPE = @voucherType

                    IF (SELECT COUNT(VOUCHER_NUMBER) FROM PRODUCT_ON_VOUCHER WHERE VOUCHER_NUMBER = @voucherNumber) !=
                       @checkSum
                        BEGIN
                            THROW 50001, 'The count of products in PRODUCT_ON_VOUCHER does not match that of the count in EXCHANGED_FOR.', 1
                        END
                END
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO