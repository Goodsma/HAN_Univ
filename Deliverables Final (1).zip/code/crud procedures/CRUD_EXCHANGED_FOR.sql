USE SUPERCINEMA

/* =======================================
    Procedure name: SP_READ_EXCHANGED_FOR
    For roles: CUSTOMER_ROLE, USHER_ROLE, CASHIER_ROLE, MANAGER_ROLE, OFFICE_EMP_ROLE, FINANCE_DEPT_ROLE
========================================== */
DROP PROC IF EXISTS SP_READ_EXCHANGED_FOR
GO

CREATE PROC SP_READ_EXCHANGED_FOR
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint

            SELECT VOUCHER_TYPE, PRODUCT_NAME
            FROM EXCHANGED_FOR
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO


/* =======================================
    Procedure name: SP_CREATE_EXCHANGED_FOR
    For roles: MANAGER_ROLE
========================================== */
DROP PROC IF EXISTS SP_CREATE_EXCHANGED_FOR
GO

CREATE PROC SP_CREATE_EXCHANGED_FOR @Voucher_Type VARCHAR(256),
                                    @Product_Name VARCHAR(256)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint

            IF @Voucher_Type IS NULL OR @Product_Name IS NULL
                BEGIN
                    THROW 52005, 'Parameters can not be null. Enter valid values.', 1
                END

            INSERT INTO EXCHANGED_FOR (VOUCHER_TYPE, PRODUCT_NAME)
            VALUES (@Voucher_Type, @Product_Name)
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO

/* =======================================
    Procedure name: SP_UPDATE_EXCHANGED_FOR
    For roles: MANAGER_ROLE
========================================== */
DROP PROC IF EXISTS SP_UPDATE_EXCHANGED_FOR
GO

CREATE PROC SP_UPDATE_EXCHANGED_FOR @Voucher_Type VARCHAR(256),
                                    @Product_Name VARCHAR(256),
                                    @Voucher_Type_New VARCHAR(256) = NULL,
                                    @Product_Name_New VARCHAR(256) = NULL

AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint

            IF @Voucher_Type IS NULL OR @Product_Name IS NULL
                BEGIN
                    THROW 52006, 'The parameters (@Voucher_Type and @Product_Name) can not be null. Enter a valid value.', 1
                END

            IF @Voucher_Type_New IS NULL AND @Product_Name_New IS NULL
                BEGIN
                    THROW 52026, 'The _New parameters (@Voucher_Type_New and @Product_Name_New) can not be null at the same time. Enter at least one valid _New value.', 1
                END

            IF @Voucher_Type_New IS NULL
                BEGIN
                    UPDATE EXCHANGED_FOR
                    SET PRODUCT_NAME = @Product_Name_New
                    WHERE VOUCHER_TYPE = @Voucher_Type
                    AND PRODUCT_NAME = @Product_Name
                END

            IF @Product_Name_New IS NULL
                BEGIN
                    UPDATE EXCHANGED_FOR
                    SET VOUCHER_TYPE = @Voucher_Type_New
                    WHERE VOUCHER_TYPE = @Voucher_Type
                    AND PRODUCT_NAME = @Product_Name
                END

            ELSE
                BEGIN
                    UPDATE EXCHANGED_FOR
                    SET VOUCHER_TYPE = @Voucher_Type_New,
                        PRODUCT_NAME = @Product_Name_New
                    WHERE VOUCHER_TYPE = @Voucher_Type
                    AND PRODUCT_NAME = @Product_Name
                END
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO

/* ================================================================
    Procedure name: SP_DELETE_EXCHANGED_FOR
    For roles: MANAGER_ROLE
=================================================================== */
DROP PROC IF EXISTS SP_DELETE_EXCHANGED_FOR
GO

CREATE PROC SP_DELETE_EXCHANGED_FOR @Voucher_Type VARCHAR(256),
                                    @Product_Name VARCHAR(256)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint

            IF @Voucher_Type IS NULL OR @Product_Name IS NULL
                BEGIN
                    THROW 51000, 'Parameters can not be null. Enter valid values.', 1
                END

            DELETE
            FROM EXCHANGED_FOR
            WHERE VOUCHER_TYPE = @Voucher_Type AND PRODUCT_NAME = @Product_Name
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO
