USE SUPERCINEMA
GO

/* ===================================
   Procedure name: SP_READ_POINT_OF_SALE
   For roles: MANAGER_ROLE, OFFICE_EMP_ROLE AND FINANCE_DEPT_ROLE
====================================== */
DROP PROC IF EXISTS SP_READ_POINT_OF_SALE
GO

CREATE PROC SP_READ_POINT_OF_SALE
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint
            SELECT SHOP_NAME
            FROM POINT_OF_SALE
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO
