USE SUPERCINEMA

/* =======================================
    Procedure name: SP_READ_PRODUCT_ON_VOUCHER
    For roles: USHER_ROLE, CASHIER_ROLE, MANAGER_ROLE, OFFICE_EMP_ROLE, FINANCE_DEPT_ROLE
========================================== */
DROP PROC IF EXISTS SP_READ_PRODUCT_ON_VOUCHER
GO

CREATE PROC SP_READ_PRODUCT_ON_VOUCHER
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint

            SELECT VOUCHER_NUMBER, PRODUCT_NAME, QUANTITY, AMOUNT
            FROM PRODUCT_ON_VOUCHER
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO

/* =======================================
    Procedure name: SP_UPDATE_POV_QUANTITY
    For roles: USHER_ROLE, CASHIER_ROLE, MANAGER_ROLE
========================================== */
DROP PROC IF EXISTS SP_UPDATE_POV_QUANTITY
GO

CREATE PROC SP_UPDATE_POV_QUANTITY @voucher_number INT,
                                   @product_name VARCHAR(256),
                                   @quantity INT = NULL,
                                   @scannedBy INTEGER,
                                   @scannedLocation VARCHAR(256)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint

            IF @voucher_number IS NULL OR @product_name IS NULL
                BEGIN
                    THROW 52006, 'The parameters can not be null. Enter a valid value.', 1
                END

            EXEC THROW_ERROR_WHEN_VOUCHER_IS_NOT_OPEN @voucher_number

            IF (@quantity IS NULL)
                BEGIN
                    EXEC SP_SCAN_PRODUCT_ON_VOUCHER @voucher_number, @product_name, @scannedBy, @scannedLocation
                END
            ELSE
                UPDATE PRODUCT_ON_VOUCHER
                SET AMOUNT = @quantity
                WHERE VOUCHER_NUMBER = @voucher_number
                  AND PRODUCT_NAME = @product_name
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO

/* =======================================
    Procedure name: SP_UPDATE_POV_AMOUNT
    For roles: USHER_ROLE, CASHIER_ROLE, MANAGER_ROLE
========================================== */
DROP PROC IF EXISTS SP_UPDATE_POV_AMOUNT
GO

CREATE PROC SP_UPDATE_POV_AMOUNT @voucher_number INT,
                                 @product_name VARCHAR(256),
                                 @amount NUMERIC(8,2),
                                 @scannedBy INT,
                                 @scannedLocation VARCHAR(256)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint

            IF @voucher_number IS NULL OR @product_name IS NULL OR @amount IS NULL
                BEGIN
                    THROW 52006, 'The parameters can not be null. Enter a valid value.', 1
                END

            EXEC THROW_ERROR_WHEN_VOUCHER_IS_NOT_OPEN @voucher_number

            IF (SELECT AMOUNT
                FROM PRODUCT_ON_VOUCHER
                WHERE VOUCHER_NUMBER = @voucher_number
                  AND PRODUCT_NAME = @product_name) = 0
                BEGIN
                    UPDATE PRODUCT_ON_VOUCHER
                    SET AMOUNT = @amount
                    WHERE VOUCHER_NUMBER = @voucher_number
                      AND PRODUCT_NAME = @product_name
                END
            ELSE
                EXEC SP_DECREASE_POV_BALANCE @voucher_number, @product_name, @amount, @scannedBy, @scannedLocation
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO