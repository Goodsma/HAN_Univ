--==============================================================
-- DBMS name:      ANSI Level 2
-- Created on:     2-6-2020 15:14:54
--==============================================================

USE MASTER
GO

DROP DATABASE IF EXISTS SUPERCINEMA
GO

CREATE DATABASE SUPERCINEMA
GO

USE SUPERCINEMA
GO

--==============================================================
-- Table: EMPLOYEE
--==============================================================
CREATE TABLE EMPLOYEE
(
    EMPLOYEE_NUMBER INTEGER NOT NULL IDENTITY,
    PRIMARY KEY (EMPLOYEE_NUMBER)
);

--==============================================================
-- Table: VOUCHER_TYPE
--==============================================================
CREATE TABLE VOUCHER_TYPE
(
    VOUCHER_TYPE VARCHAR(256) NOT NULL,
    PRIMARY KEY (VOUCHER_TYPE)
);

--==============================================================
-- Table: POINT_OF_SALE
--==============================================================
CREATE TABLE POINT_OF_SALE
(
    SHOP_NAME VARCHAR(256) NOT NULL,
    PRIMARY KEY (SHOP_NAME)
);

--==============================================================
-- Table: "ORDER"
--==============================================================
CREATE TABLE "ORDER"
(
    ORDER_NUMBER        INTEGER      NOT NULL IDENTITY,
    CUSTOMER_EMAIL      VARCHAR(256) NOT NULL,
    ADDRESS             VARCHAR(256) NOT NULL,
    POSTAL_CODE         VARCHAR(256) NOT NULL,
    PERSONAL_MESSAGE    VARCHAR(256),
    CONFIRMED_BY        INTEGER,
    CONFIRMED_DATE_TIME DATETIME,
    PRINTED_BY          INTEGER,
    PRINTED_DATE_TIME   DATETIME,
    PRIMARY KEY (ORDER_NUMBER),
    FOREIGN KEY (PRINTED_BY)
        REFERENCES EMPLOYEE (EMPLOYEE_NUMBER)
        ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (CONFIRMED_BY)
        REFERENCES EMPLOYEE (EMPLOYEE_NUMBER)
        ON UPDATE NO ACTION ON DELETE NO ACTION
);

--==============================================================
-- Table: VOUCHER
--==============================================================
CREATE TABLE VOUCHER
(
    VOUCHER_NUMBER    INTEGER       NOT NULL IDENTITY,
    SHOP_NAME         VARCHAR(256),
    VOUCHER_TYPE      VARCHAR(256)  NOT NULL,
    REPRINT_OF        INTEGER,
    PRINTED_BY        INTEGER,
    PRINTED_DATE_TIME DATETIME,
    ORDER_NUMBER      INTEGER,
    STATUS            VARCHAR(256)  NOT NULL,
    SELLING_PRICE     NUMERIC(8, 2) NOT NULL,
    PRIMARY KEY (VOUCHER_NUMBER),
    FOREIGN KEY (VOUCHER_TYPE)
        REFERENCES VOUCHER_TYPE (VOUCHER_TYPE)
        ON UPDATE CASCADE ON DELETE NO ACTION,
    FOREIGN KEY (SHOP_NAME)
        REFERENCES POINT_OF_SALE (SHOP_NAME)
        ON UPDATE CASCADE ON DELETE NO ACTION,
    FOREIGN KEY (ORDER_NUMBER)
        REFERENCES "ORDER" (ORDER_NUMBER)
        ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (PRINTED_BY)
        REFERENCES EMPLOYEE (EMPLOYEE_NUMBER)
        ON UPDATE NO ACTION ON DELETE NO ACTION
);

--==============================================================
-- Table: BLOCKED_VOUCHER
--==============================================================
CREATE TABLE BLOCKED_VOUCHER
(
    VOUCHER_NUMBER INTEGER NOT NULL,
    BLOCKED_BY     INTEGER NOT NULL,
    PRIMARY KEY (VOUCHER_NUMBER),
    FOREIGN KEY (BLOCKED_BY)
        REFERENCES EMPLOYEE (EMPLOYEE_NUMBER)
        ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (VOUCHER_NUMBER)
        REFERENCES VOUCHER (VOUCHER_NUMBER)
        ON UPDATE NO ACTION ON DELETE NO ACTION
);

--==============================================================
-- Index: BLOCKED_VOUCHER_PK
--==============================================================
CREATE UNIQUE INDEX BLOCKED_VOUCHER_PK ON BLOCKED_VOUCHER (
                                                           VOUCHER_NUMBER ASC
    );

--==============================================================
-- Index: BLOCKED_BY_FK
--==============================================================
CREATE INDEX BLOCKED_BY_FK ON BLOCKED_VOUCHER (
                                               BLOCKED_BY ASC
    );

--==============================================================
-- Index: EMPLOYEE_PK
--==============================================================
CREATE UNIQUE INDEX EMPLOYEE_PK ON EMPLOYEE (
                                             EMPLOYEE_NUMBER ASC
    );

--==============================================================
-- Table: PRODUCT
--==============================================================
CREATE TABLE PRODUCT
(
    PRODUCT_NAME VARCHAR(256) NOT NULL,
    PRODUCT_TYPE VARCHAR(256) NOT NULL,
    PRICE        NUMERIC(8, 2),
    PRIMARY KEY (PRODUCT_NAME)
);

--==============================================================
-- Table: EXCHANGED_FOR
--==============================================================
CREATE TABLE EXCHANGED_FOR
(
    VOUCHER_TYPE VARCHAR(256) NOT NULL,
    PRODUCT_NAME VARCHAR(256) NOT NULL,
    PRIMARY KEY (VOUCHER_TYPE, PRODUCT_NAME),
    FOREIGN KEY (VOUCHER_TYPE)
        REFERENCES VOUCHER_TYPE (VOUCHER_TYPE)
        ON UPDATE CASCADE ON DELETE NO ACTION,
    FOREIGN KEY (PRODUCT_NAME)
        REFERENCES PRODUCT (PRODUCT_NAME)
        ON UPDATE CASCADE ON DELETE NO ACTION
);

--==============================================================
-- Index: EXCHANGED_FOR_PK
--==============================================================
CREATE UNIQUE INDEX EXCHANGED_FOR_PK ON EXCHANGED_FOR (
                                                       VOUCHER_TYPE ASC,
                                                       PRODUCT_NAME ASC
    );

--==============================================================
-- Index: BOUGHT_WITH_FK
--==============================================================
CREATE INDEX BOUGHT_WITH_FK ON EXCHANGED_FOR (
                                              VOUCHER_TYPE ASC
    );

--==============================================================
-- Index: EXCHANGED_FOR_FK
--==============================================================
CREATE INDEX EXCHANGED_FOR_FK ON EXCHANGED_FOR (
                                                PRODUCT_NAME ASC
    );

--==============================================================
-- Table: ROLE
--==============================================================
CREATE TABLE ROLE
(
    ROLE VARCHAR(256) NOT NULL,
    PRIMARY KEY (ROLE)
);

--==============================================================
-- Table: HAS_A_ROLE_OF
--==============================================================
CREATE TABLE HAS_A_ROLE_OF
(
    EMPLOYEE_NUMBER INTEGER      NOT NULL,
    ROLE            VARCHAR(256) NOT NULL,
    PRIMARY KEY (EMPLOYEE_NUMBER, ROLE),
    FOREIGN KEY (EMPLOYEE_NUMBER)
        REFERENCES EMPLOYEE (EMPLOYEE_NUMBER)
        ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (ROLE)
        REFERENCES ROLE (ROLE)
        ON UPDATE CASCADE ON DELETE NO ACTION
);

--==============================================================
-- Index: HAS_A_ROLE_OF_PK
--==============================================================
CREATE UNIQUE INDEX HAS_A_ROLE_OF_PK ON HAS_A_ROLE_OF (
                                                       EMPLOYEE_NUMBER ASC,
                                                       ROLE ASC
    );

--==============================================================
-- Index: HAS_FK
--==============================================================
CREATE INDEX HAS_FK ON HAS_A_ROLE_OF (
                                      EMPLOYEE_NUMBER ASC
    );

--==============================================================
-- Index: HAS_A_FK
--==============================================================
CREATE INDEX HAS_A_FK ON HAS_A_ROLE_OF (
                                        ROLE ASC
    );

--==============================================================
-- Index: ORDER_PK
--==============================================================
CREATE UNIQUE INDEX ORDER_PK ON "ORDER" (
                                         ORDER_NUMBER ASC
    );

--==============================================================
-- Index: PRINTED_BY_FK
--==============================================================
CREATE INDEX PRINTED_BY_FK ON "ORDER" (
                                       PRINTED_BY ASC
    );

--==============================================================
-- Index: CONFIRMED_BY_FK
--==============================================================
CREATE INDEX CONFIRMED_BY_FK ON "ORDER" (
                                         CONFIRMED_BY ASC
    );

--==============================================================
-- Index: POINT_OF_SALE_PK
--==============================================================
CREATE UNIQUE INDEX POINT_OF_SALE_PK ON POINT_OF_SALE (
                                                       SHOP_NAME ASC
    );

--==============================================================
-- Index: PRODUCT_PK
--==============================================================
CREATE UNIQUE INDEX PRODUCT_PK ON PRODUCT (
                                           PRODUCT_NAME ASC
    );

--==============================================================
-- Table: PRODUCT_ON_VOUCHER
--==============================================================
CREATE TABLE PRODUCT_ON_VOUCHER
(
    VOUCHER_NUMBER INTEGER      NOT NULL,
    PRODUCT_NAME   VARCHAR(256) NOT NULL,
    QUANTITY       INTEGER,
    AMOUNT   NUMERIC(8, 2),
    PRIMARY KEY (VOUCHER_NUMBER, PRODUCT_NAME),
    FOREIGN KEY (VOUCHER_NUMBER)
        REFERENCES VOUCHER (VOUCHER_NUMBER)
        ON UPDATE CASCADE ON DELETE NO ACTION,
    FOREIGN KEY (PRODUCT_NAME)
        REFERENCES PRODUCT (PRODUCT_NAME)
        ON UPDATE CASCADE ON DELETE NO ACTION
);

--==============================================================
-- Index: PRODUCT_ON_VOUCHER_PK
--==============================================================
CREATE UNIQUE INDEX PRODUCT_ON_VOUCHER_PK ON PRODUCT_ON_VOUCHER (
                                                                 VOUCHER_NUMBER ASC,
                                                                 PRODUCT_NAME ASC
    );

--==============================================================
-- Index: PRODUCTS_ON_VOUCHER_FK
--==============================================================
CREATE INDEX PRODUCTS_ON_VOUCHER_FK ON PRODUCT_ON_VOUCHER (
                                                           VOUCHER_NUMBER ASC
    );

--==============================================================
-- Index: IS_PRODUCT_OF_FK
--==============================================================
CREATE INDEX IS_PRODUCT_OF_FK ON PRODUCT_ON_VOUCHER (
                                                     PRODUCT_NAME ASC
    );

--==============================================================
-- Table: RETURNED_VOUCHER
--==============================================================
CREATE TABLE RETURNED_VOUCHER
(
    VOUCHER_NUMBER   INTEGER NOT NULL,
    RETURNED_BY      INTEGER NOT NULL,
    RETURN_DATE_TIME DATETIME    NOT NULL,
    PRIMARY KEY (VOUCHER_NUMBER),
    FOREIGN KEY (RETURNED_BY)
        REFERENCES EMPLOYEE (EMPLOYEE_NUMBER)
        ON UPDATE NO ACTION ON DELETE NO ACTION,
    FOREIGN KEY (VOUCHER_NUMBER)
        REFERENCES VOUCHER (VOUCHER_NUMBER)
        ON UPDATE NO ACTION ON DELETE NO ACTION
);

--==============================================================
-- Index: RETURNED_VOUCHER_PK
--==============================================================
CREATE UNIQUE INDEX RETURNED_VOUCHER_PK ON RETURNED_VOUCHER (
                                                             VOUCHER_NUMBER ASC
    );

--==============================================================
-- Index: RETURNED_BY_FK
--==============================================================
CREATE INDEX RETURNED_BY_FK ON RETURNED_VOUCHER (
                                                 RETURNED_BY ASC
    );

--==============================================================
-- Index: ROLE_PK
--==============================================================
CREATE UNIQUE INDEX ROLE_PK ON ROLE (
                                     ROLE ASC
    );

--==============================================================
-- Table: SCANNED_BY
--==============================================================
CREATE TABLE SCANNED_BY
(
    VOUCHER_NUMBER INTEGER      NOT NULL,
    PRODUCT_NAME   VARCHAR(256) NOT NULL,
    SCANNED_BY     INTEGER      NOT NULL,
    SCANNED_TIME   DATETIME         NOT NULL,
    SCANNED_LOCATION   VARCHAR(256) NOT NULL,
    PRIMARY KEY (VOUCHER_NUMBER, PRODUCT_NAME, SCANNED_BY, SCANNED_TIME),
    FOREIGN KEY (VOUCHER_NUMBER, PRODUCT_NAME)
        REFERENCES PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME)
        ON UPDATE CASCADE ON DELETE NO ACTION,
    FOREIGN KEY (SCANNED_BY)
        REFERENCES EMPLOYEE (EMPLOYEE_NUMBER)
        ON UPDATE NO ACTION ON DELETE NO ACTION
);

--==============================================================
-- Index: SCANNED_BY_PK
--==============================================================
CREATE UNIQUE INDEX SCANNED_BY_PK ON SCANNED_BY (
                                                 VOUCHER_NUMBER ASC,
                                                 PRODUCT_NAME ASC,
                                                 SCANNED_BY ASC,
                                                 SCANNED_TIME ASC
    );

--==============================================================
-- Index: SCANS_FK
--==============================================================
CREATE INDEX SCANS_FK ON SCANNED_BY (
                                     VOUCHER_NUMBER ASC,
                                     PRODUCT_NAME ASC
    );

--==============================================================
-- Index: SCANNED_BY_FK
--==============================================================
CREATE INDEX SCANNED_BY_FK ON SCANNED_BY (
                                          SCANNED_BY ASC
    );

--==============================================================
-- Index: VOUCHER_PK
--==============================================================
CREATE UNIQUE INDEX VOUCHER_PK ON VOUCHER (
                                           VOUCHER_NUMBER ASC
    );

--==============================================================
-- Index: HAS_A_TYPE_OF_FK
--==============================================================
CREATE INDEX HAS_A_TYPE_OF_FK ON VOUCHER (
                                          VOUCHER_TYPE ASC
    );

--==============================================================
-- Index: IS_BOUGHT_AT_FK
--==============================================================
CREATE INDEX IS_BOUGHT_AT_FK ON VOUCHER (
                                         SHOP_NAME ASC
    );

--==============================================================
-- Index: VOUCHER_ON_ORDER_FK
--==============================================================
CREATE INDEX VOUCHER_ON_ORDER_FK ON VOUCHER (
                                             ORDER_NUMBER ASC
    );

--==============================================================
-- Index: PRINT_BY_FK
--==============================================================
CREATE INDEX PRINT_BY_FK ON VOUCHER (
                                     PRINTED_BY ASC
    );

--==============================================================
-- Index: REPRINT_OF_FK
--==============================================================
CREATE INDEX REPRINT_OF_FK ON VOUCHER (
                                       REPRINT_OF ASC
    );

--==============================================================
-- Index: VOUCHER_TYPE_PK
--==============================================================
CREATE UNIQUE INDEX VOUCHER_TYPE_PK ON VOUCHER_TYPE (
                                                     VOUCHER_TYPE ASC
    );

--==============================================================
-- Foreign Key: REPRINT_OF_FK
--==============================================================
ALTER TABLE VOUCHER
    ADD CONSTRAINT REPRINT_OF_FK
        FOREIGN KEY (REPRINT_OF)
            REFERENCES BLOCKED_VOUCHER (VOUCHER_NUMBER)
            ON UPDATE NO ACTION ON DELETE NO ACTION