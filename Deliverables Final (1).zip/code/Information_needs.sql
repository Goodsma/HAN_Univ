USE SUPERCINEMA

-- Set Monday as first day of the week used for both information needs (default is Sunday).
SET DATEFIRST 1;

/* ====================================
  IN1 Making query for number of vouchers sold
======================================= */

--Query:
BEGIN TRAN
    INSERT INTO VOUCHER (SHOP_NAME, VOUCHER_TYPE, REPRINT_OF, PRINTED_BY, PRINTED_DATE_TIME, ORDER_NUMBER, STATUS,
                         SELLING_PRICE)
    VALUES (NULL, 'Frozen 2 ticket', NULL, 1, GETDATE() - 1, 1, 'Open', 12),
           (NULL, 'Frozen 2 ticket', NULL, 1, GETDATE() - 2, 1, 'Open', 12),
           (NULL, 'Frozen 2 ticket', NULL, 1, GETDATE() - 31, 1, 'Open', 12),
           (NULL, 'Frozen 2 ticket', NULL, 1, GETDATE(), 1, 'Open', 12),
           (NULL, 'Frozen 2 ticket', NULL, 1, GETDATE() - 300, 1, 'Open', 12)

    SELECT * FROM VOUCHER

    SELECT 'Year'  = (SELECT COUNT(*)
                      FROM VOUCHER
                      WHERE DATEPART(YEAR, PRINTED_DATE_TIME) = DATEPART(YEAR, GETDATE() - 1)
                        AND PRINTED_DATE_TIME <= GETDATE() - 1
                        AND REPRINT_OF IS NULL),
           'Month' = (SELECT COUNT(*)
                      FROM VOUCHER
                      WHERE DATEPART(YEAR, PRINTED_DATE_TIME) = DATEPART(YEAR, GETDATE() - 1)
                        AND DATEPART(MONTH, PRINTED_DATE_TIME) = DATEPART(MONTH, GETDATE() - 1)
                        AND PRINTED_DATE_TIME <= GETDATE() - 1
                        AND REPRINT_OF IS NULL),
           'Week'  = (SELECT COUNT(*)
                      FROM VOUCHER
                      WHERE DATEPART(YEAR, PRINTED_DATE_TIME) = DATEPART(YEAR, GETDATE() - 1)
                        AND DATEPART(MONTH, PRINTED_DATE_TIME) = DATEPART(MONTH, GETDATE() - 1)
                        AND DATEPART(WEEK, PRINTED_DATE_TIME) = DATEPART(WEEK, GETDATE() - 1)
                        AND PRINTED_DATE_TIME <= GETDATE() - 1
                        AND REPRINT_OF IS NULL),
           'Day'   = (SELECT COUNT(*)
                      FROM VOUCHER
                      WHERE DATEPART(YEAR, PRINTED_DATE_TIME) = DATEPART(YEAR, GETDATE() - 1)
                        AND DATEPART(MONTH, PRINTED_DATE_TIME) = DATEPART(MONTH, GETDATE() - 1)
                        AND DATEPART(WEEK, PRINTED_DATE_TIME) = DATEPART(WEEK, GETDATE() - 1)
                        AND DATEPART(DAY, PRINTED_DATE_TIME) = DATEPART(DAY, GETDATE() - 1)
                        AND REPRINT_OF IS NULL)
ROLLBACK TRAN

/* ====================================
  IN1 stored procedure for number of vouchers sold
======================================= */
DROP PROC IF EXISTS GET_VOUCHERS_SOLD
GO

CREATE PROC GET_VOUCHERS_SOLD
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint

            SET DATEFIRST 1;

            SELECT 'Year'  = (SELECT COUNT(*)
                              FROM VOUCHER
                              WHERE DATEPART(YEAR, PRINTED_DATE_TIME) = DATEPART(YEAR, GETDATE() - 1)
                                AND PRINTED_DATE_TIME <= GETDATE() - 1
                                AND REPRINT_OF IS NULL),
                   'Month' = (SELECT COUNT(*)
                              FROM VOUCHER
                              WHERE DATEPART(YEAR, PRINTED_DATE_TIME) = DATEPART(YEAR, GETDATE() - 1)
                                AND DATEPART(MONTH, PRINTED_DATE_TIME) = DATEPART(MONTH, GETDATE() - 1)
                                AND PRINTED_DATE_TIME <= GETDATE() - 1
                                AND REPRINT_OF IS NULL),
                   'Week'  = (SELECT COUNT(*)
                              FROM VOUCHER
                              WHERE DATEPART(YEAR, PRINTED_DATE_TIME) = DATEPART(YEAR, GETDATE() - 1)
                                AND DATEPART(MONTH, PRINTED_DATE_TIME) = DATEPART(MONTH, GETDATE() - 1)
                                AND DATEPART(WEEK, PRINTED_DATE_TIME) = DATEPART(WEEK, GETDATE() - 1)
                                AND PRINTED_DATE_TIME <= GETDATE() - 1
                                AND REPRINT_OF IS NULL),
                   'Day'   = (SELECT COUNT(*)
                              FROM VOUCHER
                              WHERE DATEPART(YEAR, PRINTED_DATE_TIME) = DATEPART(YEAR, GETDATE() - 1)
                                AND DATEPART(MONTH, PRINTED_DATE_TIME) = DATEPART(MONTH, GETDATE() - 1)
                                AND DATEPART(WEEK, PRINTED_DATE_TIME) = DATEPART(WEEK, GETDATE() - 1)
                                AND DATEPART(DAY, PRINTED_DATE_TIME) = DATEPART(DAY, GETDATE() - 1)
                                AND REPRINT_OF IS NULL)
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO


/* ====================================
  IN2 stored procedure for number of vouchers scanned
======================================= */
DROP PROC IF EXISTS GET_VOUCHERS_SCANNED
GO

CREATE PROC GET_VOUCHERS_SCANNED
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint

            SET DATEFIRST 1;

            SELECT 'Year'  = (SELECT COUNT(*)
                              FROM SCANNED_BY
                              WHERE DATEPART(YEAR, SCANNED_TIME) = DATEPART(YEAR, GETDATE() - 1)
                                AND SCANNED_TIME < GETDATE()),
                   'Month' = (SELECT COUNT(*)
                              FROM SCANNED_BY
                              WHERE DATEPART(YEAR, SCANNED_TIME) = DATEPART(YEAR, GETDATE() - 1)
                                AND DATEPART(MONTH, SCANNED_TIME) = DATEPART(MONTH, GETDATE() - 1)
                                AND SCANNED_TIME < GETDATE()),
                   'Week'  = (SELECT COUNT(*)
                              FROM SCANNED_BY
                              WHERE DATEPART(YEAR, SCANNED_TIME) = DATEPART(YEAR, GETDATE() - 1)
                                AND DATEPART(MONTH, SCANNED_TIME) = DATEPART(MONTH, GETDATE() - 1)
                                AND DATEPART(WEEK, SCANNED_TIME) = DATEPART(WEEK, GETDATE() - 1)
                                AND SCANNED_TIME < GETDATE()),
                   'Day'   = (SELECT COUNT(*)
                              FROM SCANNED_BY
                              WHERE DATEPART(YEAR, SCANNED_TIME) = DATEPART(YEAR, GETDATE() - 1)
                                AND DATEPART(MONTH, SCANNED_TIME) = DATEPART(MONTH, GETDATE() - 1)
                                AND DATEPART(WEEK, SCANNED_TIME) = DATEPART(WEEK, GETDATE() - 1)
                                AND DATEPART(DAY, SCANNED_TIME) = DATEPART(DAY, GETDATE() - 1))
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO