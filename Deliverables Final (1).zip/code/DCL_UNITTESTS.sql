-- noinspection SqlInsertNullIntoNotNullForFile

-- noinspection SqlInsertIntoGeneratedColumnForFile

USE SUPERCINEMA
GO

/* ====================================
  Unittests: SP check voucher status
======================================= */
tSQLt.NewTestClass 'Tests_SP_for_IRS'
GO

DROP PROCEDURE IF EXISTS Tests_SP_for_IRS.test_voucher_is_open_thus_no_error
GO

CREATE PROCEDURE Tests_SP_for_IRS.test_voucher_is_open_thus_no_error
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER', @SchemaName = 'DBO'

    DECLARE @voucherNumber INTEGER = 1

    INSERT INTO VOUCHER (VOUCHER_NUMBER, SHOP_NAME, VOUCHER_TYPE, PRINTED_BY, REPRINT_OF, PRINTED_DATE_TIME, STATUS,
                         SELLING_PRICE)
    VALUES (@voucherNumber, 'Super Cinema''s Arnhem Stationslaan', 'Drink balance and snack balance', 11, NULL,
            '2020-04-19 20:20:20',
            'Open', 30)

    EXEC tSQLt.ExpectNoException

    --Act
    EXEC THROW_ERROR_WHEN_VOUCHER_IS_NOT_OPEN @voucherNumber
END
GO

DROP PROCEDURE IF EXISTS Tests_SP_for_IRS.test_voucher_is_open_thus_error
GO

CREATE PROCEDURE Tests_SP_for_IRS.test_voucher_is_open_thus_error
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER', @SchemaName = 'DBO'

    DECLARE @voucherNumber INTEGER = 1

    INSERT INTO VOUCHER (VOUCHER_NUMBER, SHOP_NAME, VOUCHER_TYPE, PRINTED_BY, REPRINT_OF, PRINTED_DATE_TIME, STATUS,
                         SELLING_PRICE)
    VALUES (@voucherNumber, 'Super Cinema''s Arnhem Stationslaan', 'Drink balance and snack balance', 11, NULL,
            '2020-04-19 20:20:20',
            'Returned', 30)

    EXEC tSQLt.ExpectException

    -- Act
    EXEC THROW_ERROR_WHEN_VOUCHER_IS_NOT_OPEN @voucherNumber

END
GO

/* ====================================
  Unittests: IR1
======================================= */
tSQLt.NewTestClass 'TESTS_INTEGRITY_RULE1'
GO

DROP PROCEDURE IF EXISTS
    TESTS_INTEGRITY_RULE1.test_check_if_constraint_violated_based_on_wrong_voucher_status
GO

CREATE PROCEDURE TESTS_INTEGRITY_RULE1.test_check_if_constraint_violated_based_on_wrong_voucher_status
AS
BEGIN
    --Arrange
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER', @SchemaName = 'DBO'

    INSERT INTO VOUCHER (VOUCHER_NUMBER, SHOP_NAME, VOUCHER_TYPE, PRINTED_BY, REPRINT_OF, PRINTED_DATE_TIME, STATUS,
                         SELLING_PRICE, ORDER_NUMBER)
    VALUES (1, NULL, NULL, NULL, NULL, NULL, 'Open', 30, NULL)
    EXEC tSQLt.ApplyConstraint @TableName = 'VOUCHER', @SchemaName = 'DBO', @ConstraintName = CHK_VOUCHER_STATUS
    EXEC tSQLt.ExpectException

    --ACT
    INSERT INTO VOUCHER (VOUCHER_NUMBER, SHOP_NAME, VOUCHER_TYPE, PRINTED_BY, REPRINT_OF, PRINTED_DATE_TIME, STATUS,
                         SELLING_PRICE, ORDER_NUMBER)
    VALUES (2, NULL, NULL, NULL, NULL, NULL, 'Wrong Status', 30, NULL)
END
GO

DROP PROCEDURE IF EXISTS
    TESTS_INTEGRITY_RULE1.test_check_if_constraint_is_not_violated_based_on_correct_voucher_status
GO

CREATE PROCEDURE TESTS_INTEGRITY_RULE1.test_check_if_constraint_is_not_violated_based_on_correct_voucher_status
AS
BEGIN
    --Arrange
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER', @SchemaName = 'DBO'

    INSERT INTO VOUCHER (VOUCHER_NUMBER, SHOP_NAME, VOUCHER_TYPE, PRINTED_BY, REPRINT_OF, PRINTED_DATE_TIME, STATUS,
                         SELLING_PRICE, ORDER_NUMBER)
    VALUES (1, NULL, NULL, NULL, NULL, NULL, 'Open', NULL, NULL)

    EXEC tSQLt.ApplyConstraint @TableName = 'VOUCHER', @SchemaName = 'DBO', @ConstraintName = CHK_VOUCHER_STATUS
    EXEC tSQLt.ExpectNoException

    --ACT
    INSERT INTO VOUCHER (VOUCHER_NUMBER, SHOP_NAME, VOUCHER_TYPE, PRINTED_BY, REPRINT_OF, PRINTED_DATE_TIME, STATUS,
                         SELLING_PRICE, ORDER_NUMBER)
    VALUES (2, NULL, NULL, NULL, NULL, NULL, 'Blocked', NULL, NULL)
END
GO

/* ====================================
  Unittests: IR2
======================================= */
tSQLt.NewTestClass 'TESTS_INTEGRITY_RULE2'
GO

DROP PROCEDURE IF EXISTS
    TESTS_INTEGRITY_RULE2.test_check_if_constraint_violated_based_on_wrong_product_type
GO

CREATE PROCEDURE TESTS_INTEGRITY_RULE2.test_check_if_constraint_violated_based_on_wrong_product_type
AS
BEGIN
    --Arrange
    EXEC tSQLt.FakeTable @TableName = 'Product', @SchemaName = 'DBO'

    INSERT INTO Product (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES ('frozen', 'Ticket', 10)

    EXEC tSQLt.ApplyConstraint @TableName = 'Product', @SchemaName = 'DBO', @ConstraintName = CHK_PRODUCT_TYPE
    EXEC tSQLt.ExpectException

    --ACT
    INSERT INTO Product (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES ('parasite', 'wrong_product_type', 9)
END
GO

DROP PROCEDURE IF EXISTS
    TESTS_INTEGRITY_RULE2.test_check_if_constraint_is_not_violated_based_on_correct_product_type
GO

CREATE PROCEDURE TESTS_INTEGRITY_RULE2.test_check_if_constraint_is_not_violated_based_on_correct_product_type
AS
BEGIN
    --Arrange
    EXEC tSQLt.FakeTable @TableName = 'Product', @SchemaName = 'DBO'

    INSERT INTO Product (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES ('frozen', 'Ticket', 10)

    EXEC tSQLt.ApplyConstraint @TableName = 'Product', @SchemaName = 'DBO', @ConstraintName = CHK_PRODUCT_TYPE
    EXEC tSQLt.ExpectNoException

    --ACT
    INSERT INTO Product (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES ('frozen2', 'Ticket', 13)
END
GO


/* ====================================
  Unittests: IR3
======================================= */
tSQLt.NewTestClass 'Tests_IR3'
GO

DROP PROCEDURE IF EXISTS Tests_IR3.test_update_selling_price_only_balance_passes
GO

CREATE PROCEDURE Tests_IR3.test_update_selling_price_only_balance_passes
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT_ON_VOUCHER', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT', @SchemaName = 'dbo'

    DECLARE @voucher_number INTEGER = 1
    DECLARE @voucher_type CHAR(256) = 'Marvel the Avengers: Infinity War ticket with drink and snack balance'
    DECLARE @product1_name CHAR(256) = 'Drink_Balance'
    DECLARE @product2_name CHAR(256) = 'Snack_Balance'
    DECLARE @balance1 NUMERIC(8, 2) = 10
    DECLARE @balance2 NUMERIC(8, 2) = 15

    DECLARE @expected NUMERIC(8, 2) = @balance1 + @balance2
    DECLARE @actual INTEGER

    INSERT INTO VOUCHER (VOUCHER_NUMBER, SHOP_NAME, VOUCHER_TYPE, REPRINT_OF, PRINTED_BY, PRINTED_DATE_TIME,
                         ORDER_NUMBER, STATUS, SELLING_PRICE)
    VALUES (@voucher_number, NULL, @voucher_type, NULL, 1, GETDATE(), NULL, 'Open', 0)

    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, AMOUNT)
    VALUES (@voucher_number, @product1_name, @balance1),
           (@voucher_number, @product2_name, @balance2)

    -- Act
    EXEC SP_UPDATE_SELLING_PRICE @voucher_number

    SELECT @actual = SELLING_PRICE FROM VOUCHER WHERE VOUCHER_NUMBER = @voucher_number

    -- Assert
    EXEC tSQLt.AssertEquals @expected, @actual

END
GO

DROP PROCEDURE IF EXISTS Tests_IR3.test_update_selling_price_only_products_passes
GO

CREATE PROCEDURE Tests_IR3.test_update_selling_price_only_products_passes
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT_ON_VOUCHER', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT', @SchemaName = 'dbo'

    DECLARE @voucher_number INTEGER = 1
    DECLARE @voucher_type CHAR(256) = 'After ticket and non-specific ticket'
    DECLARE @product1 CHAR(256) = 'After'
    DECLARE @product2 CHAR(256) = 'Non-specific ticket'
    DECLARE @amount1 INTEGER = 2
    DECLARE @amount2 INTEGER = 1
    DECLARE @product_type CHAR(256) = 'Ticket'
    DECLARE @price1 NUMERIC(8, 2) = 12.00
    DECLARE @price2 NUMERIC(8, 2) = 15.00

    DECLARE @expected NUMERIC(8, 2) = ((@amount1 * @price1) + (@amount2 * @price2))
    DECLARE @actual INTEGER

    INSERT INTO VOUCHER (VOUCHER_NUMBER, SHOP_NAME, VOUCHER_TYPE, REPRINT_OF, PRINTED_BY, PRINTED_DATE_TIME,
                         ORDER_NUMBER, STATUS, SELLING_PRICE)
    VALUES (@voucher_number, NULL, @voucher_type, NULL, 1, GETDATE(), NULL, 'Open', 0)

    INSERT INTO PRODUCT (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@product1, @product_type, @price1),
           (@product2, @product_type, @price2)

    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, QUANTITY)
    VALUES (@voucher_number, @product1, @amount1),
           (@voucher_number, @product2, @amount2)

    -- Act
    EXEC SP_UPDATE_SELLING_PRICE @voucher_number

    SELECT @actual = SELLING_PRICE FROM VOUCHER WHERE VOUCHER_NUMBER = @voucher_number

    -- Assert
    EXEC tSQLt.AssertEquals @expected, @actual

END
GO

DROP PROCEDURE IF EXISTS Tests_IR3.test_update_selling_price_products_and_balance_passes
GO

CREATE PROCEDURE Tests_IR3.test_update_selling_price_products_and_balance_passes
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT_ON_VOUCHER', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT', @SchemaName = 'dbo'

    DECLARE @voucher_number INTEGER = 1
    DECLARE @voucher_type CHAR(256) = 'Marvel the Avengers: Infinity War ticket with drink and snack balance and non-specific ticket'
    DECLARE @product1_name CHAR(256) = 'Drink_Balance'
    DECLARE @product2_name CHAR(256) = 'Snack_Balance'
    DECLARE @balance1 NUMERIC(8, 2) = 10
    DECLARE @balance2 NUMERIC(8, 2) = 15
    DECLARE @product1 CHAR(256) = 'Marvel the Avengers: Infinity War'
    DECLARE @product2 CHAR(256) = 'Non-specific ticket'
    DECLARE @quantity1 INTEGER = 2
    DECLARE @quantity2 INTEGER = 1
    DECLARE @product_type CHAR(256) = 'Ticket'
    DECLARE @price1 NUMERIC(8, 2) = 12.00
    DECLARE @price2 NUMERIC(8, 2) = 15.00

    DECLARE @expected NUMERIC(8, 2) = ((@quantity1 * @price1) + (@quantity2 * @price2) + (@balance1) + (@balance2))
    DECLARE @actual INTEGER

    INSERT INTO VOUCHER (VOUCHER_NUMBER, SHOP_NAME, VOUCHER_TYPE, REPRINT_OF, PRINTED_BY, PRINTED_DATE_TIME,
                         ORDER_NUMBER, STATUS, SELLING_PRICE)
    VALUES (@voucher_number, NULL, @voucher_type, NULL, 1, GETDATE(), NULL, 'Open', 0)

    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, AMOUNT)
    VALUES (@voucher_number, @product1_name, @balance1),
           (@voucher_number, @product2_name, @balance2)

    INSERT INTO PRODUCT (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@product1, @product_type, @price1),
           (@product2, @product_type, @price2)

    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, QUANTITY)
    VALUES (@voucher_number, @product1, @quantity1),
           (@voucher_number, @product2, @quantity2)

    -- Act
    EXEC SP_UPDATE_SELLING_PRICE @voucher_number

    SELECT @actual = SELLING_PRICE FROM VOUCHER WHERE VOUCHER_NUMBER = @voucher_number

    -- Assert
    EXEC tSQLt.AssertEquals @expected, @actual

END
GO

DROP PROCEDURE IF EXISTS Tests_IR3.test_update_selling_price_fails
GO

CREATE PROCEDURE Tests_IR3.test_update_selling_price_fails
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT_ON_VOUCHER', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT', @SchemaName = 'dbo'

    DECLARE @voucher_number INTEGER = 1
    DECLARE @voucher_type CHAR(256) = 'Marvel the Avengers: Infinity War ticket with drink and snack balance and non-specific ticket'
    DECLARE @product1_name CHAR(256) = 'Drink_Balance'
    DECLARE @product2_name CHAR(256) = 'Snack_Balance'
    DECLARE @balance1 NUMERIC(8, 2) = 10
    DECLARE @balance2 NUMERIC(8, 2) = 15
    DECLARE @product1 CHAR(256) = 'Marvel the Avengers: Infinity War'
    DECLARE @product2 CHAR(256) = 'Non-specific ticket'
    DECLARE @quantity1 INTEGER = 2
    DECLARE @quantity2 INTEGER = 1
    DECLARE @product_type CHAR(256) = 'Ticket'
    DECLARE @price1 NUMERIC(8, 2) = 12.00
    DECLARE @price2 NUMERIC(8, 2) = 15.00

    INSERT INTO VOUCHER (VOUCHER_NUMBER, SHOP_NAME, VOUCHER_TYPE, REPRINT_OF, PRINTED_BY, PRINTED_DATE_TIME,
                         ORDER_NUMBER, STATUS, SELLING_PRICE)
    VALUES (@voucher_number, NULL, @voucher_type, NULL, 1, GETDATE(), NULL, 'Open', 0)

    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, AMOUNT)
    VALUES (@voucher_number, @product1_name, @balance1),
           (@voucher_number, @product2_name, @balance2)

    INSERT INTO PRODUCT (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@product1, @product_type, @price1),
           (@product2, @product_type, @price2)

    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, QUANTITY)
    VALUES (@voucher_number, @product1, @quantity1),
           (@voucher_number, @product2, @quantity2)

    EXEC tSQLt.ExpectException

    -- Act
    EXEC SP_UPDATE_SELLING_PRICE NULL

END
GO

/* ====================================
  Unittests: IR4
======================================= */
tSQLt.NewTestClass 'Tests_IR4'
GO

DROP PROCEDURE IF EXISTS Tests_IR4.test_product_type_not_quantity
GO

CREATE PROCEDURE Tests_IR4.test_product_type_not_quantity
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT_ON_VOUCHER', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'Scanned_By', @SchemaName = 'dbo'

    DECLARE @voucherNumber INTEGER = 42
    DECLARE @productName VARCHAR(256) = 'Drink Balance'
    DECLARE @productType VARCHAR(256) = 'Balance'
    DECLARE @quantity INTEGER = 2
    DECLARe @price INTEGER = 5
    DECLARE @scannedBy INTEGER = 1
    DECLARE @scannedLocation VARCHAR(256) = 'Cinema'

    INSERT INTO PRODUCT(PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@productName, @productType, @price)

    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, QUANTITY)
    VALUES (@voucherNumber, @productName, @quantity)

    -- Act
    EXEC tSQLt.ExpectException
         @ExpectedMessage = 'You can not decrease the quantity of this product.'

    EXEC SP_SCAN_PRODUCT_ON_VOUCHER @voucherNumber, @productName, @scannedBy, @scannedLocation

END
GO

DROP PROCEDURE IF EXISTS Tests_IR4.test_quantity_is_already_zero
GO

CREATE PROCEDURE Tests_IR4.test_quantity_is_already_zero
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'Product_On_Voucher', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'Product', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'Scanned_By', @SchemaName = 'dbo'

    DECLARE @voucherNumber INTEGER = 1
    DECLARE @productName VARCHAR(256) = 'Cola'
    DECLARE @productType VARCHAR(256) = 'Drink'
    DECLARE @price INTEGER = 5
    DECLARE @scannedBy INT = 1
    DECLARE @scannedLocation VARCHAR(256) = 'Cinema'
    DECLARE @MESSAGE VARCHAR(256) = CONCAT('Voucher ', @voucherNumber, ' Product ', @productName,
                                      ' can''t be used because the quantity is 0.');

    INSERT INTO PRODUCT(PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@productName, @productType, @price)


    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, QUANTITY, AMOUNT)
    VALUES (@voucherNumber, @productName, 0, NULL)

    -- Act
    EXEC tSQLt.ExpectException
         @ExpectedMessage = @MESSAGE

    EXEC SP_SCAN_PRODUCT_ON_VOUCHER @voucherNumber, @productName, @scannedBy, @scannedLocation
END
GO

DROP PROCEDURE IF EXISTS Tests_IR4.test_quantity_gets_reduced
GO

CREATE PROCEDURE Tests_IR4.test_quantity_gets_reduced
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'Product_On_Voucher', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'Product', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'Scanned_By', @SchemaName = 'dbo'

    DECLARE @voucherNumber INTEGER = 1
    DECLARE @productName VARCHAR(256) = 'Cola'
    DECLARE @productType VARCHAR(256) = 'Drink'
    DECLARE @insertQuantity INTEGER = 3
    DECLARE @price INTEGER = 5
    DECLARE @scannedBy INT = 1
    DECLARE @scannedLocation VARCHAR(256) = 'Cinema'
    DECLARE @newQuantity INTEGER;

    INSERT INTO PRODUCT(PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@productName, @productType, @price)

    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, QUANTITY, AMOUNT)
    VALUES (@voucherNumber, @productName, @insertQuantity, NULL)

    -- Act
    EXEC tSQLt.ExpectNoException

    EXEC SP_SCAN_PRODUCT_ON_VOUCHER @voucherNumber, @productName, @scannedBy, @scannedLocation

    SELECT @newQuantity = QUANTITY FROM PRODUCT_ON_VOUCHER

    -- Assert
    EXEC tSQLt.AssertEqualsString @expected = 2, @actual = @newQuantity
END
GO

DROP PROCEDURE IF EXISTS Tests_IR4.test_quantity_gets_reduced_and_product_gets_scanned
GO

CREATE PROCEDURE Tests_IR4.test_quantity_gets_reduced_and_product_gets_scanned
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'Product_On_Voucher', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'Product', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'Scanned_By', @SchemaName = 'dbo'

    DECLARE @voucherNumber INTEGER = 1
    DECLARE @productName VARCHAR(256) = 'Cola'
    DECLARE @productType VARCHAR(256) = 'Drink'
    DECLARE @insertQuantity INTEGER = 3
    DECLARE @price INTEGER = 5
    DECLARE @scannedBy INTEGER = 1
    DECLARE @scannedLocation VARCHAR(256) = 'Cinema'
    DECLARE @newQuantity INTEGER;
    DECLARE @checkScan INTEGER;

    INSERT INTO PRODUCT(PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@productName, @productType, @price)

    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, QUANTITY, AMOUNT)
    VALUES (@voucherNumber, @productName, @insertQuantity, NULL)

    -- Act
    EXEC tSQLt.ExpectNoException

    EXEC SP_SCAN_PRODUCT_ON_VOUCHER @voucherNumber, @productName, @scannedBy, @scannedLocation

    SELECT @newQuantity = QUANTITY FROM PRODUCT_ON_VOUCHER
    SELECT @checkScan = VOUCHER_NUMBER FROM SCANNED_BY

    -- Assert
    EXEC tSQLt.AssertEqualsString @expected = 2, @actual = @newQuantity
    EXEC tSQLt.AssertEqualsString @expected = @voucherNumber, @actual = @checkScan
END
GO

/* ====================================
  Integrity Rule: 5
======================================= */
tSQLt.NewTestClass 'Tests_IR5'
GO

DROP PROCEDURE IF EXISTS Tests_IR5.test_product_type_not_balance
GO

CREATE PROCEDURE Tests_IR5.test_product_type_not_balance
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'Product_On_Voucher', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'Product', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'Scanned_By', @SchemaName = 'dbo'

    DECLARE @voucherNumber INTEGER = 1
    DECLARE @productName VARCHAR(256) = 'Cola'
    DECLARE @productType VARCHAR(256) = 'Drink'
    DECLARE @amount NUMERIC(8, 2) = 25
    DECLARE @scannedBy INTEGER = 1
    DECLARE @scannedLocation VARCHAR(256) = 'Cinema'

    INSERT INTO PRODUCT(PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@productName, @productType, NULL)


    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, QUANTITY, AMOUNT)
    VALUES (@voucherNumber, @productName, NULL, @amount)

    -- Act
    EXEC tSQLt.ExpectException
         @ExpectedMessage = 'You can not decrease the balance of this voucher.'

    EXEC SP_DECREASE_POV_BALANCE @voucherNumber, @productName, @amount, @scannedBy, @scannedLocation
END
GO

DROP PROCEDURE IF EXISTS Tests_IR5.test_balance_is_already_zero
GO

CREATE PROCEDURE Tests_IR5.test_balance_is_already_zero
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'Product_On_Voucher', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'Product', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'Scanned_By', @SchemaName = 'dbo'

    DECLARE @voucherNumber INTEGER = 1
    DECLARE @productName VARCHAR(256) = 'Cola'
    DECLARE @productType VARCHAR(256) = 'Balance'
    DECLARE @amount NUMERIC(8, 2) = 10
    DECLARE @scannedBy INTEGER = 1
    DECLARE @scannedLocation VARCHAR(256) = 'Cinema'
    DECLARE @MESSAGE VARCHAR(256) = CONCAT('Voucher ', @voucherNumber,
                                           ' can''t be used because the balance is 0.');

    INSERT INTO PRODUCT(PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@productName, @productType, NULL)


    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, QUANTITY, AMOUNT)
    VALUES (@voucherNumber, @productName, NULL, 0)

    -- Act
    EXEC tSQLt.ExpectException
         @ExpectedMessage = @MESSAGE

    EXEC SP_DECREASE_POV_BALANCE @voucherNumber, @productName, @amount, @scannedBy, @scannedLocation
END
GO

DROP PROCEDURE IF EXISTS Tests_IR5.test_not_enough_balance
GO

CREATE PROCEDURE Tests_IR5.test_not_enough_balance
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'Product_On_Voucher', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'Product', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'Scanned_By', @SchemaName = 'dbo'

    DECLARE @voucherNumber INTEGER = 1
    DECLARE @productName VARCHAR(256) = 'Cola'
    DECLARE @productType VARCHAR(256) = 'Balance'
    DECLARE @amount NUMERIC(8, 2) = 15
    DECLARE @scannedBy INTEGER = 1
    DECLARE @scannedLocation VARCHAR(256) = 'Cinema'

    INSERT INTO PRODUCT(PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@productName, @productType, NULL)


    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, QUANTITY, AMOUNT)
    VALUES (@voucherNumber, @productName, NULL, 5)

    -- Act
    EXEC tSQLt.ExpectException
         @ExpectedMessage = 'You don''t have enough balance on this voucher.'

    EXEC SP_DECREASE_POV_BALANCE @voucherNumber, @productName, @amount, @scannedBy, @scannedLocation
END
GO

DROP PROCEDURE IF EXISTS Tests_IR5.test_balance_gets_reduced
GO

CREATE PROCEDURE Tests_IR5.test_balance_gets_reduced
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'Product_On_Voucher', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'Product', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'Scanned_By', @SchemaName = 'dbo'

    DECLARE @voucherNumber INTEGER = 1
    DECLARE @productName VARCHAR(256) = 'Cola'
    DECLARE @productType VARCHAR(256) = 'Balance'
    DECLARE @insertBalance NUMERIC(8, 2) = 20.0
    DECLARE @amount NUMERIC(8, 2) = 15.0
    DECLARE @scannedBy INTEGER = 1
    DECLARE @scannedLocation VARCHAR(256) = 'Cinema'
    DECLARE @newBalance NUMERIC(8, 2);

    INSERT INTO PRODUCT(PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@productName, @productType, NULL)

    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, QUANTITY, AMOUNT)
    VALUES (@voucherNumber, @productName, NULL, @insertBalance)

    -- Act
    EXEC tSQLt.ExpectNoException

    EXEC SP_DECREASE_POV_BALANCE @voucherNumber, @productName, @amount, @scannedBy, @scannedLocation

    SELECT @newBalance = AMOUNT FROM PRODUCT_ON_VOUCHER

    -- Assert
    EXEC tSQLt.AssertEqualsString @expected = 5.00, @actual = @newBalance
END
GO

CREATE PROCEDURE Tests_IR5.test_balance_gets_reduced_and_product_gets_scanned
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'Product_On_Voucher', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'Product', @SchemaName = 'dbo'
    EXEC tSQLt.FakeTable @TableName = 'Scanned_By', @SchemaName = 'dbo'

    DECLARE @voucherNumber INTEGER = 1
    DECLARE @productName VARCHAR(256) = 'Cola'
    DECLARE @productType VARCHAR(256) = 'Balance'
    DECLARE @insertBalance NUMERIC(8, 2) = 20.0
    DECLARE @amount NUMERIC(8, 2) = 15.0
    DECLARE @scannedBy INTEGER = 1
    DECLARE @scannedLocation VARCHAR(256) = 'Cinema'
    DECLARE @newBalance NUMERIC(8, 2);
    DECLARE @checkScan INT

    INSERT INTO PRODUCT(PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@productName, @productType, NULL)

    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, QUANTITY, AMOUNT)
    VALUES (@voucherNumber, @productName, NULL, @insertBalance)

    -- Act
    EXEC tSQLt.ExpectNoException

    EXEC SP_DECREASE_POV_BALANCE @voucherNumber, @productName, @amount, @scannedBy, @scannedLocation

    SELECT @newBalance = AMOUNT FROM PRODUCT_ON_VOUCHER
    SELECT @checkScan = VOUCHER_NUMBER FROM SCANNED_BY
    -- Assert
    EXEC tSQLt.AssertEqualsString @expected = 5.00, @actual = @newBalance
    EXEC tSQLt.AssertEqualsString @expected = 1, @actual = @checkScan

END
GO

/* ====================================
  Integrity Rule: 6
======================================= */
tSQLt.NewTestClass 'Tests_IR6'
GO

DROP PROC IF EXISTS Tests_IR6.test_update_status_if_voucher_is_used_does_not_update_when_no_products_are_used
GO

CREATE PROC Tests_IR6.test_update_status_if_voucher_is_used_does_not_update_when_no_products_are_used
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER_TYPE', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'EXCHANGED_FOR', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT_ON_VOUCHER', @SchemaName = 'DBO'
    EXEC tSQLt.ApplyTrigger @TableName = 'PRODUCT_ON_VOUCHER', @TriggerName = 'TRG_UPDATE_STATUS_IF_VOUCHER_IS_USED'

    DECLARE @product1 VARCHAR(256) = 'Drink Balance'
    DECLARE @product2 VARCHAR(256) = 'Coca Cola'
    DECLARE @product3 VARCHAR(256) = 'Lays'

    DECLARE @voucherType VARCHAR(256) = 'test type'
    DECLARE @status VARCHAR(10) = 'Open'
    DECLARE @voucherNumber INT = 1

    INSERT INTO PRODUCT (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@product1, 'Balance', NULL),
           (@product2, 'Drink', 10.0),
           (@product3, 'Snack', 5.0)
    INSERT INTO VOUCHER_TYPE (VOUCHER_TYPE)
    VALUES (@voucherType)
    INSERT INTO EXCHANGED_FOR (VOUCHER_TYPE, PRODUCT_NAME)
    VALUES (@voucherType, @product1),
           (@voucherType, @product2)
    INSERT INTO VOUCHER (VOUCHER_NUMBER, VOUCHER_TYPE, STATUS)
    VALUES (@voucherNumber, @voucherType, @status)

    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, QUANTITY, AMOUNT)
    VALUES (@voucherNumber, @product1, NULL, 10.0),
           (@voucherNumber, @product2, 2, NULL)

    EXECUTE tSQLt.ExpectNoException

    -- Act
    UPDATE PRODUCT_ON_VOUCHER
    SET QUANTITY = QUANTITY - 1
    WHERE VOUCHER_NUMBER = @voucherNumber
      AND PRODUCT_NAME = @product2

    DECLARE @actualStatus VARCHAR(10)
    SELECT @actualStatus = STATUS
    FROM VOUCHER
    WHERE VOUCHER_NUMBER = @voucherNumber

    -- Assert
    EXECUTE tSQLt.AssertEquals @status, @actualStatus
END
GO

DROP PROC IF EXISTS Tests_IR6.test_update_status_if_voucher_is_used_does_not_update_when_only_one_of_its_products_is_used
GO

CREATE PROC Tests_IR6.test_update_status_if_voucher_is_used_does_not_update_when_only_one_of_its_products_is_used
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER_TYPE', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'EXCHANGED_FOR', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT_ON_VOUCHER', @SchemaName = 'DBO'
    EXEC tSQLt.ApplyTrigger @TableName = 'PRODUCT_ON_VOUCHER', @TriggerName = 'TRG_UPDATE_STATUS_IF_VOUCHER_IS_USED'

    DECLARE @product1 VARCHAR(256) = 'Drink Balance'
    DECLARE @product2 VARCHAR(256) = 'Coca Cola'
    DECLARE @product3 VARCHAR(256) = 'Lays'

    DECLARE @voucherType VARCHAR(256) = 'test type'
    DECLARE @status VARCHAR(10) = 'Open'
    DECLARE @voucherNumber INT = 1

    INSERT INTO PRODUCT (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@product1, 'Balance', NULL),
           (@product2, 'Drink', 10.0),
           (@product3, 'Snack', 5.0)
    INSERT INTO VOUCHER_TYPE (VOUCHER_TYPE)
    VALUES (@voucherType)
    INSERT INTO EXCHANGED_FOR (VOUCHER_TYPE, PRODUCT_NAME)
    VALUES (@voucherType, @product1),
           (@voucherType, @product2)
    INSERT INTO VOUCHER (VOUCHER_NUMBER, VOUCHER_TYPE, STATUS)
    VALUES (@voucherNumber, @voucherType, @status)

    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, QUANTITY, AMOUNT)
    VALUES (@voucherNumber, @product1, NULL, 10.0),
           (@voucherNumber, @product2, 2, NULL)

    EXECUTE tSQLt.ExpectNoException

    -- Act
    UPDATE PRODUCT_ON_VOUCHER
    SET QUANTITY = 0
    WHERE VOUCHER_NUMBER = @voucherNumber
      AND PRODUCT_NAME = @product2

    DECLARE @actualStatus VARCHAR(10)
    SELECT @actualStatus = STATUS
    FROM VOUCHER
    WHERE VOUCHER_NUMBER = @voucherNumber

    -- Assert
    EXECUTE tSQLt.AssertEquals @status, @actualStatus
END
GO

DROP PROC IF EXISTS Tests_IR6.test_update_status_if_voucher_is_used_updates_when_all_products_are_used
GO

CREATE PROC Tests_IR6.test_update_status_if_voucher_is_used_updates_when_all_products_are_used
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER_TYPE', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'EXCHANGED_FOR', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT_ON_VOUCHER', @SchemaName = 'DBO'
    EXEC tSQLt.ApplyTrigger @TableName = 'PRODUCT_ON_VOUCHER', @TriggerName = 'TRG_UPDATE_STATUS_IF_VOUCHER_IS_USED'

    DECLARE @product1 VARCHAR(256) = 'Drink Balance'
    DECLARE @product2 VARCHAR(256) = 'Coca Cola'
    DECLARE @product3 VARCHAR(256) = 'Lays'

    DECLARE @voucherType VARCHAR(256) = 'test type'
    DECLARE @status VARCHAR(10) = 'Open'
    DECLARE @voucherNumber INT = 1

    INSERT INTO PRODUCT (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@product1, 'Balance', NULL),
           (@product2, 'Drink', 10.0),
           (@product3, 'Snack', 5.0)
    INSERT INTO VOUCHER_TYPE (VOUCHER_TYPE)
    VALUES (@voucherType)
    INSERT INTO EXCHANGED_FOR (VOUCHER_TYPE, PRODUCT_NAME)
    VALUES (@voucherType, @product1),
           (@voucherType, @product2)
    INSERT INTO VOUCHER (VOUCHER_NUMBER, VOUCHER_TYPE, STATUS)
    VALUES (@voucherNumber, @voucherType, @status)

    INSERT INTO PRODUCT_ON_VOUCHER (VOUCHER_NUMBER, PRODUCT_NAME, QUANTITY, AMOUNT)
    VALUES (@voucherNumber, @product1, NULL, 10.0),
           (@voucherNumber, @product2, 2, NULL)

    EXECUTE tSQLt.ExpectNoException

    -- Act
    UPDATE PRODUCT_ON_VOUCHER
    SET QUANTITY = 0
    WHERE VOUCHER_NUMBER = @voucherNumber
      AND PRODUCT_NAME = @product2

    UPDATE PRODUCT_ON_VOUCHER
    SET AMOUNT = 0
    WHERE VOUCHER_NUMBER = @voucherNumber
      AND PRODUCT_NAME = @product1

    DECLARE @actualStatus VARCHAR(10)
    SELECT @actualStatus = STATUS
    FROM VOUCHER
    WHERE VOUCHER_NUMBER = @voucherNumber

    -- Assert
    EXECUTE tSQLt.AssertEquals 'Used', @actualStatus
END
GO

/* ====================================
  Unit tests Integrity Rule: 7
======================================= */
tSQLt.NewTestClass 'Tests_IR7'
GO

DROP PROC IF EXISTS Tests_IR7.test_add_products_to_voucher_fails_if_param_is_null
GO

CREATE PROC Tests_IR7.test_add_products_to_voucher_fails_if_param_is_null
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER_TYPE', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'EXCHANGED_FOR', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT_ON_VOUCHER', @SchemaName = 'DBO'

    DECLARE @product1 VARCHAR(256) = 'Drink Balance'
    DECLARE @product2 VARCHAR(256) = 'Coca Cola'
    DECLARE @product3 VARCHAR(256) = 'Lays'

    DECLARE @voucherType VARCHAR(256) = 'test type'

    DECLARE @voucherNumber INT = 1

    INSERT INTO PRODUCT (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@product1, 'Balance', NULL),
           (@product2, 'Drink', 10.0),
           (@product3, 'Snack', 5.0)
    INSERT INTO VOUCHER_TYPE (VOUCHER_TYPE)
    VALUES (@voucherType)
    INSERT INTO EXCHANGED_FOR (VOUCHER_TYPE, PRODUCT_NAME)
    VALUES (@voucherType, @product1),
           (@voucherType, @product2)
    INSERT INTO VOUCHER (VOUCHER_NUMBER, VOUCHER_TYPE)
    VALUES (@voucherNumber, @voucherType)

    EXECUTE tSQLt.ExpectException @ExpectedMessagePattern = '%One of the provided parameters contained a NULL value, which is not allowed.%'

    -- Act
    EXEC SP_ADD_PRODUCTS_TO_VOUCHER NULL, NULL
END
GO

DROP PROC IF EXISTS Tests_IR7.test_add_products_to_voucher_adds_correct_quantity_of_products
GO

CREATE PROC Tests_IR7.test_add_products_to_voucher_adds_correct_quantity_of_products
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER_TYPE', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'EXCHANGED_FOR', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT_ON_VOUCHER', @SchemaName = 'DBO'

    DECLARE @product1 VARCHAR(256) = 'Drink Balance'
    DECLARE @product2 VARCHAR(256) = 'Coca Cola'
    DECLARE @product3 VARCHAR(256) = 'Lays'

    DECLARE @voucherType VARCHAR(256) = 'test type'

    DECLARE @voucherNumber INT = 1

    INSERT INTO PRODUCT (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@product1, 'Balance', NULL),
           (@product2, 'Drink', 10.0),
           (@product3, 'Snack', 5.0)
    INSERT INTO VOUCHER_TYPE (VOUCHER_TYPE)
    VALUES (@voucherType)
    INSERT INTO EXCHANGED_FOR (VOUCHER_TYPE, PRODUCT_NAME)
    VALUES (@voucherType, @product1),
           (@voucherType, @product2)
    INSERT INTO VOUCHER (VOUCHER_NUMBER, VOUCHER_TYPE)
    VALUES (@voucherNumber, @voucherType)

    EXECUTE tSQLt.ExpectNoException

    -- Act
    DECLARE @actualCount INT

    EXEC SP_ADD_PRODUCTS_TO_VOUCHER @voucherNumber, @voucherType

    SELECT @actualCount = COUNT(VOUCHER_NUMBER) FROM PRODUCT_ON_VOUCHER WHERE VOUCHER_NUMBER = @voucherNumber

    -- Arrange
    EXECUTE tSQLt.AssertEquals 2, @actualCount
END
GO

DROP PROC IF EXISTS Tests_IR7.test_add_products_to_voucher_sets_quantity_to_null_if_balance
GO

CREATE PROC Tests_IR7.test_add_products_to_voucher_sets_quantity_to_null_if_balance
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER_TYPE', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'EXCHANGED_FOR', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT_ON_VOUCHER', @SchemaName = 'DBO'

    DECLARE @product1 VARCHAR(256) = 'Drink Balance'
    DECLARE @product2 VARCHAR(256) = 'Coca Cola'
    DECLARE @product3 VARCHAR(256) = 'Lays'

    DECLARE @voucherType VARCHAR(256) = 'test type'

    DECLARE @voucherNumber INT = 1

    INSERT INTO PRODUCT (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@product1, 'Balance', NULL),
           (@product2, 'Drink', 10.0),
           (@product3, 'Snack', 5.0)
    INSERT INTO VOUCHER_TYPE (VOUCHER_TYPE)
    VALUES (@voucherType)
    INSERT INTO EXCHANGED_FOR (VOUCHER_TYPE, PRODUCT_NAME)
    VALUES (@voucherType, @product1),
           (@voucherType, @product2)
    INSERT INTO VOUCHER (VOUCHER_NUMBER, VOUCHER_TYPE)
    VALUES (@voucherNumber, @voucherType)

    EXECUTE tSQLt.ExpectNoException

    -- Act
    DECLARE @actualValue INT

    EXEC SP_ADD_PRODUCTS_TO_VOUCHER @voucherNumber, @voucherType

    SELECT @actualValue = QUANTITY FROM PRODUCT_ON_VOUCHER WHERE PRODUCT_NAME = @product1

    -- Arrange
    EXECUTE tSQLt.AssertEquals NULL, @actualValue
END
GO

DROP PROC IF EXISTS Tests_IR7.test_add_products_to_voucher_sets_amount_to_null_if_not_balance
GO

CREATE PROC Tests_IR7.test_add_products_to_voucher_sets_amount_to_null_if_not_balance
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'VOUCHER_TYPE', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'EXCHANGED_FOR', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT', @SchemaName = 'DBO'
    EXEC tSQLt.FakeTable @TableName = 'PRODUCT_ON_VOUCHER', @SchemaName = 'DBO'

    DECLARE @product1 VARCHAR(256) = 'Drink Balance'
    DECLARE @product2 VARCHAR(256) = 'Coca Cola'
    DECLARE @product3 VARCHAR(256) = 'Lays'

    DECLARE @voucherType VARCHAR(256) = 'test type'

    DECLARE @voucherNumber INT = 1

    INSERT INTO PRODUCT (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES (@product1, 'Balance', NULL),
           (@product2, 'Drink', 10.0),
           (@product3, 'Snack', 5.0)
    INSERT INTO VOUCHER_TYPE (VOUCHER_TYPE)
    VALUES (@voucherType)
    INSERT INTO EXCHANGED_FOR (VOUCHER_TYPE, PRODUCT_NAME)
    VALUES (@voucherType, @product1),
           (@voucherType, @product2)
    INSERT INTO VOUCHER (VOUCHER_NUMBER, VOUCHER_TYPE)
    VALUES (@voucherNumber, @voucherType)

    EXECUTE tSQLt.ExpectNoException

    -- Act
    DECLARE @actualValue MONEY

    EXEC SP_ADD_PRODUCTS_TO_VOUCHER @voucherNumber, @voucherType

    SELECT @actualValue = AMOUNT FROM PRODUCT_ON_VOUCHER WHERE PRODUCT_NAME = @product2

    -- Arrange
    EXECUTE tSQLt.AssertEquals NULL, @actualValue
END
GO

/* ====================================
  Integrity Rule: 8
======================================= */
tSQLt.NewTestClass 'Tests_IR8'
GO

DROP PROC IF EXISTS Tests_IR8.test_chk_balance_type_has_no_price_passes
GO

CREATE PROC Tests_IR8.test_chk_balance_type_has_no_price_passes
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable 'PRODUCT', 'dbo'
    EXEC tSQLt.ApplyConstraint 'PRODUCT', 'CHK_BALANCE_TYPE_HAS_NO_PRICE'
    EXEC tSQLt.ApplyConstraint 'PRODUCT', 'CHK_OTHER_TYPE_HAS_PRICE'

    EXEC tSQLt.ExpectNoException

    -- Act
    INSERT INTO PRODUCT (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES ('Ticket_Balance', 'Balance', NULL)

END
GO

DROP PROC IF EXISTS Tests_IR8.test_chk_balance_type_has_no_price_fails
GO

CREATE PROC Tests_IR8.test_chk_balance_type_has_no_price_fails
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable 'PRODUCT', 'dbo'
    EXEC tSQLt.ApplyConstraint 'PRODUCT', 'CHK_BALANCE_TYPE_HAS_NO_PRICE'
    EXEC tSQLt.ApplyConstraint 'PRODUCT', 'CHK_OTHER_TYPE_HAS_PRICE'

    EXEC tSQLt.ExpectException

    -- Act
    INSERT INTO PRODUCT (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES ('Ticket_Balance', 'Balance', 20)

END
GO

DROP PROC IF EXISTS Tests_IR8.test_chk_other_type_has_price_passes
GO

CREATE PROC Tests_IR8.test_chk_other_type_has_price_passes
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable 'PRODUCT', 'dbo'
    EXEC tSQLt.ApplyConstraint 'PRODUCT', 'CHK_BALANCE_TYPE_HAS_NO_PRICE'
    EXEC tSQLt.ApplyConstraint 'PRODUCT', 'CHK_OTHER_TYPE_HAS_PRICE'

    EXEC tSQLt.ExpectNoException

    -- Act
    INSERT INTO PRODUCT (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES ('Frozen 3', 'Ticket', 15)

END
GO

DROP PROC IF EXISTS Tests_IR8.test_chk_other_type_has_price_fails
GO

CREATE PROC Tests_IR8.test_chk_other_type_has_price_fails
AS
BEGIN
    -- Arrange
    EXEC tSQLt.FakeTable 'PRODUCT', 'dbo'
    EXEC tSQLt.ApplyConstraint 'PRODUCT', 'CHK_BALANCE_TYPE_HAS_NO_PRICE'
    EXEC tSQLt.ApplyConstraint 'PRODUCT', 'CHK_OTHER_TYPE_HAS_PRICE'

    EXEC tSQLt.ExpectException

    -- Act
    INSERT INTO PRODUCT (PRODUCT_NAME, PRODUCT_TYPE, PRICE)
    VALUES ('Frozen 3', 'Ticket', NULL)

END
GO

tSQLt.RunAll
GO
