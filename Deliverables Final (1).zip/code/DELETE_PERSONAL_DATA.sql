USE SUPERCINEMA
GO

DROP PROC IF EXISTS DELETE_PERSONAL_DATA_AFTER_TEN_YEARS
GO

CREATE PROC DELETE_PERSONAL_DATA_AFTER_TEN_YEARS
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint

            UPDATE [ORDER]
            SET CUSTOMER_EMAIL   = 'REMOVED',
                ADDRESS          = 'REMOVED',
                POSTAL_CODE      = 'REMOVED',
                PERSONAL_MESSAGE = 'REMOVED'
            WHERE CONFIRMED_DATE_TIME < DATEADD(year, -10, GETDATE())
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        THROW
    END CATCH
END
GO
