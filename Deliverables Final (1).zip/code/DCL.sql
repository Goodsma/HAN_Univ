USE SUPERCINEMA
GO

/* ====================================
  SP check voucher status
======================================= */

DROP PROC IF EXISTS THROW_ERROR_WHEN_VOUCHER_IS_NOT_OPEN
GO

CREATE PROC THROW_ERROR_WHEN_VOUCHER_IS_NOT_OPEN @VOUCHER_NUMBER INTEGER
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint
            IF (SELECT STATUS FROM VOUCHER WHERE VOUCHER_NUMBER = @VOUCHER_NUMBER) != 'Open'
                THROW 52008, 'Voucher can not be used.', 1
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        THROW
    END CATCH
END
GO

/* ====================================
  Integrity Rule: 1
======================================= */

ALTER TABLE VOUCHER
    DROP CONSTRAINT
        IF EXISTS CHK_VOUCHER_STATUS
GO

ALTER TABLE VOUCHER
    ADD CONSTRAINT CHK_VOUCHER_STATUS
        CHECK (STATUS IN ('Used', 'Open', 'Blocked', 'Returned'))
GO

/* ====================================
  Integrity Rule: 2
======================================= */
ALTER TABLE PRODUCT
    DROP CONSTRAINT
        IF EXISTS CHK_PRODUCT_TYPE
GO

ALTER TABLE PRODUCT
    ADD CONSTRAINT CHK_PRODUCT_TYPE
        CHECK (PRODUCT_TYPE IN ('Ticket', 'Snack', 'Drink', 'Balance'))
GO

/* ====================================
  Integrity Rule: 3
======================================= */
DROP PROC IF EXISTS SP_UPDATE_SELLING_PRICE
GO

CREATE PROC SP_UPDATE_SELLING_PRICE @voucherNumber INTEGER
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint

            IF (@voucherNumber IS NULL)
                BEGIN
                    ;THROW 52008, 'A value can not be empty, enter a valid value.', 1
                END

            DECLARE @selling_price NUMERIC(8, 2) = (
                                                       SELECT ISNULL(SUM(QUANTITY * PRICE), 0)
                                                       FROM PRODUCT_ON_VOUCHER POV
                                                                INNER JOIN PRODUCT P
                                                                           ON P.PRODUCT_NAME = POV.PRODUCT_NAME
                                                       WHERE POV.VOUCHER_NUMBER = @voucherNumber)
                + (
                                                       SELECT ISNULL(SUM(AMOUNT), 0)
                                                       FROM PRODUCT_ON_VOUCHER PROV
                                                       WHERE PROV.VOUCHER_NUMBER = @voucherNumber
                                                   )

            UPDATE VOUCHER SET SELLING_PRICE = @selling_price WHERE VOUCHER_NUMBER = @voucherNumber
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO

/* ====================================
  Integrity Rule: 4
======================================= */

DROP PROC IF EXISTS SP_SCAN_PRODUCT_ON_VOUCHER
GO

CREATE PROC SP_SCAN_PRODUCT_ON_VOUCHER @voucherNumber INTEGER,
                                       @productName VARCHAR(256),
                                       @scannedBy INT,
                                       @scannedLocation VARCHAR(256)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint
            DECLARE @MESSAGE VARCHAR(255)

            IF (@voucherNumber IS NULL OR
                @productName IS NULL)
                THROW 51000, 'U missed a parameter.', 1;

            EXEC THROW_ERROR_WHEN_VOUCHER_IS_NOT_OPEN @voucherNumber

            IF ((SELECT PRODUCT_TYPE  FROM PRODUCT WHERE PRODUCT_NAME = @productName) NOT IN ('Ticket','Snack','Drink'))
                BEGIN
                    ;THROW 52003, 'You can not decrease the quantity of this product.', 1
                END

            ELSE
                SET @MESSAGE = CONCAT('Voucher ', @voucherNumber, ' Product ', @productName,
                                      ' can''t be used because the quantity is 0.');
            IF (SELECT QUANTITY
                FROM PRODUCT_ON_VOUCHER
                WHERE VOUCHER_NUMBER = @voucherNumber
                  AND PRODUCT_NAME = @productName) <= 0
                THROW 51007, @MESSAGE, 1;

            ELSE
                UPDATE PRODUCT_ON_VOUCHER
                SET QUANTITY = QUANTITY - 1
                WHERE VOUCHER_NUMBER = @voucherNumber
                  AND PRODUCT_NAME = @productName

                  EXEC SP_INSERT_SCANNED_BY @voucherNumber = @voucherNumber,
                                 @productName = @productName,
                                 @scannedBy = @scannedBy,
                                 @scannedLocation = @scannedLocation
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        THROW
    END CATCH
END
GO

/* ====================================
  Integrity Rule: 5
======================================= */

DROP PROC IF EXISTS SP_DECREASE_POV_BALANCE
GO

CREATE PROCEDURE SP_DECREASE_POV_BALANCE @voucherNumber INTEGER,
                                         @productName VARCHAR(256),
                                         @amount NUMERIC(8, 2),
                                         @scannedBy INTEGER,
                                         @scannedLocation VARCHAR(256)
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @startTC INT = @@TRANCOUNT
    DECLARE @savepoint VARCHAR(128) = CAST(OBJECT_NAME(@@PROCID) AS VARCHAR(125)) + CAST(@@NESTLEVEL AS VARCHAR(3))
    BEGIN TRY
        BEGIN TRAN
            SAVE TRAN @savepoint
            DECLARE @MESSAGE VARCHAR(255)

            IF (@voucherNumber IS NULL OR
                @productName IS NULL OR
                @amount IS NULL)
                THROW 51000, 'U missed a parameter.', 1;

            EXEC THROW_ERROR_WHEN_VOUCHER_IS_NOT_OPEN @voucherNumber

            IF ((SELECT PRODUCT_TYPE FROM PRODUCT WHERE PRODUCT_NAME = @productName) != 'Balance')
                THROW 51000, 'You can not decrease the balance of this voucher.', 1;

            ELSE
                SET @MESSAGE = CONCAT('Voucher ', @voucherNumber,
                                      ' can''t be used because the balance is 0.');
            IF (SELECT AMOUNT
                FROM PRODUCT_ON_VOUCHER
                WHERE VOUCHER_NUMBER = @voucherNumber
                  AND PRODUCT_NAME = @productName) <= 0
                THROW 51000, @MESSAGE, 1;

            ELSE
                SET @MESSAGE = 'You don''t have enough balance on this voucher.'
            IF (@amount) >
               (SELECT AMOUNT
                FROM PRODUCT_ON_VOUCHER
                WHERE VOUCHER_NUMBER = @voucherNumber
                  AND PRODUCT_NAME = @productName)
                THROW 51000, @MESSAGE, 1;

            ELSE
                UPDATE PRODUCT_ON_VOUCHER
                SET AMOUNT = AMOUNT - @amount
                WHERE VOUCHER_NUMBER = @voucherNumber
                  AND PRODUCT_NAME = @productName

                  EXEC SP_INSERT_SCANNED_BY @voucherNumber = @voucherNumber,
                                 @productName = @productName,
                                 @scannedBy = @scannedBy,
                                 @scannedLocation = @scannedLocation
        COMMIT TRAN
    END TRY
    BEGIN CATCH
        IF xact_state() = -1 AND @startTC = 0
            ROLLBACK TRAN
        IF xact_state() = 1
            BEGIN
                ROLLBACK TRAN @savepoint
                COMMIT TRAN
            END;
        THROW
    END CATCH
END
GO

/* ====================================
  Integrity Rule: 6
======================================= */
DROP TRIGGER IF EXISTS TRG_UPDATE_STATUS_IF_VOUCHER_IS_USED
GO

CREATE TRIGGER TRG_UPDATE_STATUS_IF_VOUCHER_IS_USED
    ON PRODUCT_ON_VOUCHER
    AFTER UPDATE
    AS
BEGIN
    IF @@ROWCOUNT = 0 RETURN
    SET NOCOUNT ON
    BEGIN TRY
        UPDATE VOUCHER
        SET STATUS = 'Used'
        WHERE VOUCHER_NUMBER IN (
            SELECT POV.VOUCHER_NUMBER
            FROM PRODUCT_ON_VOUCHER POV
            WHERE ((AMOUNT = 0 AND QUANTITY IS NULL)
               OR (QUANTITY = 0 AND AMOUNT IS NULL)) AND
                  POV.VOUCHER_NUMBER NOT IN (SELECT V.VOUCHER_NUMBER FROM VOUCHER V WHERE STATUS = 'Used')
            GROUP BY POV.VOUCHER_NUMBER
            HAVING COUNT(PRODUCT_NAME) = (SELECT COUNT(VOUCHER_NUMBER)
                                          FROM PRODUCT_ON_VOUCHER POV2
                                          WHERE POV2.VOUCHER_NUMBER = POV.VOUCHER_NUMBER))
    END TRY
    BEGIN CATCH
        DECLARE @errormessage VARCHAR(2000) =
                'Error occured in sproc ''' + OBJECT_NAME(@@procid) + '''. Original message: ''' + ERROR_MESSAGE() +
                '''';
        THROW 50000, @errormessage, 1;
    END CATCH
END
GO

/* ====================================
  Integrity Rule: 7
  The implementation of IR 7 is part of the creation of a voucher. Therefore the procedure can be found in
  crud procedures > CRUD_VOUCHER.sql on line 227.
  The unittests for this procedure, however, will be put in DCL_UNITTESTS under IR7.
======================================= */

/* ====================================
  Integrity Rule: 8
======================================= */
ALTER TABLE PRODUCT
    DROP CONSTRAINT
        IF EXISTS CHK_BALANCE_TYPE_HAS_NO_PRICE
GO

ALTER TABLE PRODUCT
    ADD CONSTRAINT CHK_BALANCE_TYPE_HAS_NO_PRICE
        CHECK (
                NOT PRODUCT_TYPE = 'Balance'
                OR PRICE IS NULL
            )
GO

ALTER TABLE PRODUCT
    DROP CONSTRAINT
        IF EXISTS CHK_OTHER_TYPE_HAS_PRICE
GO

ALTER TABLE PRODUCT
    ADD CONSTRAINT CHK_OTHER_TYPE_HAS_PRICE
        CHECK (
                NOT PRODUCT_TYPE != 'Balance'
                OR PRICE IS NOT NULL
            )
GO