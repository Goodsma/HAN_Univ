# Technical Design

### Table of contents
* [1. Introduction](#introduction)
* [2. Physical Database Schema](#physical_schema)
    * [2.1 Physical Database Model](#physical_model)
    * [2.2 Table descriptions](#table_descriptions)
    * [2.3 Integrity rules](#integrity_rules)
    * [2.4 Implementation choices](#implementation_choices)
        * [2.4.1 Modeling decisions for PDM](#modeling_decisions)
        * [2.4.2 Implementation choices for integrity rules](#ic_ir)
* [3. Information needs](#information_needs)
    * [3.1 Information need 1](#in1)
    * [3.2 Information need 2](#in2)
* [4. Staging Area](#staging-api)
    * [4.1 Class Diagram](#class-diagram)
    * [4.2 Python Requirements](#python-requirements)
    * [4.3 Installation and Usage Guide](#installation-guide)
        * [4.3.1 Installation](#installation)
        * [4.3.2 Usage](#usage_guide)
* [5. Concurrency and Indexing](#concurrency-indexing)
    * [5.1 Know Concurrency problems with fixes](#concurrency)
    * [5.2 Indexing](#indexing)
* [6. Test script](#test_script)

## 1. Introduction <a name="introduction"></a>
For the introduction on the assignment, see the introduction of the functional design.
In this technical design the information from the functional design will be converted into a physical database model with corresponding integrity rules and table descriptions.
There will also be a explanation on the staging area and API the financial department will use to access data.

## 2. Physical Database Schema <a name="physical_schema"></a>

### 2.1 Physical Database Model <a name="physical_model"></a>
This model is derived from the CDM model found in the Functional Design.
The chapters underneath will go more in depth on this diagram.

![Movie vouchers PDM](Pictures/Movie_Vouchers_PDM.png)
*figure 1*
<br><br>

### 2.2 Table descriptions <a name="table_descriptions"></a>
##### Table:Points_Of_sale
This table contains the different points of sale a voucher can be sold at. <br>
The attribute Shop_Name references to the name of the point of sale. <br> 
Shop name must be combined with a location if necessary to make it unique. <br>

##### Table:Voucher
This table holds all the general information of the vouchers. <br>
This table has Voucher_Number as a primary key to assign each voucher uniqueness. <br>
This table has foreign key Printed_By for table Employee, which is the employee that printed this voucher. <br>
If it is not printed yet this value is set to null. <br>
This table has foreign key Voucher_Type for table Voucher_Type, which means what type of voucher it is. <br>
This table has foreign key Reprint_Of for table Blocked_Voucher,
which means this voucher is a reprint of a blocked voucher. Since a voucher doesn't have to be blocked this value can be null. <br>
This table has foreign key Order_Number for table Order, which means the voucher was ordered by the online Order.  
Since a voucher doesn't have to be ordered online this value can be null. <br>
This table has attribute Printed_Date_Time which means when it was printed. Since there could be a printing error this value can be null. <br>
This table has attribute Status which can only be 'Used', 'Open', 'Blocked' or 'Returned'. <br>
This table has attribute Selling_price which is the total sum of the set price of the products and balance amount of the products . <br>
Printed_By, Printed_Date_Time should have value at the same time. It can't be like that Printed_By has value and Printed_Date_Time hasn't. <br>

##### Table:Blocked_Voucher
This table contains blocked vouchers that are blocked by employees and can't be used any more. <br>
So this table has foreign key Voucher_Number for table Voucher and it is also primary key. <br>
And has foreign key Blocked_By for table Employee. <br>

##### Table:Returned_Voucher
This table contains returned vouchers that can be returned by employees with a date and time. <br>  
So this table has foreign key Voucher_Number for table Voucher and it is also primary key. <br>
And has foreign key Returned_By for table Employee. <br>
And it has attribute Return_Date_Time. <br>

##### Table:Employee
This table contains all the employees with a employee number. <br>

##### Table:HAS_A_ROLE_OF
This table is made because of the many to many relationship between Role and Employee. <br>
Employee_Number and Role are the primary keys obtained from these 2 entities (Role and Employee). <br>

##### Table:Role
This table contains Role which is imposed to Employee. <br>
These roles can only be: 'Usher', 'Cashier', 'Manager' or 'Office Employee'. <br>

##### Table:Order
This table holds all the general information of the internet Order of vouchers. <br>
Attribute Order_Number is the primary key for identifying each order. <br>
This table has foreign key Printed_By for table Employee, which means who print this. <br>
This table has Confirmed_By for table Employee, which is the employee that confirmed this order. <br>
This table has attribute Address and Postal_Code for the delivery. <br>
Additionally there is attribute Customer_Email for connection with client. <br>  
Client can leave a Personal_Message which is optionally. <br>
Attribute Printed_Date_Time, Printed_By should have value at the same time. <br>
Attribute Confirmed_Date_Time. Confirmed_By should have value at the same time. <br>

##### Table:Product_On_Voucher
This table is made because a voucher can contain different products and or a balance. <br>
Attribute Amount is the balance on the voucher, this value only exist when the type of <Product_Type> is 'Balance'. <br>
Attribute Quantity is the quantity of a product on a voucher, this value only exist when the type of <Product_Type> is 'Drink', 'Snack' or 'Ticket'. <br>
Voucher_Number and Product_Name are the primary keys obtained from the Voucher and Product tables. <br>

##### Table:Product
This table contains the products that are sold at the cinema. <br>
The Product_Name is the primary key. <br>
Attribute Product_Type only has 'Ticket', 'Drink', 'Snack' or 'Balance'. <br>
The Price is the set price of a product which is only set if the product type isn't 'Balance'. <br>

##### Table:Voucher_Type
This table contains all the different voucher types hence the attribute Voucher_Type which is the primary key. <br>

##### Table:EXCHANGED_FOR
This table is made because of the many to many relationship between Voucher_Type and Product. <br>
This table shows which products a voucher type contains. <br>

##### Table:Scanned_By
This table contains the general information about the scanned vouchers. <br>
This table is needed since products and balance in a voucher can be scanned multiple times even at different location. <br>
Voucher_Number, Product_Name, Scanned_By and Scanned_Time are the primary keys. <br>
The Voucher_Number, Product_Name and Scanned_By attributes are obtained from different tables. <br>
This table has attribute Scanned_Location which is the location the product is scanned at.
 
### 2.3 Integrity rules <a name="integrity_rules"></a>
To insure that the stored information is correct a few integrity rules are needed.
These rules are derived from the constraints in the functional design.

**IR1: Corresponds with BR1 and C1**
* Specification: Att Status can only be 'Used', 'Open', 'Blocked' or 'Returned'.
* Implementation: Check constraint CHK_VOUCHER_STATUS on VOUCHER.

**IR2: Corresponds with BR2 and C2**
* Specification: Product_Type is one of the following values: 'Ticket', 'Snack', 'Drink' or 'Balance'.
* Implementation: Check constraint CHK_PRODUCT_TYPE on PRODUCT.

**IR3: Corresponds with BR3 and C3**
* Specification: Selling price is the total sum of the set price and balance amount of the products.
* Implementation: Stored procedure SP_UPDATE_SELLING_PRICE with the following parameter: @voucherNumber.

**IR4: Corresponds with BR4 and C4**
* Specification: When the voucher gets scanned for products with Product_Type 'Ticket', 'Snack' or 'Drink', the quantity is decreased by one.
* Implementation: Stored procedure SP_SCAN_PRODUCT_ON_VOUCHER with the following parameters: @voucherNumber, @productName, @amount, @scannedBy and @scannedLocation.

**IR5: Corresponds with BR5 and C5**
* Specification: When the voucher gets scanned for a product with Product_Type 'Balance', the amount is to be decreased by the amount spend by the customer on products.
* Implementation: Stored procedure SP_DECREASE_POV_BALANCE with the following parameters: @voucherNumber, @productName, @amount, @scannedBy and @scannedLocation.

**IR6: Corresponds with BR6 and C6**
* Specification: When all products quantity or amount in Product_On_Voucher of a voucher are zero, the status of that voucher needs to be updated to 'Used'.
* Implementation: After UPDATE trigger TRG_UPDATE_STATUS_IF_VOUCHER_IS_USED on PRODUCT_ON_VOUCHER.

**IR7: Corresponds with BR7 and C7**
* Specification: If Product_Type is 'Balance', then the Amount on Product_On_Voucher is filled in. For the Product_Type 'Ticket', 'Snack' or 'Drink', the Quantity on Product_On_Voucher is filled in.
* Implementation: Stored procedure SP_ADD_PRODUCTS_TO_VOUCHER with the following parameters: @voucherNumber and @voucherType.

**IR8: Corresponds with BR8 and C8**
* Specification:  If Product_Type is 'Balance' there is no price set in Product. For the Product_Type 'Ticket', 'Snack', or 'Drink', the price is set.
* Implementation: Check constraint CHK_BALANCE_TYPE_HAS_NO_PRICE and CHK_OTHER_TYPE_HAS_PRICE on PRODUCT.

### 2.4 Implementation choices and Modeling decisions <a name="implementation_choices"></a>
In this section we will go into more depth of modeling decisions we took for the PDM model and the implementation decisions we made for implementing the integrity rules.

#### 2.4.1 Modeling decisions for PDM <a name="modeling_decisions"></a>
After converting the CDM to a PDM model a few mistakes where ironed out making the model more readable. Starting with the attribute Employee_Number in 'Voucher'. This attribute indicates the employee that printed the voucher and is therefore renamed to Printed_By.    
Next up are Employee_Number and Emp_Employee_Number in 'Order'. These attributes are supposed to indicate the employee that printed the order and the employee that confirmed the printing. However, the way the attribute names are generated don't tell anything about the attribute.
We renamed the attributes to Printed_By and Confirmed_By to better understand what each attribute means.
The voucher number added to Voucher due to the relation between Voucher and Blocked_Voucher was renamed to Reprint_Of to better signify the relation.     
Lastly, we changed the three Employee_Number attributes in 'Blocked_Voucher', 'Returned_Voucher' and 'Scanned_By' to Blocked_By, Returned_By and Scanned_By respectively. 

#### 2.4.2 Implementation choices for integrity rules <a name="ic_ir"></a>
The reason why we implemented certain integrity rules (found in chapter 2.3) can be found underneath:

* IR1: This integrity rule will be implemented with a check constraint as only one attribute needs to be checked in one table.
* IR2: This integrity rule will be implemented with a check constraint as only one attribute needs to be checked in one table.
* IR3: This stored procedure needs to be executed when the Employee has set the amounts and quantities of all products on a voucher to update its selling price. The parameter is used to update the correct voucher.
* IR4: Every user based interaction with the database will go through a stored procedure. The parameters are necessary for adjusting the quantity of correct product on the correct voucher, and for scanning information of the products on the voucher.
* IR5: Every user based interaction with the database will go through a stored procedure. The parameters are necessary for flexibly adjusting the amount of balance for the correct product on the correct voucher, and for scanning information of the products on the vouchers.
* IR6: This integrity rule will be implemented with a trigger. This will be done because the voucher status needs to be updated if all amounts and quantities for the voucher are 0. It is best to check this after PRODUCT_ON_VOUCHER is updated.
* IR7: This stored procedure will be called when a voucher is being created. It will add all the products that are linked to the Voucher_Type to Product_On_Voucher and set their quantity and amount to 0. These values then need to be adjusted by an Employee through a different procedure.
* IR8: The integrity rules will be implemented with 'If A then B' check constraints due to fact that all the attributes are in the same table. With this it is possible to check that the price is NULL when Product_Type is 'Balance' and check if the price is not NULL when the type is anything else.

## 3. Information needs <a name="information_needs"></a>
In this chapter results can be found of the different information needs.
These results are from an example population and do not represent the actual number of sold and scanned vouchers. 

Information need 3 and 4 found in the functional design are not yet implemented because these are optional. 

### 3.1 Information need 1 <a name="in1"></a>
The result of information need 1 is seen below:

Result: <br>
![IN1_Result](Pictures/IN1_result.png)

*figure 2*
<br><br>

In this year there are 13 vouchers sold whereof 4 last month. The other 9 vouchers are sold this year just not last month, week, or yesterday.

### 3.2 Information need 2 <a name="in2"></a>
A voucher will be taken for scanned if a product or the balance on a voucher gets scanned. This would mean that when a voucher gets scanned
multiple times this would add up the scan amount. 

The result of information need 2 is seen below:

Result: <br>
![IN2_Result](Pictures/IN2_result.PNG) 

*figure 3*
<br><br>

In this year there are 5 vouchers scanned whereof 4 last week of last month. The other voucher is scanned this year just not last month, week, or yesterday.

## 4. Staging API <a name="staging-api"></a>

### 4.1 Class Diagram <a name="class-diagram"></a>
![Class Diagram](Pictures/Class%20Diagram.png)

*figure 4*
<br><br>

The class diagram in the image above is a visual representation of how the classes of the code should relate together. 
Hereby we used a few different types of arrows to represent different types of relations between classes. For example the regular arrow line is used to show a direct reference between the classes. This means that, for example, report_view.py makes direct use of the ReportController class.
Dotted arrow lines are used to show an indirect reference between classes. For example, ReportController passes a ReportResponseModel onwards to the report_view.py, but never directly accesses the class. 
For the last arrow type there is a reference between ReportGateway and Gateway. This line with a closed arrow head signifies that ReportGateway is a concrete implementation of the abstract Gateway class and the same goes for the BackgroundTask and ReportGenerationTask classes.

The FastAPI and Uvicorn classes have been coloured grey to signify the fact that they are external libraries and are not included in the system other than the provided reference arrows.

### 4.2 Python Requirements <a name="python-requirements"></a>
| **Requirement** | **Usage Description** |
| --- | --- |
| fastapi | This library is used for the API's endpoint server | 
| uvicorn | This library is required by fastapi  | 
| pydantic | This library is used for creating fastapi compatible response models | 
| ConfigParser | This library is used to read the config.ini file |
| pyodbc | This library is used to connect to the SQL database |
| pymongo | This library is used to connect to MongoDB databases |  
| dnspython | This library is required by pymongo to connect to MongoDB Atlas | 

*table 1*
<br><br>

### 4.3 Installation and Usage Guide <a name="installation-guide"></a>
In this paragraph we will explain how to install and use the staging API.
#### 4.3.1 Installation <a name="installation"></a>
For the installation of the staging api you are required to have Python v3.8+ installed on your working environment.
Make sure that the API is running on a device that can run 24/7 as the API runs as a server.

Place the directory of the API in a location of your desire. Make sure to change the config.ini's host to your MSSQL database host. 

#### 4.3.2 Usage <a name="usage_guide"></a>
In order to boot up the API, on Windows, simply execute the provided run_app.bat.
In the cases of MacOS and Linux devices run the following commands:
```pip install -r requirements.txt``` followed by ```python -m main```.

Once you have the API server running you can access it by going to ```http://127.0.0.1:8000/docs``` to access and execute the endpoints provided by this API.
It is also possible to access these endpoints from any front-end by simply accessing the URL with the specific paths such as ```127.0.0.1:8000/reports/sold```.

## 5. Concurrency and Indexing <a name="concurrency-indexing"></a>

### 5.1 Know Concurrency problems with fixes <a name="concurrency"></a>
There are multiple procedures where in theory concurrency problems could occur. However, due to how the domain works it is impossible for vouchers to be scanned multiple times at the same time by multiple employees. 
This is because it is physically impossible for the customer to be at multiple places at once.

| **Issue Number** | **Problem** | **Solution** | 
| --- | --- | --- |
| Con1 | The table VOUCHER makes use of an identity tag, which makes sure that each entry as a unique id that automatically increases for each insert. The problem arrives when we try to create new vouchers. First the voucher data gets inserted to generate a new ID. After that a select is used to retrieve the last inserted ID. However, if someone else were to create a new voucher between the insert and select statement, the select would return the wrong ID. | The way this was fixed is by changing the SP_CREATE_VOUCHER procedure to, instead of using an insert and then a select, use an insert that gives an output. By doing it is impossible to retrieve the wrong ID.
| Con2 | When the procedure for printing a voucher is executed, there is a check to see if the voucher was already printed before setting the print date and printed_by attributes. However, the printing could be ordered by two employees at the same time. This could result in both employees reading that no one has printed the voucher yet and they both update the attributes. | For the solution of the concurrency problem the isolation level of the procedure was set to serializable. This would result in a deadlock situation for both transaction causing one transaction to be terminated and one transaction to be committed. When the terminated transaction were to rerun the procedure it would now get the error that the voucher was already printed by the employee from transaction 2.
| Con3 | Concurrency Problem of SP_PRINT_ORDER ,SP_CONFIRM_PRINTING is specified below in the 'List: CRUD_ORDER'.| To solve this problem it is added PRINTED_DATE_TIME IS NULL or CONFIRMED_DATE_TIME IS NULL to the update where clause. By doing so it can be prevented duplicate print or confirm. Second attempt to update has result that 0 row is affected. In this case, using an output statement helped error can be thrown.

*table 2*
<br><br>

List:
CRUD_ORDER:
    SP_PRINT_ORDER -> Between if-statement and update someone can print it twice(overwrite it -> lost update)
    SP_CONFIRM_PRINTING -> Between if-statement and update someone can confirm it twice(overwrite it -> lost update)

In the DCL some concurrency issues could technically remain. However, because of the nature of our domain where everything is dependent of a voucer number that is unique and 
can not be scanned by 3 different users, these problems can not occur.
    
### 5.2 Indexing <a name="indexing"></a>
For the CRUD procedures no indexes are made, this is because the selects in these are all done with
the primary key of the tables. Since a clustered index is already set (which will be the fastest option) on the primary key, more isn't needed. <br>

In this version of the database there isn't a lot of data inserted for convenience. However, we need to take
into account that there could be a lot of data inserted. An example could be voucher data, because in the future 
it would be the case that there are a lot of vouchers with each of them containing different products. 
 
## 6. Test script <a name="test_script"></a>

For this project the following (sql) test script is made:

* DCL_UNITTESTS

In the "DCL_UNITTESTS" script the integrity rules implemented in the "DCL" script are tested to ensure that these are properly implemented.
This will be done with the tSQLt framework. <br>

**Installation:** <br>
To ensure proper use of the tSQLt framework, the tSQLt zip on their website needs to be installed first. 
In this zip the following scripts can be found: "SetClrEnabled.sql" & "tSQLt.class.sql". These scripts need to executed in order of
"SetClrEnabled.sql" first and then the "tSQLt.class.sql", after this the integrity rules unittests can be run. 
Note that in order to have all unittests run, the entire database(including CRUD procedures) needs to be present.
This can be done by first executing the whole script so the stored procedures are made, 
after this all test can be run by executing the "tSQLt.RunAll" command. 

