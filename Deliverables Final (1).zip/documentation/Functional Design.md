# Functional Design

### Table of contents
* [1. Introduction](#introduction)
* [2. Dynamic model](#d_model)
  * [2.1 User classes and characteristics](#user_classes)
  * [2.2 Use case model](#use_case_model)
  * [2.3 Brief use case description](#uc_brief)
* [3. Static model](#static_model)
    * [3.1 Verbalization's / Analysis](#verbalizations)
    * [3.2 Business Rules](#business_rules)
* [4. Conceptual Data Model](#conceptual_model)
    * [4.1 Entity Relationship Diagram](#entity_relations)
    * [4.2 Domains](#domains)
    * [4.3 Description of Domain concepts](#domain_description)
    * [4.4 Constraints](#constraints)
    * [4.5 Modelling decisions](#modelling_decisions)
* [5. Interaction Model](#interaction_model)
  * [5.1 CRUD Matrix](#crud_matrix)
  * [5.2 User privileges](#user_privileges)
* [6. Requirements](#requirements)
    * [6.1 Functional Requirements](#func_requirements)
    * [6.2 Non-Functional Requirements](#non_func_requirements)
* [7. Information needs](#information_needs)


## 1. Introduction <a name="introduction"></a>
Super Cinema's is a cinema chain that still uses an old database. In this functional design a new database is designed for Super Cinema's,
that is able to hold the existing vouchers from the old database and meets the other requested requirements. For more information on the
project and the scope of the project, see the project plan on this project.

## 2. Dynamic model <a name="d_model"></a>
The following chapters will take a closer look at the users of the system and the processes taking place in which there is interaction with the system.

### 2.1 User classes and characteristics <a name="user_classes"></a>
Below are the different user groups and their characteristics.

| **Actor** | **Description** |
| --- | --- |
| **Customer** | A customer that orders voucher(s) online. |
| **Usher** | An employee that serves customers during the movies. They scan the vouchers that the customers may have while taking their order and bring the order to the customer when it is ready. |
| **Cashier** | An employee at the counter that can sell and print vouchers, scan vouchers. |
| **Office employee** | An employee who works at the office and can print, block and return vouchers. |
| **Manager** | An employee with the same rights as both Cashier and office employee. The manager can also create new voucher types. |
| **Financial department** | An employee from the financial department that looks up records of importance for his/her department. |

*table 1*
<br><br>

### 2.2 Use case model <a name="use_case_model"></a>
The use case model below gives a visual representation on which actor does which processes. <br>
![UCD](Pictures/UCD.png) <br>
*figure 1* 
<br><br>

### 2.3 Brief use case description <a name="uc_brief"></a>
Below are brief descriptions of the use cases.

| **Use case** | **Brief description** |
| --- | --- |
| **Scan voucher** | The employee scans the voucher the customer gave to him/her to pay/exchange for a product that is available for that voucher type. |
| **Sell voucher** | The employee sells a voucher to a customer at the counter. |
| **Order voucher** | The customer orders voucher(s) online. |
| **Print voucher** | The employee prints out a voucher for the customer, confirms that the voucher is printed and hands it over to the customer. In case printing went wrong, the voucher can be blocked and reprinted. |
| **Block voucher** | The employee blocks a voucher after a customer has requested to do so or if it seems necessary to do so by the employee. |
| **Return voucher** | The employee returns a voucher that a customer returns. |
| **CRUD voucher type** | The employee creates, reads, updates or deletes a voucher type. |
| **Read relevant data** | The employee can read relevant data. |

*table 2*
<br><br>

## 3. Static model <a name="static_model"></a>

### 3.1 Verbalization's/Analysis <a name="verbalizations"></a>

**Verbalization** <br>
Out of the available documentation and the interview with the client,
are the following facts derived:

1. Fact type 1 <br>
<u>Voucher type 'grants entry to all movies'</u> can be exchanged for <u>Non-specific ticket.</u> <br>
Voucher type 'grants entry to all movies and all drinks.' can be exchanged for Coca Cola 300ml. <br>
-------ET Voucher_Type-----------------------------------------------------ET Product--------------<br>
------ID Att Voucher_Type--------------------------------------------------ID Att Product_Name------ <br>

RT EXCHANGED_FOR between Voucher_Type and Product

PREDICATE: Voucher type <Voucher_Type> can be exchanged for <Product_Name>. </p>

2. Fact type 2 <br>
<u>Voucher 10</u> was bought at <u>Super Cinema's Arnhem Stationslaan.</u> <br>
Voucher 9 was bought at Super Cinema's Arnhem ruitenberglaan. <br>
Voucher 7 was bought at Super Cinema's Nijmgen. <br>
Voucher 11 was bought at supermarket Market. <br>
--ET Voucher-----------------------ET Point_Of_Sale <br>
--ID Att Voucher_Number----------ID Att Shop_Name <br>

RT IS_BOUGHT_AT between Voucher and Point_Of_Sale

PREDICATE: voucher <Voucher_Number> was bought at <Shop_Name>. </p>

3. Fact type 3 <br>
<u>Voucher 12</u> has <u>the voucher type 'grants entry to one specific movie'.</u> <br>
Voucher 11 has the voucher type 'can be exchanged for specific products'. <br>
--ET Voucher-----------ET Voucher_Type--------------------------------- <br>
--MATCH----------------MATCH---------------------------------------------- <br>

RT HAS_A_TYPE_OF between Voucher and Voucher_Type

PREDICATE: Voucher <Voucher_Number> has the voucher type <Voucher_Name>. </p>

4. Fact type 4 <br>
The <u>delivery address</u> for <u>order 12</u> is <u>21 Jumpstreet.</u> <br>
The delivery address for order 11 is 22 Jumpstreet. <br>
-----ET Order----------------------------Att Address---- <br>
-----ID Att Order_Number---

PREDICATE: The delivery address for order <Order_Number> is < Address >. </p>

5. Fact type 5 <br>
The <u>postal code</u> of <u>order 12</u> is <u>3333CK.</u> <br>
The postal code of order 11 is 3333BK. <br>
-----------------------ET Order---Att Postal_Code <br>
-----------------------MATCH-----

PREDICATE: The postal code of order <Order_Number> is <Postal_Code>. </p>

6. Fact type 6 <br>
<u>Order 12</u> contains <u>voucher 12.</u> <br>
Order 11 contains voucher 11.<br>
Order 11 contains voucher 14.<br>
--ET Order----------ET Voucher------- <br>
--MATCH------------MATCH------------ <br>

RT VOUCHER_ON_ORDER between Order and Voucher

PREDICATE: Order <Order_Number> contains voucher <Voucher_Number>. </p>

7. Fact type 7 <br>
<u>Order 12</u> was placed by <u>customer with e-mail adress Piet@gmail.com.</u> <br>
Order 11 was placed by customer with e-mail adress Henk@gmail.com.<br>
--ET Order-----------------Att Customer_Email--------- <br>
--MATCH-------------------

PREDICATE: Order <Order_Number> was placed by customer with e-mail adress <Customer_Email>. </p>

8. Fact type 8 <br>
<u>Order 12</u> has <u>personal message of 'Enjoy!'.</u> <br>
Order 11 has personal message of 'You deserved it!'.<br>
--ET Order----Att Personal_Message------ <br>
--MATCH------

PREDICATE: Order <Order_Number> has personal message of <Personal_Message>. </p>

9. Fact type 9 <br>
<u>Voucher 12</u> is <u>printed by employee 8.</u> <br>
Voucher 11 is printed by employee 10.<br>
--ET Voucher---------ET Employee------------ <br>
--MATCH--------------ID Att Employee_Number <br>

RT PRINT_BY between Voucher and Employee

PREDICATE: Voucher <Voucher_Number> is printed by employee <Employee_Number>. </p>

10. Fact type 10 <br>
<u>Voucher 12</u> was <u>printed on 20-04-2020 at 11:29.</u> <br>
Voucher 11 was printed on 20-04-2020 at 12:29. <br>
--ET Voucher-----------Att Printed_Date_Time-------<br>
--MATCH-------

PREDICATE: Voucher <Voucher_Number> was printed on <Printed_Date_Time>. </p>

11. Fact type 11 <br>
<u>Order 12</u> was <u>printed on 20-04-2020 at 11:20.</u> <br>
Order 11 was printed on 20-04-2020 at 12:29. <br>
--ET Order----Att Printed_Date_Time------------ <br>
--MATCH----

PREDICATE: Order <Order_Number> was printed on <Printed_Date_Time>. </p>

12. Fact type 12 <br>
<u>Order 12 </u> is printed by <u>employee 11.</u> <br>
Order 11 is printed by employee 10. <br>
---ET Order--------------ET Employee-- <br>
---MATCH----------------MATCH--------- <br>

RT PRINTED_BY between Order and Employee

PREDICATE: Order <Order_Number> is printed by employee <Employee_Number>. </p>

13. Fact type 13 <br>
<u>Order 11's</u> printing was <u>confirmed by employee 1.</u> <br>
Order 12's printing was confirmed by employee 2. <br>
--ET Order-------------------ET Employee------ <br>
--MATCH----------------------MATCH------------ <br>

RT CONFIRMED_BY between Order and Employee

PREDICATE: Order <Order_Number>'s printing was confirmed by employee <Employee_Number>. </p>

14. Fact type 14 <br>
<u>Order 11's</u> printing was <u>confirmed on 20-04-2020 at 10:14.</u> <br>
Order 12's printing was confirmed on 20-04-2020 at 10:16. <br>
Order 12's printing was confirmed on 20-04-2020 at 10:15. <br>
--ET Order----------------Att Confirmed_Date_Time------------ <br>
--MATCH--------

PREDICATE: Order <Order_Number>'s printing was confirmed on <Approved_Date_Time>. </p>

15. Fact type 15 <br>
<u>Employee 14</u> has the <u>role Manager.</u> <br>
Employee 15 has the role Cashier. <br>
Employee 16 has the role Usher. <br>
--ET Employee--------ET Role---- <br>
--MATCH----------------ID Att Role---- <br>

RT HAS_A_ROLE_OF between Employee and Role

PREDICATE: Employee <Employee_Number> has the role < Role >. </p>

16. Fact type 16 <br>
<u>Voucher 13</u> has the <u>status blocked.</u> <br>
Voucher 19 has the status returned. <br>
--ET Voucher--------------ATT Status------- <br>
--MATCH-------

PREDICATE: Voucher <Voucher_Number> has a status of < Status >. </p>

17. Fact type 17*(from SDR2) <br>
<u>Voucher 13</u> is a voucher that is blocked. <br>
Voucher 17 is a voucher that is blocked. <br>
-ET Blocked_Voucher-----------<br>
-ID Att Voucher_Number

PREDICATE: Voucher <Voucher_Number> is a voucher that is blocked

18. Fact type 18 <br>
<u>Blocked voucher 13</u> is blocked by <u>employee 5.</u> <br>
Blocked voucher 17 is blocked by employee 8. <br>
--ET Blocked_Voucher--------------------ET Employee-- <br>
--MATCH---------------------------------MATCH----- <br>

RT BLOCKED_BY between Blocked_Voucher and Employee

PREDICATE: Blocked voucher <Voucher_number> is blocked by employee <Employee_Number>. </p>

19. Fact type 19 <br>
<u>Voucher 100</u> is a reprint of <u>blocked voucher 13.</u> <br>
Voucher 97 is a reprint of blocked voucher 17.<br>
-ET Voucher---------------------ET Blocked_Voucher---<br>
-MATCH--------------------------MATCH----------------

RT REPRINT_OF between Blocked_Voucher and Voucher

PREDICATE: Voucher <Voucher_Number> is a reprint of  Blocked Voucher<Voucher_Number>. </p>

20. Fact type 20*(from SDR1) <br>
<u>Voucher 47</u> is a voucher that is returned. <br>
Voucher 23 is a voucher that is returned. <br>
-ET Returned_Voucher---------<br>
-ID Att Voucher_Number--<br>

PREDICATE: Voucher <Voucher_Number> is a voucher which is returned.</p>

21. Fact type 21 <br>
<u>Returned Voucher 47</u> is returned by <u>employee 5</u>. <br>
Returned Voucher 67 is returned by employee 5. <br>
-ET Returned_Voucher--------------ET Employee-- <br>
-MATCH---------------------------------MATCH-------

RT RETURNED_BY between Returned_Voucher and Employee

PREDICATE: Returned voucher <Voucher_Number> is returned by employee <Employee_Number>. </p>

22. Fact type 22 <br>
<u>Voucher 15</u> has <u>selling price €10</u>. <br> 
Voucher 43 has selling price €16. <br>
-ET Voucher----Att Selling_price--- <br>
-MATCH-----

PREDICATE: Voucher <Voucher_Number> has selling price <Selling_price>. </p>

23. Fact type 23<br>
<u>Coca Cola 300ml</u> is of the product type <u>Drink.</u> <br>
Non-specific ticket is of the product type Ticket. <br>
-ET Product------Att Product_Type- <br>
-MATCH-------

PREDICATE: Product <Product_Name> is of the product type <Product_Type>. </p> 

24. Fact type 24 <br>
<u>Coca Cola 300ml</u> has a <u>selling price €2</u>. <br> 
Non-specific ticket has a selling price €8. <br>
-ET Product------------------Att Price----- <br>
-MATCH----

PREDICATE: Product <Product_Name> has a selling price <Price>. </p>

25. Fact type 25 <br>
<u>Voucher 16 contain Coca Cola 300ml</u> with a <u>quantity 2</u>. <br>
Voucher 16 contain Medium popcorn sweet with a quantity 3. <br>
-ET Product_On_Voucher-----------------------------------Att Quantity---- <br>
-ID ET Voucher + ET Product--- <br>
------MATCH--------MATCH------ <br>

RT PRODUCTS_ON_VOUCHER between Voucher and Product_On_Voucher(dependent) <br>
RT IS_PRODUCT_OF between Product and Product_On_Voucher(dependent)

PREDICATE: Voucher <Voucher_Number> contain Product<Product_Name> with a quantity<Quantity>.

26. Fact type 26 <br>
<u>Voucher 16</u> contains a Ticket_Balance for which there is <u>an amount of €10</u>. <br>
Voucher 13 contains a Snack_Balance for which there is an amount of €10. <br>
-ET Product_On_Voucher---------------------------------------Att Amount-- <br>
----MATCH------------ <br>

RT PRODUCTS_ON_VOUCHER between Voucher and Product_On_Voucher
RT IS_PRODUCT_OF between Product and Product_On_Voucher

PREDICATE: Voucher <Voucher_Number> contains a Product<Product_Name> for which there is an amount of <Amount>. </p>

27. Fact type 27 <br>
<u>Coca Cola 300ml on Voucher 14 that was scanned by Employee 15 was scanned on 21-08-2020 at 21:15</u>. <br>
Ticket_Balance on Voucher 14 that was scanned by Employee 13 was scanned on 20-07-2020 at 21:45 . <br>
-ET Scanned_By---------------------------------------------------------------------------------------------- <br>
-ID ET Product_On_Voucher + ET Employee + Att Scanned_Time-----------<br>

RT SCANS between Scanned_By(dependent) and Product_On_Voucher <br>
RT SCANNED_BY between Scanned_By(dependent) and Employee <br>

PREDICATE: Product <Product_Name> on Voucher <Voucher_Number> that is scanned by Employee <Employee_Number> was scanned on <Scanned_Time>. </p>

28. Fact type 28 <br>
<u>Coca Cola 300ml on Voucher 14 that was scanned by Employee 15 on 21-08-2020 at 21:15</u> was scanned at <u>Super Cinema's Arnhem Station.</u> <br>
Drink_Balance on Voucher 14 that is scanned by Employee 12 on 01-01-2020 at 21:15 was scanned at Super Cinema's Nijmegen. <br>
-ET Scanned_By------------------------------------------------------------------------------------Att Scanned_Location--- <br>
-MATCH----------<br>

PREDICATE: Product <Product_Name> on Voucher <Voucher_Number> that is scanned by Employee <Employee_Number> on <Scanned_Time> is scanned at <Scanned_Location>. </p>

#### 3.2 Business Rules <a name="business_rules"></a>
All business rules have been written down underneath. These rules are written down to enforce a correct data model.
These rules will later be implemented in the database as constraints. <br>
BR1: The Status of a voucher can only be 'Used', 'Open', 'Blocked' or 'Returned'. <br>
BR2: Product_Type is one of the following values: 'Ticket', 'Snack', 'Drink' or 'Balance'. <br>
BR3: Selling price is the total of all products in the voucher which means the  total sum of the set price and balance amount of the products. <br>
BR4: When the voucher gets scanned for products with Product_Type 'Ticket', 'Snack' or 'Drink', the quantity is decreased by one. <br>
BR5: When the voucher gets scanned for a product with Product_Type 'Balance', the amount is to be decreased by the amount spend by the customer on products. <br>
BR6: When all products quantity or amount in Product_On_Voucher of a voucher are zero, the status of that voucher needs to be updated to 'Used'. <br>
BR7: If Product_Type is 'Balance', then the Amount on Product_On_Voucher is filled in. For the Product_Type 'Ticket', 'Snack' or 'Drink', the Quantity on Product_On_Voucher is filled in. <br>
BR8: If Product_Type is 'Balance' there is no price set in Product. For the Product_Type 'Ticket', 'Snack', or 'Drink', the price is set. <br>

## 4. Conceptual Data Model <a name="conceptual_model"></a>
In this chapter there will be looked at the CDM. This contains an ERD with
domains that will be clarified. The constrains are also mentioned in this chapter
with the modelling decisions.

### 4.1 Entity Relationship Diagram <a name="entity_relations"></a>
This model is made on the basis of the analysis from the previous chapter.
It contains all the entities and attributes and shows the relationships
between these entities. </p>
![Movie vouchers cdm](Pictures/Movie_vouchers.png)
*figure 2*
<br><br>

One of the client requests was to have a separate entity for the cinema branch locations. The entity Scanned_By could reference this entity, which in turn ensures that there is no nonsense data inserted into the Scanned_By location attribute.
However, due to time constraints this has not been implemented yet. If this were to be implemented the entity Point_of_Sale would be changed to the entity Location containing the primary identifier Name and a mandatory attribute Type. 
The Type attribute would get a domain constraint specifying that it could only be a 'Branch' or a 'Sales Point'. Point_of_Sale would return as a relation between Voucher and Location to show the sales point of the voucher. Between Scanned_By and Location there would be a relation named Scanned_Location.
In addition to the relation Scanned_Location there would also be a new business rule specifying that only Locations with the Type of 'Branch' can be used as a scanned_location.

### 4.2 Domains <a name="domains"></a>
The following table describes the domains in the ERD and their corresponding
datatypes and value constraints.

| NO | DOMAIN      | DATATYPE     | DESCRIPTION                                                                                                                              | Domain value constraints                        |
|:---|:------------|:-------------|:-----------------------------------------------------------------------------------------------------------------------------------------|:------------------------------------------------|
| 1  | ADDRESS     | VARCHAR(255) | ADDRESS is the address of the customer.                                                                                                  |                                                 |
| 2  | DATE_TIME   | DATE & TIME  | DATE & TIME is used for a 'Returned_voucher', 'Order' & 'Voucher'.                                                                       |                                                 |
| 3  | EMAIL       | VARCHAR(255) | EMAIL is the email of the customer.                                                                                                      |                                                 |
| 4  | MESSAGE     | VARCHAR(255) | MESSAGE is the personal message that the customer can supply.                                                                            |                                                 |
| 5  | MONEY       | MONEY        | The amount of money of a product.                                                                                                        | Values >= 0                                     |
| 6  | NAME        | VARCHAR(255) | NAME us used for the identification of a 'Point_Of_Sale', 'Voucher_Type' & 'Product' and the scanned location in 'Product_On_Voucher'.                                                    |                                                 |
| 7  | NUMBER      | INTEGER      | NUMBER is used for unique identification of the 'Voucher', 'Employee' & 'Order' and for the quantity in 'Product_On_Voucher'.                                                         | Values > 0                                      |
| 8  | POSTAL_CODE | VARCHAR(255) | POSTAL_CODE is the postal code of the customer.                                                                                          |                                                 |
| 9  | ROLE        | VARCHAR(255) | ROLE is the role an employee can have.                                                                                                   |                                                 |
| 10 | STATUS      | VARCHAR(255) | STATUS is the status the 'Voucher'can have this shows if it is a returned voucher, a blocked voucher, a used voucher or a normal voucher (open voucher). |                                                 |

*table 3*
<br><br>

### 4.3 Description of Domain concepts <a name="domain_description"></a>
In this section more context is given for the entities/domains.

| **Domain** | **Description** |
| --- | --- |
| **Voucher** | A voucher is a coupon that can be exchanged for certain products at the cinema. |
| **Blocked_Voucher** | A blocked voucher is a voucher that has been blocked by an employee because it was reported missing or something else went wrong with it. |
| **Returned_Voucher** | A returned voucher has been returned by a customer and processed by an employee. A returned voucher can not have been used for it to be able to be returned. When a voucher has become a returned voucher, it can no longer be used. |
| **Voucher_Type** | A voucher always has a voucher type. The voucher type determines what the voucher can be exchanged for. |
| **Product_On_Voucher** | The products that a voucher can be exchanged for. These products can contain a quantity or an amount depended on the product type. |
| **Product** | A product is a movie ticket, drink, snack or balance that can be used as seems fit. |
| **Scanned_By** | A product on a voucher can be scanned by different employees on different time at different locations, depending on where the customer uses their voucher.
| **Order** | An order lists all vouchers a customer bought. An Order also holds the address of the customer and its e-mail address as contact information. |
| **Employee** | Employee is a person who works at the cinema and interacts with the system. |
| **Role** | An Employee can have different roles. These roles are shown in this table/entity. |
| **Point_Of_Sale** | A point of sale is a location where vouchers can be bought by customers. |

*table 4*
<br><br>

### 4.4 Constraints <a name="constraints"></a>
All constraints have been written down underneath, these constraints correspond with the business rules in chapter 3.2.
The constraints will be implemented in the database to ensure the accuracy and reliability of the data in the tables.
Because if there is any violation between the constraint and the data action, the action is aborted. <br>

**C1 corresponds with B1**
* Concerns: ET Voucher, Att Status
* Specification: Att Status can only be 'Used', 'Open', 'Blocked' or 'Returned'.

**C2 corresponds with BR2**
* Concerns: ET Product, ATT Product_Type
* Specification: Product_Type is one of the following values: "Ticket", "Snack", "Drink" or "Balance".

**C3 corresponds with BR3**
* Concerns: ET Voucher, ATT Selling_Price
* Specification: Selling price is the total sum of the set price and balance amount of the products. 

**C4 corresponds with BR4**
* Concerns: ET Product_On_Voucher, ATT Quantity
* Specification: When the voucher gets scanned for products with Product_Type 'Ticket', 'Snack' or 'Drink', the quantity is decreased by one.

**C5 corresponds with BR5**
* Concerns: ET Product_On_Voucher, ATT Amount
* Specification: When the voucher gets scanned for a product with Product_Type 'Balance', the amount is to be decreased by the amount spend by the customer on products.

**C6 corresponds with BR6**
* Concerns: ET Voucher, ATT Status, ET Product_On_Voucher, ATT Quantity, ATT Amount
* Specification:  When all products quantity or amount in Product_On_Voucher of a voucher are zero, the status of that voucher needs to be updated to 'Used'.

**C7 corresponds with BR7**
* Concerns: ET Product, ATT Product_Type, ET Product_On_Voucher, ATT Quantity, ATT Amount
* Specification: If Product_Type is 'Balance', then the Amount on Product_On_Voucher is filled in. For the Product_Type 'Ticket', 'Snack' or 'Drink', the Quantity on Product_On_Voucher is filled in. 

**C8 corresponds with BR8**
* Concerns: ET Product, ATT Product_Type, ATT Price
* Specification: If Product_Type is 'Balance' there is no price set in Product. For the Product_Type 'Ticket', 'Snack' or 'Drink', the price is set.

### 4.5 Modelling decisions <a name="modelling_decisions"></a>
This paragraph will go explain every decision that was made whilst modelling the CDM model.

**Decision** | **Description**
--- | ---
**D1** | The entity Blocked_Voucher and Returned_Voucher are subtypes of Voucher as they both require the properties of Voucher. In order to determine sub-type of voucher the attribute 'Status' was added to Voucher to act as the subtype derivable fact.
**D2** | Point_Of_Sale was kept as a separate entity in order to prevent the duplication of sales point data. This also allows for the addition of more information about the sales point without having to change any data corresponding with the vouchers.
**D3** | Product_On_Voucher was added to keep track of what products (and how many) are stored on which voucher. The entity can also be used to derive the price of a voucher.
**D4** | Product_Type was given a domain constraint rather than a look-up entity due to the assumption that the cinema branch will not add different types of products any time soon. Due to that it is deemed unnecessary to make the product-type maximally flexible.
**D5** | Role was added as an entity to allow Employees to have multiple/different roles in a flexible way.
**D6** | The relation Reprint_Of was added between Voucher and Blocked_Voucher to indicate that the voucher can be a reprint of a blocked voucher.
**D7** | In the relation Reprint_Of, Blocked_Voucher was made Dominant to enforce a foreign key reference from Voucher to Blocked_Voucher.
**D8** | There are 2 relations between Order and Employee. One is for a reference to the Employee that prints the order and one for a reference to the Employee that confirmed that the order was printed.
**D9** | Balance was added as a Product_Type and the Product_Name dictates on which other product types you can spend the balance.
**D10** | BR7 was added to enforce that a balance has an amount and the other product types have a quantity.
**D11** | BR8 was added because a product with product type balance doesn't have a set price but has a variable amount that is dependant on the voucher, thus the amount is stored in the Product_On_Voucher entity.
**D12** | RT SCANNED_BY was made into an entity because multiple employees are able to scan the same voucher and vouchers can be used in different locations. By making an entity for this, there is a proper place to store this information.
**D13** | Scanned_Time has been added as part of the identifier because without it still one employee would be able to scan one voucher which isn't true.

*table 5*
<br><br>

## 5. Interaction Model <a name="interaction_model"></a>
In this section the interaction between the dynamic and static model is described.
### 5.1 CRUD Matrix <a name="crud_matrix"></a>
In this matrix the relationships between entities and use cases is shown using CRUD.

|  | **ET Voucher** | ET Voucher_Type | ET Product | ET Point_Of_Sale | ET Order | ET Employee | ET Blocked_Voucher | ET Returned_Voucher | ET Product_On_Voucher | ET Scanned_By |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **Scan voucher** | RU | R | R | --- | --- | --- | --- | --- | R | C |
| **Sell voucher** | CR | R | R | R | --- | --- | --- | --- | CR | --- |
| **Order voucher(s)** | R | R | R | --- | CR | --- | --- | --- | R | --- |
| **Print voucher** | R | R | R | --- | --- | R | --- | --- | R | --- |
| **Block voucher** | RU | --- | --- | --- | --- | R | RU | --- | --- | --- |
| **Return voucher** | RU | --- | --- | --- | --- | R | --- | RU | --- | --- |
| **CRUD voucher type** | --- | CRUD | --- | --- | --- | --- | --- | --- | --- | --- |
| **Read relevant data** | R | R | R | R | R | R | R | R | R | R |

*table 6*
<br><br>

### 5.2 User Privileges <a name="user_privileges"></a>
The following tables show the privileges each user has in the system with each of the entity types and relations.
It will show the priviliges each user has in the system with a type of CRUD matrix.

| CRUD Legend | Description |
| --- | --- |
| **C** | Creation of the attribute/entity |
| **R** | Reading attribute/entity |
| **U** | Updating of the attribute/entity |
| **D** | Deletion of the attribute/entity |

*table 7*
<br><br>

#### ET Voucher
| | Voucher_Number | Printed_Date_Time | Status | Selling_price | RT REPRINT_OF | RT IS_BOUGHT_AT | RT HAS_A_TYPE_OF | RT PRINT_BY
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **Customer** | --- | --- | --- | --- | --- | --- | --- | --- |
| **Usher** | R | --- | R | --- | --- | --- | R | R |
| **Cashier** | CR | U | RU | R | C | --- | CR | RU |
| **Manager** | CR | RU | RU | R | CR | R | CR | RU |
| **Office Employee** | CR | RU | RU | R | CR | R | CR | RU |
| **Financial department** | R | R | R | R | R | R | R | R |

*table 8*
<br><br>

#### ET Blocked_Voucher
| | RT BLOCKED_BY |
| --- | --- |
| **Customer** | --- |
| **Usher** | --- |
| **Cashier** | U |
| **Manager** | RU |
| **Office Employee** | RU | 
| **Financial department** | R |

*table 9*
<br><br>

#### ET Returned_Voucher
| | Return_Date_Time | RT RETURNED_BY |
| --- | --- | --- |
| **Customer** | ---| --- |
| **Usher** | --- | --- |
| **Cashier** | --- | --- |
| **Manager** | RU | RU |
| **Office Employee** | RU | RU | 
| **Financial department** | R | R |

*table 10*
<br><br>

#### ET Employee
| | Employee_Number | RT HAS_A_ROLE_OF | RT SCANNED_BY |
| --- | --- | --- | --- |
| **Customer** | --- | --- | --- |
| **Usher** | --- | --- | C |
| **Cashier** | --- | --- | C |
| **Manager** | R | R | CR |
| **Office Employee** | R | R | R |
| **Financial department** | R | R | R |

*table 11*
<br><br>

#### ET Role
| | Role
| --- | --- |
| **Customer** | --- |
| **Usher** | --- |
| **Cashier** | --- |
| **Manager** | --- |
| **Office Employee** | --- |
| **Financial department** | R |

*table 12*
<br><br>

#### ET Order
| | Order_Number | Address | Postal_Code | Customer_Email | Personal_Message | Printed_Date_Time | Confirmed_Date_Time | RT CONFIRMED_BY | RT PRINTED_BY | RT ORDER_OF_VOUCHER | 
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **Customer** | CR | CR | CR | CR | CR | --- | --- | --- | --- | --- |
| **Usher** | --- |  --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **Cashier** | R | R | R | R | R | RU | RU | RU | RU | R |
| **Manager** | R | R | R | R | R | RU | RU | RU | RU | R |
| **Office Employee** | R |  R | R | R | R | RU | RU | RU | RU | R |
| **Financial department** | R | --- | --- | --- | R | R | R | R | R | R |

*table 13*
<br><br>

#### ET Point_Of_Sale
| | Role
| --- | --- |
| **Customer** | --- |
| **Usher** | --- |
| **Cashier** | R |
| **Manager** | R |
| **Office Employee** | R |
| **Financial department** | R |

*table 14*
<br><br>

#### ET Voucher_Type
| | Voucher_Type | RT Exchanged_For
| --- | --- | --- |
| **Customer** | R | R |
| **Usher** | R | R |
| **Cashier** | R | R |
| **Manager** | CRUD | CRUD |
| **Office Employee** | R | R |
| **Financial department** | R | R |

*table 15*
<br><br>

#### ET Product
| | Product_Name | Product_Type | Price |
| --- | --- | --- | --- | 
| **Customer** | R | --- | --- | 
| **Usher** | R | --- | R |
| **Cashier** | R | R | R |
| **Manager** | R | R | R |
| **Office Employee** | R | R | R |
| **Financial department** | R | R | R |

*table 16*
<br><br>

#### ET Product_On_Voucher
| | Quantity | Amount | RT PRODUCTS_ON_VOUCHER | RT IS_PRODUCT_OF
| --- | --- | --- | --- | --- |
| **Customer** | --- | --- | --- | --- |
| **Usher** | RU | RU | R | R |
| **Cashier** | RU | RU | R | R |
| **Manager** | RU | RU | R | R |
| **Office Employee** | R | R | R | R |
| **Financial department** | R | R | R | R |

*table 17*
<br><br>

### ET Scanned_By 
| |  Scanned_Time | Scanned_Location | RT SCANNED_BY | RT SCANS
| --- | --- | --- | --- | --- |
| **Customer** | --- | --- | --- | --- |
| **Usher** | C | C | C | C |
| **Cashier** | C | C | C | C|
| **Manager** | CR | CR | CR | CR |
| **Office Employee** | R | R | R | R |
| **Financial department** | R | R | R | R |

*table 18*
<br><br>

## 6. Requirements <a name="requirements"></a>
The requirements are determined using the FURPS method and devided into functional and non-functional requirements.

### 6.1 Functional Requirements <a name="func_requirements"></a>
**Code** | **Description**
--- | ---
**FR1** | Personal data needs to be removed after ten years. 

*table 19*
<br><br>

### 6.2 Non-Functional Requirements <a name="non_func_requirements"></a>

#### 6.2.1 Performance
**Code** | **Description**
--- | ---
**NFR1** | The execution speed of the system should not be affected by user count.

*table 20*
<br><br>

#### 6.2.2 Supportability
**Code** | **Description**
--- | ---
**NFR2** | The system supports multiple users changing data at the same time without any concurrency propblems.

*table 21*
<br><br>

## 7. Information needs <a name="information_needs"></a>
The financial department has several information needs that need to be made. These can be found below. <br>

1. The first information need is about how many vouchers have been sold per day, week, month and/or year.
2. The second information need is about how many vouchers have been scanned per day, week, month and/or year.
3. The third information need is about the amount of vouchers scanned per employee on a given day, week, month and/or year.
4. The fourth information need is about how many vouchers are scanned per location on a given day, week, month and/or year.

The week starts on Monday (request of the client). Because of this reason the reports will show the results from last week because
it will generate the query for yesterday and it was from the last week. The same accounts for months and years.
