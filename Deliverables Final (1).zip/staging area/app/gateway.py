import configparser

import pyodbc
from pymongo import MongoClient


class Gateway:
    def __init__(self):
        self._collection = None

    def _mongo_db_connection(self):
        client = MongoClient(
            'mongodb+srv://Admin:ISE@maincluster-mxqgi.azure.mongodb.net/test?retryWrites=true&w=majority')
        db = client.get_database('super_cinema_db')
        return db

    def _sql_db_connection(self):
        config = configparser.ConfigParser()
        config.read('config.ini')

        return pyodbc.connect('Driver={SQL Server};'
                              'Server=' + config.get('DatabaseSection', 'database.host') + ';'
                                                                                           'Database=' + config.get(
            'DatabaseSection', 'database.dbname') + ';'
                                                    'UID=' + config.get('DatabaseSection',
                                                                        'database.user') + ';' 'PWD=' + config.get(
            'DatabaseSection', 'database.password') + ';')

    def _sql_data_handler(self, query: str, values, return_result: bool):
        try:
            database = self._sql_db_connection()  # Open connection
            cursor = database.cursor()
            cursor.execute(query, values)  # Execute query

            if return_result:
                return_value = cursor.fetchall()  # Fetch results
            else:
                return_value = None

            database.commit()  # Commit request
            database.close()  # Close database connection
            return return_value
        except pyodbc.Error as err:
            raise err

    def _upload_to_mongo(self, report):
        return self._collection.insert_one(report.dict())