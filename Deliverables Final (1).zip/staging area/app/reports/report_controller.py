from datetime import datetime

from app.reports.report_gateway import ReportGateway


class ReportController:
    def __init__(self):
        self._gateway = ReportGateway()

    def get_sold_vouchers_report(self):
        filter = self._create_filter("SoldVouchers")
        return self._gateway.get_todays_report(filter)

    def get_scanned_vouchers_report(self):
        filter = self._create_filter("ScannedVouchers")
        return self._gateway.get_todays_report(filter)

    def generate_reports(self):
        self._gateway.generate_sold_vouchers_report()
        self._gateway.generate_scanned_vouchers_report()
        print("Reports have been generated.")

    def _create_filter(self, report_type: str):
        date = datetime.now().strftime("%Y-%m-%d")
        filter = {"creation_date": date, "report_type": report_type}
        return filter
