from datetime import datetime

from app.gateway import Gateway
from app.reports.report_models import ScannedVouchersReportResponseModel, SoldVouchersReportResponseModel


class ReportGateway(Gateway):
    def __init__(self):
        super().__init__()
        self._collection = self._get_report_collection()
        self._ROW = 0
        self._YEAR = 0
        self._MONTH = 1
        self._WEEK = 2
        self._DAY = 3

    def _get_report_collection(self):
        return self._mongo_db_connection().reports

    def get_todays_report(self, report_filter):
        return self._collection.find_one(report_filter)

    def generate_sold_vouchers_report(self):
        query = "EXEC GET_VOUCHERS_SOLD"
        return_value = self._sql_data_handler(query, (), True)

        creation_date = datetime.now().strftime("%Y-%m-%d")
        report_type = "SoldVouchers"
        sold_in_day = return_value[self._ROW][self._DAY]
        sold_in_week = return_value[self._ROW][self._WEEK]
        sold_in_month = return_value[self._ROW][self._MONTH]
        sold_in_year = return_value[self._ROW][self._YEAR]
        report = SoldVouchersReportResponseModel(creation_date=creation_date, report_type=report_type,
                                                 sold_in_day=sold_in_day, sold_in_week=sold_in_week,
                                                 sold_in_month=sold_in_month, sold_in_year=sold_in_year)

        self._upload_to_mongo(report)
        return report

    def generate_scanned_vouchers_report(self):
        query = "EXEC GET_VOUCHERS_SCANNED"
        return_value = self._sql_data_handler(query, (), True)

        creation_date = datetime.now().strftime("%Y-%m-%d")
        report_type = "ScannedVouchers"
        scanned_in_day = return_value[self._ROW][self._DAY]
        scanned_in_week = return_value[self._ROW][self._WEEK]
        scanned_in_month = return_value[self._ROW][self._MONTH]
        scanned_in_year = return_value[self._ROW][self._YEAR]
        report = ScannedVouchersReportResponseModel(creation_date=creation_date, report_type=report_type,
                                                    scanned_in_day=scanned_in_day, scanned_in_week=scanned_in_week,
                                                    scanned_in_month=scanned_in_month, scanned_in_year=scanned_in_year)

        self._upload_to_mongo(report)
        return report
