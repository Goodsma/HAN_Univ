from fastapi import APIRouter

from app.reports.report_controller import ReportController
from app.reports.report_models import SoldVouchersReportResponseModel, ScannedVouchersReportResponseModel

router = APIRouter()
_report_controller = ReportController()


@router.get("/reports/sold", response_model=SoldVouchersReportResponseModel, status_code=200)
async def get_sold_vouchers_report():
    return _report_controller.get_sold_vouchers_report()


@router.get("/reports/scanned", response_model=ScannedVouchersReportResponseModel, status_code=200)
async def get_scanned_vouchers_report():
    return _report_controller.get_scanned_vouchers_report()
