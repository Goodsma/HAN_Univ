from app.base_model import BaseModel


class ScannedVouchersReportResponseModel(BaseModel):
    creation_date: str
    report_type: str
    scanned_in_day: int
    scanned_in_week: int
    scanned_in_month: int
    scanned_in_year: int


class SoldVouchersReportResponseModel(BaseModel):
    creation_date: str
    report_type: str
    sold_in_day: int
    sold_in_week: int
    sold_in_month: int
    sold_in_year: int
