from datetime import datetime

from app.reports.report_controller import ReportController


class BackgroundTask:
    def __init__(self):
        self._execution_time = None
        self._task_enabled = True

    def set_execution_time(self, hour: int, minutes: int):
        """
            :param hour Range from 0 to 23
            :param minutes Range from 0 to 59
        """
        if (hour < 0 or hour > 23) or (minutes < 0 or minutes > 59):
            raise Exception("Hour or minutes fell out of range.")
        else:
            self._execution_time = "{0:0=2d}".format(hour) + ":" + "{0:0=2d}".format(minutes)

    def execute(self):
        if self._reached_execution_time() and self._task_enabled:
            self._run()
        if not self._reached_execution_time() and not self._task_enabled:
            self._re_enable_task()

    def _reached_execution_time(self):
        if self._execution_time is None:
            raise Exception("Execution time was not set. Aborting.")

        current_time = datetime.now().strftime("%H:%M")
        return current_time == self._execution_time

    def _re_enable_task(self):
        self._task_enabled = True

    def _run(self):
        pass


class ReportGenerationTask(BackgroundTask):
    def __init__(self):
        super().__init__()
        self._report_controller = ReportController()

    def _run(self):
        self._report_controller.generate_reports()
        self._task_enabled = False


class BackgroundTaskScheduler:
    def __init__(self):
        self._tasks = []

    def add_task(self, task: BackgroundTask):
        self._tasks.append(task)

    def loop(self):
        while True:
            self._run_tasks()

    def _run_tasks(self):
        for task in self._tasks:
            task.execute()
