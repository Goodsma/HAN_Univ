from fastapi import FastAPI

from app.reports import report_view


def create_api():
    # Instance API
    app = FastAPI()

    # Add endpoint routers
    app.include_router(report_view.router, tags=['Reports'])

    return app
