import threading

import uvicorn

from app.background_tasks import BackgroundTaskScheduler, ReportGenerationTask
from setup import create_api

if __name__ == '__main__':
    # Setup API
    app = create_api()

    # Start Background Scheduler
    task = ReportGenerationTask()
    task.set_execution_time(4, 0)
    background_scheduler = BackgroundTaskScheduler()
    background_scheduler.add_task(task)
    threading.Thread(target=background_scheduler.loop,name="background_scheduler").start()

    # Run the application
    uvicorn.run(app)
